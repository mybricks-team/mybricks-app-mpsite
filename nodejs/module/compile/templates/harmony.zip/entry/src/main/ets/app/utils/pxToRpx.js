import Taro from '../../npm/@tarojs/taro';
import React__default, { useRef, useState, useMemo, useEffect, memo } from '../../npm/react';
import { Reaction } from '../render-taro/observable/index.js';

const oriCreateElement = React__default.createElement;
const matchKeys = ["marginTop", "marginBottom", "marginLeft", "marginRight", "paddingTop", "paddingBottom", "paddingLeft", "paddingRight", "width", "height", "fontSize", "left", "right", "top", "bottom"];
function pxTransform(value) {
  if (/[\d.]+(px)$/.test(value) || !isNaN(parseFloat(value)) && value !== "100%") {
    return Taro.pxTransform(parseFloat(String(value).replace("px", "")));
  }
  return value;
}
const createElement = React__default.createElement;
React__default.createElement = function () {
  for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
    args[_key] = arguments[_key];
  }
  const newArgs = [...args];
  if (newArgs[1]?.style && !newArgs[1]?.style?._transformed_) {
    const newStyle = {
      ...(newArgs[1]?.style ?? {})
    };
    Object.keys(newStyle).forEach(key => {
      try {
        if (matchKeys.includes(key)) {
          newStyle[key] = pxTransform(newStyle[key]);
        }
        if (["margin", "padding"].includes(key)) {
          const values = newStyle[key].split(" ");
          const newValues = values.map(v => pxTransform(v));
          newStyle[key] = newValues.join(" ");
        }
      } catch (error) {
        console.warn(`px to rpx: transform ${key} ${newStyle[key]} fail`);
      }
    });
    newStyle._transformed_ = true;
    newArgs[1].style = newStyle;
  }
  const [type, props] = args;
  if (props) {
    if (typeof type === "function" && !(type.prototype instanceof React__default.Component)) {
      const enCom = enhanceComponent(type);
      args.splice(0, 1, enCom);
      return createElement(...args);
    }
  }
  return oriCreateElement.apply(React__default, newArgs);
};
const PROP_ENHANCED = `__enhanced__`;
function enhanceComponent(fn) {
  let obFn = fn[PROP_ENHANCED];
  if (!obFn) {
    obFn = enhance(fn);
    try {
      fn[PROP_ENHANCED] = obFn;
    } catch (ex) {}
  }
  const props = Object.getOwnPropertyNames(fn);
  props && props.forEach(prop => {
    try {
      obFn[prop] = fn[prop];
    } catch (ex) {
      console.error(ex);
    }
  });
  return obFn;
}
function enhance(component) {
  let memoIt = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : true;
  function hoc(props, refs) {
    const ref = useRef(null);
    const [, setState] = useState([]);
    useMemo(() => {
      if (!ref.current) {
        ref.current = new Reaction(() => setState([]));
      }
    }, []);
    useEffect(() => {
      return () => {
        ref.current?.destroy();
        ref.current = null;
      };
    }, []);
    let render;
    ref.current?.track(() => {
      render = component(props, refs);
    });
    return render;
  }
  hoc.displayName = component.displayName || component.name;
  return memoIt ? /* @__PURE__ */memo(hoc) : hoc;
}
//# sourceMappingURL=pxToRpx.js.map
