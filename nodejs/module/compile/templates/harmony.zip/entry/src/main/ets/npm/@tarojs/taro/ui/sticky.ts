// @ts-nocheck
import { temporarilyNotSupport } from '../utils'

// 置顶
export const setTopBarText = /* @__PURE__ */ temporarilyNotSupport('setTopBarText')
