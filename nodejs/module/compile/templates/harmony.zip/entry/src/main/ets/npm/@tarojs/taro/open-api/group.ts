// @ts-nocheck
import { temporarilyNotSupport } from '../utils'

// 微信群
export const getGroupEnterInfo = /* @__PURE__ */ temporarilyNotSupport('getGroupEnterInfo')
