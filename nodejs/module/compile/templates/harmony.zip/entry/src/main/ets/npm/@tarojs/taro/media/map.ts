// @ts-nocheck
import { temporarilyNotSupport } from '../utils'

// 地图
export const createMapContext = /* @__PURE__ */ temporarilyNotSupport('createMapContext')
