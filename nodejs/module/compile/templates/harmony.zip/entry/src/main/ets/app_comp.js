import _defineProperty from './node_modules/@babel/runtime/helpers/esm/defineProperty.js';
import './registExternals.js';
import Taro from './npm/@tarojs/taro';
import { Component } from './npm/react';
import './app/utils/pxToRpx.js';
import { render } from './app/render-taro/index.js';
import { call } from './app/utils/callConnectorHttp-ktaro.js';
import { EventEmitter } from './app/utils/event.js';
import { tabbarIns } from './app/utils/tabbar.js';
import { parsePakoJson, getGlobalData } from './utils.js';
import { genMybricksSdk } from './app/utils/mybricks-sdk.js';
import _injectConfig from './mybricks/root-config.js';
import allInjectScript from './mybricks/inject-code.js';
import { ScenesContext } from './app/render-taro/scenesContext.js';

if ("harmony" === "h5") {
  require("./app.h5.less");
} else if ("harmony" !== "harmony") {
  require("./app.less");
}
const injectConfig = "harmony" === "h5" || "harmony" === "harmony" ? _injectConfig : parsePakoJson(_injectConfig);
const eventEmitter = new EventEmitter();
const app = getGlobalData();
app.h = app.h || {};
const {
  routeMap = {}
} = injectConfig ?? {};
const goto = (type, sceneId, url) => {
  if (routeMap[sceneId]?.isTabbar) {
    Taro.switchTab({
      url
    });
    return;
  }
  const goRoute = type === "navigateTo" ? Taro.navigateTo : Taro.redirectTo;
  goRoute({
    url,
    fail() {
      Taro.switchTab({
        url
      });
    }
  });
};
const genCallConnector = (status, comInstance) => (connector, params) => {
  if (connector.type === "http") {
    return call(comInstance[connector.id], params, {
      before(options) {
        let newOptions = {
          ...options
        };
        newOptions.header = newOptions.header || {};
        let mybricksGlobalHeaders = Taro.getStorageSync("_MYBRICKS_GLOBAL_HEADERS_");
        if (mybricksGlobalHeaders) {
          newOptions.header = {
            ...mybricksGlobalHeaders,
            ...newOptions.header
          };
        }
        if (connector.timeout) {
          newOptions.timeout = connector.timeout;
        }
        if (!/^(http|https):\/\/.*/.test(newOptions.url) && status.defaultCallServiceHost) {
          newOptions.url = `${status.defaultCallServiceHost}${newOptions.url}`;
        }
        return newOptions;
      }
    });
  } else {
    return Promise.reject("错误的连接器类型.");
  }
};
const getPagePathFromSceneIdAndParams = (sceneId, searchParams) => {
  const pagePath = routeMap?.[sceneId]?.path ?? `/pages/${sceneId}/index`;
  let pagePathWithQuery = pagePath;
  if (Object.prototype.toString.call(searchParams) === "[object Object]" && Object.keys(searchParams).length > 0) {
    let searchParamsString = Object.keys(searchParams).map(key => {
      const value = searchParams[key];
      const serializedValue = typeof value === "object" && value !== null ? JSON.stringify(value) : value;
      return `${key}=${encodeURIComponent(serializedValue)}`;
    }).join("&");
    console.log(`[searchParamsString]`, searchParamsString);
    pagePathWithQuery = `${pagePath}?${searchParamsString}`;
  } else {
    pagePathWithQuery = `${pagePath}?mb_key=${searchParams}`;
  }
  return [pagePathWithQuery, pagePath];
};
app.h.scenesContext = new ScenesContext({
  scenes: injectConfig.scenes,
  global: {
    fxFrames: injectConfig.fxFrames
  },
  globalVarMap: injectConfig.globalVarMap
});
app.h.render = (toJson, _ref) => {
  let {
    comDefs,
    comInstance,
    ref,
    scenesOperate,
    setShareConfig
  } = _ref;
  const _comModules = typeof app.mybricks?.allComModules === "object" ? Object.assign(app.mybricks?.allComModules, comInstance ?? {}) : comInstance;
  console.log("_comModules", _comModules);
  const mainPageJson = toJson.scenes?.filter(t => t.type !== "popup" && t.type !== "module")?.[0];
  const options = {
    env: {
      callConnector: genCallConnector(app.mybricks.status, _comModules),
      uploadFile(params) {
        let header = {};
        let mybricksGlobalHeaders = Taro.getStorageSync("_MYBRICKS_GLOBAL_HEADERS_");
        if (mybricksGlobalHeaders) {
          header = {
            ...mybricksGlobalHeaders,
            ...header
          };
        }
        if (!/^(http|https):\/\/.*/.test(params.url) && app.mybricks.status.defaultCallServiceHost) {
          params.url = `${app.mybricks.status.defaultCallServiceHost}${params.url}`;
        }
        Taro.uploadFile({
          header,
          ...params
        });
      },
      canvas: {
        id: mainPageJson?.id,
        _open(sceneId, params, action) {
          const [pagePathWithQuery] = getPagePathFromSceneIdAndParams(sceneId, params);
          switch (action) {
            case "blank":
              goto("navigateTo", sceneId, pagePathWithQuery);
              break;
            case "redirect":
              goto("redirectTo", sceneId, pagePathWithQuery);
              break;
            case "reLaunch":
              Taro.reLaunch({
                url: pagePathWithQuery
              });
              break;
            default:
              goto("navigateTo", sceneId, pagePathWithQuery);
              break;
          }
        },
        pages: routeMap
      },
      callServiceFx(id, params) {
        console.log("callServiceFx", id, params);
        return new Promise((resolved, rejected) => {
          Taro.request({
            url: `${app.mybricks.status.serviceFx?.url}/${id}`,
            method: "POST",
            header: {
              "x-mybricks-target": app.mybricks.status.serviceFx?.env
            },
            data: {
              params
            },
            success: res => {
              resolved(res.data.data);
            },
            fail: err => {
              rejected(err);
            }
          });
        });
      },
      renderCom(json, opts) {
        return new Promise(resolve => {
          resolve(render(json, {
            ...(opts || {}),
            env: {
              ...(opts?.env || {}),
              edit: false,
              runtime: true,
              events: [],
              comDefs,
              comInstance: _comModules
            },
            events: [],
            comDefs,
            comInstance: _comModules
            // callConnector: genCallConnector(toJson, _comModules),
          }));
        });
      },
      mybricksSdk: genMybricksSdk(allInjectScript),
      // event: eventEmitter,
      tabbar: tabbarIns,
      rootScroll: {
        onScroll: cb => eventEmitter.addEventListner(`rootScroll_${mainPageJson?.id}`, cb),
        emitScrollEvent: payload => eventEmitter.dispatch(`rootScroll_${mainPageJson?.id}`, payload),
        scrollTo: _ref2 => {
          let {
            scrollTop = 0
          } = _ref2;
        },
        getBoundingClientRect: Promise.resolve()
      },
      setShareConfig,
      // silent: true,
      global: app.global || {}
    },
    events: [],
    comDefs,
    comInstance: _comModules,
    scenesOperate,
    ref
  };
  const pageContext = app.h.scenesContext.createPageContext(mainPageJson?.id, options);
  return render(toJson, pageContext.options, pageContext, app.h.scenesContext);
};
app.h.destroy = jsonId => {
  app.h.scenesContext.destroyPage(jsonId);
};
app.h.isTabbarPage = jsonId => {
  return routeMap[jsonId]?.isTabbar;
};
app.mybricks = app.mybricks || {};
app.mybricks.status = injectConfig.status;
app.mybricks.allComModules = allInjectScript;
const init = () => new Promise(resolve => {
  resolve(true);
});
app.mybricks.ready = init();
class App extends Component {
  constructor() {
    super(...arguments);
    _defineProperty(this, "globalData", {
      xx: 11
    });
    _defineProperty(this, "taroGlobalData", {
      xx: 22
    });
  }
  componentDidMount() {
    console.log("componentDidMount", (/* @__PURE__ */new Date()).getTime());
    let systemInfoSync = Taro.getSystemInfoSync();
    let system = systemInfoSync.system.toLocaleLowerCase();
    console.log("systemInfoSync", systemInfoSync);
    const ratio = systemInfoSync.windowWidth / 375;
    const isIOS = system.indexOf("ios") > -1;
    const isAndroid = system.indexOf("android") > -1;
    const statusBarHeight = systemInfoSync.statusBarHeight;
    let _statusBarHeight = Math.ceil(statusBarHeight / ratio);
    let _titleHeight;
    if (isIOS) {
      _titleHeight = Math.ceil(44 / ratio);
    } else if (isAndroid) {
      _titleHeight = Math.ceil(48 / ratio);
    } else {
      _titleHeight = Math.ceil(48 / ratio);
    }
    app.mybricks.navigation = {
      navigationHeight: _statusBarHeight + _titleHeight,
      statusBarHeight: _statusBarHeight,
      titleHeight: _titleHeight
    };
    console.log("after componentDidMount", (/* @__PURE__ */new Date()).getTime());
  }
  onLaunch() {
    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }
    console.log("onLaunch", ...args);
  }
  componentDidShow() {
    for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
      args[_key2] = arguments[_key2];
    }
    console.log("componentDidShow", ...args);
  }
  componentDidHide() {
    for (var _len3 = arguments.length, args = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
      args[_key3] = arguments[_key3];
    }
    console.log("componentDidHide", ...args);
  }
  onPageNotFound(_ref3) {
    let {
      path,
      query
    } = _ref3;
    if ("harmony" === "h5") {
      console.warn("page not found" + path + query);
      return;
    } else {
      if (path?.split) {
        const sceneId = path.split("/").reverse()[1];
        const [pagePathWithQuery, pagePath] = getPagePathFromSceneIdAndParams(sceneId, query);
        if (pagePath.indexOf(path) > -1) {
          return;
        }
        goto("redirectTo", sceneId, pagePathWithQuery);
      }
    }
  }
  // this.props.children 是将要会渲染的页面
  render() {
    return this.props.children;
  }
}

export { App as default };
//# sourceMappingURL=app_comp.js.map
