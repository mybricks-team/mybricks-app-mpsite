// @ts-nocheck
import { temporarilyNotSupport } from '../utils'

// 扫码
export const scanCode = /* @__PURE__ */ temporarilyNotSupport('scanCode')
