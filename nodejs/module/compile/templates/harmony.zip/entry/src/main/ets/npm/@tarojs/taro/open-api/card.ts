// @ts-nocheck
import { temporarilyNotSupport } from '../utils'

// 卡券
export const openCard = /* @__PURE__ */ temporarilyNotSupport('openCard')
export const addCard = /* @__PURE__ */ temporarilyNotSupport('addCard')
