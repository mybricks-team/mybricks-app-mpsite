// @ts-nocheck
import { temporarilyNotSupport } from '../utils'

// 帐号信息
export const pluginLogin = /* @__PURE__ */ temporarilyNotSupport('pluginLogin')
export const login = /* @__PURE__ */ temporarilyNotSupport('login')
export const checkSession = /* @__PURE__ */ temporarilyNotSupport('checkSession')
