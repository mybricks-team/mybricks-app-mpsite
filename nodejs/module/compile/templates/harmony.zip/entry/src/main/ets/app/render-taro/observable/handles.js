import { observable } from './index.js';
import { isObject } from '../utils.js';
import { rawToProxy, proxyToRaw } from './global/index.js';
import { globalReactionStack } from './global/reactionStack.js';
import { globalTaskEmitter } from './global/taskEmitter.js';

function get(target, key) {
  const result = target[key];
  if (["$$typeof", "constructor"].includes(key) || target["__model_style__"] && !["display", "visibility"].includes(key)) {
    return result;
  }
  globalReactionStack.regist({
    target,
    key
  });
  const observableResult = rawToProxy.get(result);
  if (isObject(result)) {
    if (observableResult) {
      return observableResult;
    }
    return observable(result);
  }
  return observableResult || result;
}
function set(target, key, value) {
  if (isObject(value)) {
    value = proxyToRaw.get(value) || value;
  }
  const hasOwnProperty = Object.hasOwnProperty.call(target, key);
  const preValue = target[key];
  target[key] = value;
  let runTask = false;
  switch (true) {
    case !hasOwnProperty || Array.isArray(target) && key === "length":
      runTask = true;
      break;
    case value !== preValue:
      runTask = true;
      break;
    default:
      break;
  }
  if (runTask) {
    globalTaskEmitter.runTask({
      target,
      key
    });
    globalTaskEmitter.deleteTask(rawToProxy.get(preValue));
  }
  return true;
}
const baseHandlers = {
  get,
  set
};

export { baseHandlers as default };
//# sourceMappingURL=handles.js.map
