// @ts-nocheck
export declare const enum Shortcuts {
    Container = "container",
    Childnodes = "cn",
    Text = "v",
    NodeType = "nt",
    NodeName = "nn",
    Sid = "sid",
    Style = "st",
    Class = "cl",
    Src = "src"
}
