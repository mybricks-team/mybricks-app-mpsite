import Taro from '../../npm/@tarojs/taro';

const defaultFn = function (options) {
  for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
    args[_key - 1] = arguments[_key];
  }
  return {
    ...options,
    ...args
  };
};
const setData = (data, keys, val) => {
  const len = keys.length;
  function dfs(res, index, val2) {
    if (!res || index === len) {
      return res;
    }
    const key = keys[index];
    if (Array.isArray(res)) {
      return res.map((item, i) => {
        const curVal = val2[i];
        let obj;
        if (curVal === void 0) {
          obj = {};
          val2.push(obj);
        } else {
          obj = curVal;
        }
        return dfs(item, index, obj);
      });
    } else {
      if (index === len - 1) {
        val2[key] = res[key];
        return res[key];
      }
      res = res[key];
      if (Array.isArray(res)) {
        val2[key] = val2[key] || [];
      } else {
        val2[key] = val2[key] || {};
      }
    }
    return dfs(res, index + 1, Array.isArray(val2) ? val2 : val2[key]);
  }
  return dfs(data, 0, val);
};
const del = (data, keys) => {
  const len = keys.length;
  function dfs(data2, index) {
    if (!data2 || index === len) return;
    const key = keys[index];
    if (index === len - 1) {
      Reflect.deleteProperty(data2, key);
    }
    if (Array.isArray(data2)) {
      data2.forEach(item => {
        dfs(item, index);
      });
    } else {
      dfs(data2[key], index + 1);
    }
  }
  dfs(data, 0);
};
const getFetch = connector => {
  return (params, _ref, config) => {
    let {
      then,
      onError
    } = _ref;
    const method = connector.method;
    const path = connector.path.trim();
    const headers = connector.headers || {};
    const outputKeys = connector.outputKeys || [];
    const excludeKeys = connector.excludeKeys || [];
    const markList = connector.markList || [];
    if (!markList.length) {
      markList.push({
        title: "默认",
        id: "default",
        predicate: {},
        outputKeys,
        excludeKeys
      });
    }
    try {
      const url = path;
      const newParams = connector.globalParamsFn(method.startsWith("GET") ? {
        params,
        url,
        method,
        headers
      } : {
        data: params,
        url,
        method,
        headers
      });
      newParams.url = newParams.url || url;
      newParams.method = newParams.method || method;
      const options = connector.input(newParams);
      if (options.headers) {
        options.header = options.headers;
        Reflect.deleteProperty(options, "headers");
      }
      if (options.params) {
        let search = Object.keys(options.params).map(key => `${key}=${options.params[key]}`).join("&");
        options.url = (options.url || url).indexOf("?") === -1 ? `${options.url}?${search}` : `${options.url}&${search}`;
        Reflect.deleteProperty(options, "params");
      }
      options.method = options.method || method;
      let curOutputKeys = [];
      let curExcludeKeys = [];
      let curOutputId = "then";
      config.ajax(options).then(response => {
        if (typeof response?.data === "string" && response?.header?.["content-type"] === "application/json") {
          try {
            response.data = JSON.parse(response.data);
          } catch (error) {}
        }
        if (response?.statusCode !== 200) {
          return connector.globalErrorResultFn({
            error: response,
            response,
            config: {}
          }, {
            throwError: onError
          });
        }
        return connector.globalResultFn(
        // { response, config: options },
        {
          response: response?.data,
          config: options
        }, {
          throwStatusCodeError: onError,
          throwError: onError
        });
      }).then(response => {
        const result = connector.output(response, Object.assign({}, options), {
          throwStatusCodeError: onError,
          throwError: onError
        });
        for (let i = 0; i < markList.length; i++) {
          const {
            id,
            predicate = {
              key: "",
              value: void 0
            },
            excludeKeys: excludeKeys2,
            outputKeys: outputKeys2
          } = markList[i];
          if (!predicate || !predicate.key || predicate.value === void 0) {
            curOutputKeys = outputKeys2;
            curExcludeKeys = excludeKeys2;
            curOutputId = id === "default" ? "then" : id;
            break;
          }
          let curResult = result,
            keys = predicate.key.split(".");
          while (curResult && keys.length) {
            curResult = curResult[keys.shift()];
          }
          if (!keys.length && (predicate.operator === "=" ? curResult === predicate.value : curResult !== predicate.value)) {
            curOutputKeys = outputKeys2;
            curExcludeKeys = excludeKeys2;
            curOutputId = id === "default" ? "then" : id;
            break;
          }
        }
        return result;
      }).then(response => {
        curExcludeKeys?.forEach(key => del(response, key.split(".")));
        return response;
      }).then(response => {
        let outputData = Array.isArray(response) ? [] : {};
        if (curOutputKeys === void 0 || curOutputKeys.length === 0) {
          outputData = response;
        } else {
          curOutputKeys.forEach(key => {
            setData(response, key.split("."), outputData);
          });
          if (Array.isArray(curOutputKeys) && curOutputKeys.length && (curOutputKeys.length > 1 || !(curOutputKeys.length === 1 && curOutputKeys[0] === ""))) {
            try {
              let cascadeOutputKeys = curOutputKeys.map(key => key.split("."));
              while (Object.prototype.toString.call(outputData) === "[object Object]" && cascadeOutputKeys.every(keys => !!keys.length) && Object.values(outputData).length === 1) {
                outputData = Object.values(outputData)[0];
                cascadeOutputKeys.forEach(keys => keys.shift());
              }
            } catch (e) {
              console.log("connector format data error", e);
            }
          }
        }
        then(outputData);
      }).catch(error => {
        console.error("connector err", error);
        return onError(error);
      });
    } catch (error) {
      console.error("connector error", error);
      return onError(error);
    }
  };
};
function isPlainObject(value) {
  if (typeof value !== "object" || value === null) return false;
  let proto = Object.getPrototypeOf(value);
  if (proto === null) return true;
  return proto === Object.prototype;
}
function call(connector, params, config) {
  return new Promise((resolve, reject) => {
    try {
      const fn = getFetch(connector);
      const {
        before = defaultFn
      } = config || {};
      if (!isPlainObject(params)) {
        params = {};
      }
      fn(params, {
        then: resolve,
        onError: reject
      }, {
        ajax(options) {
          let _options = before({
            ...options
          }) || options;
          if (_options.header && _options.header["Content-Type"] === "multipart/form-data") {
            const formData = new FormData();
            Object.keys(_options.data ?? {}).forEach(key => {
              formData.append(key, _options.data[key]);
            });
            _options.data = formData;
            delete _options.header["Content-Type"];
          }
          return Taro.request(_options).then(res => {
            return res;
          }).catch(error => reject(error));
        }
      });
    } catch (ex) {
      console.error("连接器script错误", ex);
      reject("连接器script错误.");
    }
  });
}

export { call };
//# sourceMappingURL=callConnectorHttp-ktaro.js.map
