import React__default from '../../npm/react';

function Selection() {
  return /* @__PURE__ */React__default.createElement("view", {
    style: {
      width: "100%",
      height: "100%"
    }
  });
}
function Group(_ref) {
  let {
    slots
  } = _ref;
  return /* @__PURE__ */React__default.createElement("view", {
    style: {
      width: "100%",
      height: "100%",
      overflow: "visible"
    }
  }, slots.content.render());
}
function JsAi() {
  return () => {};
}
function polyfillCoreComlib(comDefs) {
  if (!comDefs["mybricks.core-comlib.selection-1.0.0"]) {
    comDefs["mybricks.core-comlib.selection-1.0.0"] = {
      namespace: "mybricks.core-comlib.selection",
      version: "1.0.0",
      runtime: Selection
    };
  }
  if (!comDefs["mybricks.core-comlib.group-1.0.0"]) {
    comDefs["mybricks.core-comlib.group-1.0.0"] = {
      namespace: "mybricks.core-comlib.group",
      version: "1.0.0",
      runtime: Group
    };
  }
  if (!comDefs["mybricks.core-comlib.js-ai-1.0.0"]) {
    comDefs["mybricks.core-comlib.js-ai-1.0.0"] = {
      namespace: "mybricks.core-comlib.js-ai",
      version: "1.0.0",
      runtime: Group
    };
  }
  return comDefs;
}

export { polyfillCoreComlib };
//# sourceMappingURL=polyfill-core-comlib.js.map
