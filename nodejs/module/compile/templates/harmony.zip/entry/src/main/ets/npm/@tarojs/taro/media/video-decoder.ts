// @ts-nocheck
import { temporarilyNotSupport } from '../utils'

// 视频解码器
export const createVideoDecoder = /* @__PURE__ */ temporarilyNotSupport('createVideoDecoder')
