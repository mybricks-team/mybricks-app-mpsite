const DynamicExternals = {
  /** 需要填充需要动态引入的javascript */
};

export { DynamicExternals as default };
//# sourceMappingURL=index.js.map
