import { useState, useRef } from '../../npm/react';
import Taro from '../../npm/@tarojs/taro';
import comInstance from './comModules.js';
import './comDefs.js';
import { getGlobalData } from '../../utils.js';
import injectConfig from './mybricks/page-config.js';
import '../../style.less.xss2.js';
import comDefs from '../../components/comDefs.js';

const app = getGlobalData();
const shareConfig = {
  message: null,
  timeline: null
};
const setShareConfig = (type, value) => {
  shareConfig[type] = value;
};
const component = () => {
  const [isReady, setIsReady] = useState(false);
  const [router] = useState(Taro.getCurrentInstance().router);
  const ioRefs = useRef({
    ref: {}
  });
  Taro.useDidShow(() => {
    if (!isReady) {
      return;
    }
    ioRefs.current.ref?.inputs?.onShow?.();
    Taro.eventCenter.trigger("pageDidShow", {
      path: router.path || "",
      query: router.params || {}
    });
  });
  Taro.useDidHide(() => {
    ioRefs.current.ref?.inputs?.onHide?.();
    Taro.eventCenter.trigger("pageDidHide", {
      path: router.path || "",
      query: router.params || {}
    });
  });
  Taro.useShareAppMessage(() => {
    if (shareConfig.message) {
      return shareConfig.message;
    }
  });
  Taro.useShareTimeline(() => {
    if (shareConfig.timeline) {
      return shareConfig.timeline;
    }
  });
  let jsx = app.h.render(injectConfig.toJson, {
    comDefs,
    comInstance,
    // scenesOperate: {
    //   /** 页面跳转 */
    //   open(props) {
    //     // TODO
    //     Taro.navigateTo({
    //       url: `/pages/${props.frameId}/index?params=${JSON.stringify(props.todo.value)}`,
    //       fail() {
    //         // 跳转失败的时候，使用 switchTab 重试
    //         Taro.switchTab({
    //           url: `/pages/${props.frameId}/index?params=${JSON.stringify(props.todo.value)}`
    //         });
    //       }
    //     });
    //   }
    // },
    ref: refs => {
      ioRefs.current.ref = refs;
      try {
        let value = Taro.getCurrentInstance()?.router?.params || {};
        console.warn("open before", value);
        if (value.params) {
          try {
            let params = decodeURIComponent(value.params);
            let rule = typeof params === "string" && params.indexOf("{") === 0 && params.indexOf("}") === params.length - 1;
            if (rule) {
              value = JSON.parse(params);
            } else {}
          } catch (e) {}
        }
        console.warn("open after", value);
        refs.inputs["open"]?.(value);
      } catch (e) {
        console.error("open", e);
        refs.inputs["open"]?.({});
      }
      setIsReady(true);
    },
    setShareConfig
  });
  return jsx;
};

export { component as default };
//# sourceMappingURL=index_comp.js.map
