// @ts-nocheck
import { temporarilyNotSupport } from '../utils'

// 音视频合成
export const createMediaContainer = /* @__PURE__ */ temporarilyNotSupport('createMediaContainer')
