// @ts-nocheck
import { temporarilyNotSupport } from '../utils'

// 授权
export const authorizeForMiniProgram = /* @__PURE__ */ temporarilyNotSupport('authorizeForMiniProgram')
export const authorize = /* @__PURE__ */ temporarilyNotSupport('authorize')
