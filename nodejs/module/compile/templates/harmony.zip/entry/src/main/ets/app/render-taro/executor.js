import { logOutputVal, logInputVal, log } from './logger.js';
import { uuid, easyClone } from './utils.js';

const ROOT_FRAME_KEY = "_rootFrame_";
function executor(opts, _ref) {
  let {
    observable
  } = _ref;
  const {
    json,
    comInstance,
    getComDef,
    env,
    ref,
    onError,
    logger,
    debug = false,
    _context = {
      debuggerPanel: {}
    },
    scenesOperate
  } = opts;
  const {
    id: jsonID,
    slot: UIRoot,
    coms: Coms = {},
    comsAutoRun: ComsAutoRun = {},
    cons: Cons = [],
    pinRels: PinRels = {},
    pinProxies: PinProxies = {},
    pinValueProxies: PinValueProxies = {},
    type: JsonType
  } = json;
  const _Env = env;
  const _Props = {};
  const _frameOutputProxy = {};
  const _exedJSCom = {};
  const _frameOutput = {};
  const _nextConsPinKeyMap = {};
  Object.keys(Cons).forEach(key => {
    const cons = Cons[key];
    const {
      startPinParentKey
    } = cons[0];
    if (startPinParentKey) {
      _nextConsPinKeyMap[startPinParentKey] = key;
    }
  });
  const _valueBarrier = {};
  const _timerPinWait = {};
  const _slotValue = {};
  const _variableRelationship = {};
  const _var = {};
  const _varSlotMap = {};
  const _slotDefMap = {};
  function _logOutputVal(type, content) {
    let isBreakpoint = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : false;
    if (type === "com") {
      const {
        com,
        pinHostId,
        val,
        fromCon,
        notifyAll,
        comDef,
        conId
      } = content;
      logOutputVal(com.title, comDef, pinHostId, val);
    } else if (type === "frame") {}
  }
  function _logInputVal(content) {
    let isBreakpoint = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : false;
    const {
      com,
      pinHostId,
      val,
      frameKey,
      finishPinParentKey,
      comDef,
      conId
    } = content;
    if (conId) {
      logInputVal(com.title, comDef, pinHostId, val);
    }
  }
  function exeCon(pInReg, nextScope, val, fromCon) {
    const proxyDesc = PinProxies[pInReg.comId + "-" + pInReg.pinId];
    let inReg = pInReg;
    if (proxyDesc) {
      const isFrameOutput = inReg.def?.namespace === "mybricks.core-comlib.frame-output";
      if (isFrameOutput) {
        inReg = {
          ...pInReg,
          type: proxyDesc.type,
          frameId: proxyDesc.frameId,
          pinId: proxyDesc.pinId,
          direction: "inner-input",
          comId: (pInReg.targetFrameKey || pInReg.frameKey).split("-")[0]
        };
      } else {
        _slotValue[`${proxyDesc.frameId}-${proxyDesc.pinId}`] = val;
        if (fromCon && fromCon.finishPinParentKey !== inReg.startPinParentKey) {
          return;
        }
        if (proxyDesc.type === "frame") {
          const comProps = getComProps(inReg.comId, nextScope);
          let myScope;
          myScope = {
            // id: nextScope?.id || uuid(10, 16),
            id: uuid(10, 16),
            frameId: proxyDesc.frameId,
            parent: nextScope,
            proxyComProps: comProps
            //current proxied component instance
          };
          const isFn = inReg.def.namespace === "mybricks.core-comlib.fn";
          if (isFn) {
            const {
              configs
            } = comProps.data;
            if (configs) {
              Object.entries(configs).forEach(_ref2 => {
                let [key, value] = _ref2;
                const {
                  frameId,
                  comId,
                  pinId
                } = proxyDesc;
                const idPre = comId ? `${comId}-${frameId}` : `${frameId}`;
                const cons = Cons[idPre + "-" + key];
                if (cons) {
                  exeCons({
                    logProps: null,
                    cons,
                    val: value,
                    curScope: myScope
                  });
                }
              });
            }
          }
          exeInputForFrame({
            options: proxyDesc,
            value: val,
            scope: myScope,
            comProps
          });
          if (!isFrameOutput) {
            exeForFrame({
              frameId: proxyDesc.frameId,
              scope: myScope
            });
          }
          return;
        }
      }
    }
    if (inReg.type === "com") {
      if (fromCon) {
        if (fromCon.finishPinParentKey === inReg.startPinParentKey) {
          exeInputForCom(inReg, val, nextScope);
        }
      } else {
        exeInputForCom(inReg, val, nextScope);
      }
    } else if (inReg.type === "frame") {
      if (fromCon) {
        if (fromCon.finishPinParentKey !== inReg.startPinParentKey) {
          return;
        }
      }
      if (inReg.comId && proxyDesc?.frameId !== jsonID) {
        if (inReg.direction === "inner-input") {
          const proxyFn = _frameOutputProxy[inReg.comId + "-" + inReg.frameId + "-" + (nextScope?.id ? nextScope.id + "-" : "") + inReg.pinId] || _frameOutputProxy[inReg.comId + "-" + inReg.frameId + "-" + (nextScope?.parent?.id ? nextScope.parent.id + "-" : "") + inReg.pinId] || _frameOutputProxy[inReg.frameKey + "-" + inReg.pinId];
          if (proxyFn) {
            proxyFn(val);
          }
        } else if (inReg.direction === "inner-output" && inReg.pinType === "joint") {
          const cons = Cons[inReg.comId + "-" + inReg.frameId + "-" + inReg.pinId];
          if (cons) {
            exeCons({
              logProps: null,
              cons,
              val
            });
          }
        }
      } else {
        const proxiedComProps = nextScope?.proxyComProps;
        if (proxiedComProps) {
          const outPin = proxiedComProps.outputs[inReg.pinId];
          if (outPin) {
            outPin(val, nextScope.parent);
            return;
          }
        }
        _frameOutput[inReg.pinId]?.(val);
      }
    } else {
      throw new Error(`尚未实现`);
    }
  }
  function exeCons(_ref3) {
    let {
      logProps,
      cons,
      val,
      curScope,
      fromCon,
      notifyAll,
      fromCom,
      isAutoRun
    } = _ref3;
    if (debug && JsonType !== "module") {
      cons.sort((a, b) => {
        if (a.isBreakpoint && !b.isBreakpoint) {
          return -1;
        } else if (!a.isBreakpoint && b.isBreakpoint) {
          return 1;
        } else {
          return 0;
        }
      });
    }
    cons.forEach(async inReg => {
      const {
        comId,
        pinId,
        pinType,
        timerPinInputId,
        frameKey
      } = inReg;
      const component = Coms[comId];
      if (fromCon) {
        if (fromCon.finishPinParentKey !== inReg.startPinParentKey) {
          return;
        }
      }
      if (debug && inReg.isIgnored) {
        return;
      }
      if (debug && JsonType !== "module" && _context.debuggerPanel?.hasBreakpoint(inReg)) {
        let hasLog = true;
        await _context.debuggerPanel?.wait(inReg, () => {
          hasLog = false;
          if (logProps) {
            logProps[1].conId = inReg.id;
            logProps && _logOutputVal(...logProps, true);
          }
        });
        if (hasLog && logProps) {
          logProps[1].conId = inReg.id;
          logProps && _logOutputVal(...logProps);
        }
      } else {
        logProps && _logOutputVal(...logProps);
      }
      if (pinType === "timer") {
        next({
          value: val,
          curScope,
          inReg,
          notifyAll,
          fromCon
        });
      } else {
        if (notifyAll) {
          const frameKey2 = inReg.frameKey;
          if (frameKey2 === ROOT_FRAME_KEY || isAutoRun) {
            callNext({
              pinId,
              value: val,
              component,
              curScope: null,
              comId,
              val,
              timerPinInputId,
              frameKey: frameKey2,
              inReg,
              notifyAll,
              fromCon
            });
          } else {
            const [comId2, slotId] = frameKey2.split("-");
            if (!_variableRelationship[frameKey2]) {
              const frameToComIdMap = _variableRelationship[frameKey2] = {};
              frameToComIdMap[fromCom.id] = {
                [inReg.id]: inReg
              };
            } else {
              const frameToComIdMap = _variableRelationship[frameKey2];
              const consMap = frameToComIdMap[fromCom.id];
              if (!consMap) {
                frameToComIdMap[fromCom.id] = {
                  [inReg.id]: inReg
                };
              } else {
                consMap[inReg.id] = inReg;
              }
            }
            if (fromCom.parentComId) {
              callNext({
                pinId,
                value: val,
                component,
                curScope,
                comId: comId2,
                val,
                timerPinInputId,
                frameKey: frameKey2,
                inReg,
                notifyAll,
                fromCon
              });
            } else {
              const frameProps = _Props[`${comId2}-${slotId}`];
              if (frameProps) {
                const entries = Object.entries(frameProps);
                const length = entries.length;
                entries.forEach(_ref4 => {
                  let [key, slot] = _ref4;
                  if (length > 1 && key === "slot") {} else {
                    if (slot?.type === "scope") {
                      if (!slot.curScope) {
                        slot.pushTodo(curScope2 => {
                          callNext({
                            pinId,
                            value: val,
                            component,
                            curScope: curScope2,
                            comId: comId2,
                            val,
                            timerPinInputId,
                            frameKey: frameKey2,
                            inReg,
                            notifyAll,
                            fromCon
                          });
                        });
                      } else {
                        callNext({
                          pinId,
                          value: val,
                          component,
                          curScope: slot.curScope,
                          comId: comId2,
                          val,
                          timerPinInputId,
                          frameKey: frameKey2,
                          inReg,
                          notifyAll,
                          fromCon
                        });
                      }
                    } else {
                      callNext({
                        pinId,
                        value: val,
                        component,
                        curScope: slot.curScope,
                        comId: comId2,
                        val,
                        timerPinInputId,
                        frameKey: frameKey2,
                        inReg,
                        notifyAll,
                        fromCon
                      });
                    }
                  }
                });
              }
            }
          }
        } else {
          callNext({
            pinId,
            value: val,
            component,
            curScope,
            comId,
            val,
            timerPinInputId,
            frameKey,
            inReg,
            notifyAll,
            fromCon
          });
        }
      }
    });
  }
  function next(_ref5) {
    let {
      pinId,
      value,
      curScope,
      inReg,
      notifyAll,
      fromCon
    } = _ref5;
    let nextScope = curScope;
    const finalInReg = pinId ? {
      ...inReg,
      pinId
    } : inReg;
    if (notifyAll) {
      const frameKey = finalInReg.frameKey;
      if (!frameKey) {
        throw new Error(`数据异常，请检查toJSON结果.`);
      }
      if (frameKey === ROOT_FRAME_KEY) {
        exeCon(finalInReg, {}, value, fromCon);
      } else {
        exeCon(finalInReg, curScope, value, fromCon);
      }
    } else {
      const ary = finalInReg.frameKey.split("-");
      if (ary.length >= 2 && !nextScope) {
        const slotProps = getSlotProps(ary[0], ary[1], null, false);
        if (slotProps?.type === "scope") {
          if (!slotProps.curScope) {
            slotProps.pushTodo(curScope2 => {
              exeCon(finalInReg, curScope2, value, fromCon);
            });
          } else {
            exeCon(finalInReg, slotProps.curScope, value, fromCon);
          }
        } else {
          exeCon(finalInReg, nextScope, value, fromCon);
        }
      } else {
        exeCon(finalInReg, nextScope, value, fromCon);
      }
    }
  }
  function callNext(_ref6) {
    let {
      pinId,
      value,
      component,
      curScope,
      comId,
      val,
      timerPinInputId,
      frameKey,
      inReg,
      notifyAll,
      fromCon
    } = _ref6;
    const {
      isReady,
      isMultipleInput,
      pinId: realPinId,
      value: realValue,
      cb
    } = transformInputId({
      pinId,
      value,
      component,
      curScope,
      comId,
      val
    });
    if (isReady) {
      const nextProps = {
        pinId: isMultipleInput ? realPinId : null,
        value: realValue,
        curScope,
        inReg,
        notifyAll,
        fromCon
      };
      if (timerPinInputId) {
        const timerKey = timerPinInputId + "-" + frameKey + (curScope?.id ? `-${curScope.id}` : "");
        const timerWaitInfo = _timerPinWait[timerKey];
        if (timerWaitInfo) {
          const {
            ready,
            todo
          } = timerWaitInfo;
          if (ready) {
            let hasSameFn = false;
            Object.entries(todo).forEach(_ref7 => {
              let [key, todoFn] = _ref7;
              if (key === realPinId) {
                next(nextProps);
                hasSameFn = true;
              } else {
                todoFn();
              }
            });
            if (!hasSameFn) {
              next(nextProps);
            }
            cb?.();
            Reflect.deleteProperty(_timerPinWait, timerKey);
          } else {
            todo[realPinId] = () => {
              cb?.();
              next(nextProps);
            };
          }
        } else {
          _timerPinWait[timerKey] = {
            ready: false,
            todo: {
              [realPinId]: () => {
                cb?.();
                next(nextProps);
              }
            }
          };
        }
      } else {
        cb?.();
        next(nextProps);
      }
    }
  }
  function transformInputId(_ref8) {
    let {
      pinId,
      value,
      component,
      curScope,
      comId,
      val
    } = _ref8;
    const pidx = pinId.indexOf(".");
    const result = {
      pinId,
      value,
      isReady: true,
      isMultipleInput: false,
      cb: null
    };
    if (component && pidx !== -1) {
      const valueBarrierKey = component.id + `${curScope?.id ? `-${curScope.id}` : ""}`;
      const {
        inputs
      } = component;
      const finalPinId = pinId.substring(0, pidx);
      result.pinId = finalPinId;
      const paramId = pinId.substring(pidx + 1);
      let barrier = _valueBarrier[valueBarrierKey];
      if (!barrier) {
        barrier = _valueBarrier[valueBarrierKey] = {};
      }
      barrier[paramId] = val;
      const regExp = new RegExp(`${finalPinId}.`);
      const allPins = inputs.filter(pin => {
        return !!pin.match(regExp);
      });
      if (Object.keys(barrier).length === allPins.length) {
        result.value = barrier;
        result.isMultipleInput = true;
        result.cb = () => {
          Reflect.deleteProperty(_valueBarrier, valueBarrierKey);
        };
      } else {
        result.isReady = false;
      }
    }
    return result;
  }
  function getComProps(comId, scope) {
    const com = Coms[comId];
    if (!com) return null;
    const comInFrameId = comId + (com.frameId || ROOT_FRAME_KEY);
    let frameProps = _Props[comInFrameId];
    if (!frameProps) {
      frameProps = _Props[comInFrameId] = {};
    }
    let storeScopeId;
    let curScope = scope;
    if (!curScope && com.parentComId && com.frameId) {
      curScope = _Props[`${com.parentComId}-${com.frameId}`]?.slot?.curScope;
    }
    while (curScope) {
      const key2 = curScope.id + "-" + comId;
      if (curScope.frameId === com.frameId) {
        storeScopeId = curScope.id;
        const found2 = frameProps[key2];
        if (found2) {
          return found2;
        } else {
          const parentComId = curScope.parentComId;
          if (parentComId) {
            if (parentComId === com.paramId || parentComId === com.parentComId) {
              break;
            }
          } else {
            break;
          }
        }
      }
      curScope = curScope.parent;
    }
    const key = (storeScopeId ? storeScopeId + "-" : "") + comId;
    const found = frameProps[key];
    if (found) {
      return found;
    }
    const def = com.def;
    const model = com.model;
    const modelData = JSON.parse(JSON.stringify(model.data));
    const modelStyle = JSON.parse(JSON.stringify(model.style));
    modelStyle.__model_style__ = true;
    const inputRegs = {};
    const inputTodo = {};
    const _inputRegs = {};
    const _inputTodo = {};
    const addInputTodo = (inputId, val, fromCon, fromScope) => {
      let ary = inputTodo[inputId];
      if (!ary) {
        inputTodo[inputId] = ary = [];
      }
      ary.push({
        val,
        fromCon,
        fromScope
      });
    };
    const inputs = function (ioProxy) {
      return new Proxy({}, {
        ownKeys(target) {
          return com.inputs;
        },
        getOwnPropertyDescriptor(k) {
          return {
            enumerable: true,
            configurable: true
          };
        },
        get(target, name) {
          return function (fn) {
            if (Object.prototype.toString.call(name) === "[object Symbol]") {
              return;
            }
            const proxiedInputs = ioProxy?.inputs;
            if (proxiedInputs) {
              const proxy = proxiedInputs[name];
              if (typeof proxy === "function") {
                proxy(fn);
              }
            }
            inputRegs[name] = fn;
            const ary = inputTodo[name];
            if (ary) {
              ary.forEach(_ref9 => {
                let {
                  val,
                  fromCon,
                  fromScope
                } = _ref9;
                fn(val, new Proxy({}, {
                  //relOutputs
                  get(target2, name2) {
                    return function (val2) {
                      if (Object.prototype.toString.call(name2) === "[object Symbol]") {
                        return;
                      }
                      const fn2 = outputs()[name2];
                      if (typeof fn2 === "function") {
                        fn2(val2, fromScope || curScope, fromCon);
                      } else {
                        throw new Error(`outputs.${name2} not found`);
                      }
                    };
                  }
                }));
              });
              inputTodo[name] = void 0;
            }
          };
        }
      });
    };
    const inputsCallable = new Proxy({}, {
      get(target, name) {
        return function (val) {
          if (Object.prototype.toString.call(name) === "[object Symbol]") {
            return;
          }
          const rels = PinRels[comId + "-" + name];
          if (rels) {
            const rtn2 = {};
            const reg = {};
            rels.forEach(relId => {
              rtn2[relId] = proFn => {
                reg[relId] = proFn;
              };
            });
            Promise.resolve().then(() => {
              const inReg = {
                comId,
                def,
                pinId: name
              };
              exeInputForCom(inReg, val, scope, reg);
            });
            return rtn2;
          } else {
            const inReg = {
              comId,
              def,
              pinId: name
            };
            exeInputForCom(inReg, val, scope);
          }
        };
      }
    });
    const _inputsCallable = new Proxy({}, {
      get(target, name) {
        return function (val) {
          if (Object.prototype.toString.call(name) === "[object Symbol]") {
            return;
          }
          const proxyDesc = PinProxies[comId + "-" + name];
          if (proxyDesc) {
            scenesOperate?.inputs({
              ...proxyDesc,
              value: val,
              parentScope: rtn
            });
          }
        };
      }
    });
    const outputs = function (ioProxy) {
      return new Proxy({}, {
        ownKeys(target) {
          return com.outputs;
        },
        getOwnPropertyDescriptor(k) {
          return {
            enumerable: true,
            configurable: true
          };
        },
        get(target, name, receiver) {
          const exe = function (val, _myScope, fromCon, isCurrent) {
            if (Object.prototype.toString.call(name) === "[object Symbol]") {
              return;
            }
            const notifyAll = typeof _myScope === "boolean" && _myScope;
            if (notifyAll) {
              if (com.parentComId) {
                const key2 = `${com.parentComId}-${com.frameId}`;
                if (!_varSlotMap[key2]) {
                  _varSlotMap[key2] = {
                    [comId]: true
                  };
                } else {
                  _varSlotMap[key2][comId] = true;
                }
              }
              _var[`${com.id}${scope?.id ? `-${scope.id}` : ""}`] = val;
              if (com.global && !isCurrent) {
                scenesOperate?.exeGlobalCom({
                  com,
                  value: val,
                  pinId: name
                });
                return;
              }
            }
            const args = arguments;
            const proxiedOutputs = ioProxy?.outputs;
            if (proxiedOutputs) {
              const proxy = proxiedOutputs[name];
              if (typeof proxy === "function") {
                proxy(val);
              }
            }
            let myScope;
            if (_myScope && typeof _myScope === "object") {
              myScope = _myScope;
            }
            const comDef = getComDef(def);
            if (!comDef) return;
            const evts = model.outputEvents;
            let cons;
            if (evts) {
              const eAry = evts[name];
              if (eAry && Array.isArray(eAry)) {
                const activeEvt = eAry.find(e => e.active);
                if (activeEvt) {
                  const {
                    type
                  } = activeEvt;
                  switch (type) {
                    case "none":
                      cons = [];
                      break;
                    case "fx":
                      const proxyDesc = PinProxies[comId + "-" + name];
                      if (proxyDesc?.type === "frame") {
                        const key2 = `${proxyDesc.frameId}-${proxyDesc.pinId}`;
                        cons = Cons[key2] || [];
                        _slotValue[key2] = val;
                      } else {
                        cons = [];
                      }
                      break;
                    case "defined":
                      break;
                    default:
                      cons = [];
                      if (Array.isArray(env?.events)) {
                        const def2 = env.events.find(ce => {
                          if (ce.type === type) {
                            return ce;
                          }
                        });
                        if (def2 && typeof def2.exe === "function") {
                          def2.exe({
                            options: activeEvt.options
                          });
                        }
                      }
                      break;
                  }
                }
              }
            }
            cons = cons || Cons[comId + "-" + name];
            if (cons?.length) {
              if (args.length >= 3 && typeof isCurrent === "undefined") {
                exeCons({
                  logProps: ["com", {
                    com,
                    pinHostId: name,
                    val,
                    fromCon,
                    notifyAll,
                    comDef
                  }],
                  cons,
                  val,
                  curScope: myScope,
                  fromCon,
                  fromCom: com
                });
              } else {
                exeCons({
                  logProps: ["com", {
                    com,
                    pinHostId: name,
                    val,
                    fromCon,
                    notifyAll,
                    comDef
                  }],
                  cons,
                  val,
                  curScope: myScope || scope,
                  fromCon,
                  notifyAll,
                  fromCom: com
                });
              }
            } else {
              _logOutputVal("com", {
                com,
                pinHostId: name,
                val,
                fromCon,
                notifyAll,
                comDef
              });
            }
          };
          exe.getConnections = () => {
            return Cons[comId + "-" + name] || [];
          };
          return exe;
        }
      });
    };
    const _inputs = new Proxy({}, {
      get(target, name, receiver) {
        return function (fn) {
          if (Object.prototype.toString.call(name) === "[object Symbol]") {
            return;
          }
          _inputRegs[name] = fn;
          const ary = _inputTodo[name];
          if (ary) {
            ary.forEach(val => {
              fn(val);
            });
            _inputTodo[name] = void 0;
          }
        };
      }
    });
    const _outputs = new Proxy({}, {
      get(target, name, receiver) {
        return function (val) {
          if (Object.prototype.toString.call(name) === "[object Symbol]") {
            return;
          }
          const cons = Cons[comId + "-" + name];
          if (cons) {
            exeCons({
              logProps: ["com", {
                com,
                pinHostId: name,
                val,
                comDef: def
              }],
              cons,
              val,
              curScope: scope
            });
          } else {
            _logOutputVal("com", {
              com,
              pinHostId: name,
              val,
              comDef: def
            });
          }
        };
      }
    });
    function _notifyBindings(val) {
      if (com.global) {
        scenesOperate?._notifyBindings(val, com);
        return;
      }
      const {
        bindingsTo
      } = com.model;
      if (bindingsTo) {
        for (let comId2 in bindingsTo) {
          const com2 = getComProps(comId2);
          if (com2) {
            const bindings = bindingsTo[comId2];
            if (Array.isArray(bindings)) {
              bindings.forEach(binding => {
                let nowObj = com2;
                const ary = binding.split(".");
                ary.forEach((nkey, idx) => {
                  if (idx !== ary.length - 1) {
                    nowObj = nowObj[nkey];
                  } else {
                    nowObj[nkey] = val;
                  }
                });
              });
            }
          }
        }
      }
    }
    const isJS = def.rtType?.match(/^js/gi);
    const rtn = {
      id: com.id,
      title: com.title,
      frameId: com.frameId,
      parentComId: com.parentComId,
      data: isJS ? modelData : observable(modelData),
      style: isJS ? modelStyle : observable(modelStyle),
      _inputRegs: inputRegs,
      addInputTodo,
      inputs: inputs(),
      inputsCallable,
      _inputsCallable,
      outputs: outputs(),
      _inputs,
      _outputs,
      clone(ioProxy) {
        const rtn2 = {
          inputs: inputs(ioProxy),
          outputs: outputs(ioProxy)
        };
        Object.setPrototypeOf(rtn2, this);
        return rtn2;
      },
      _notifyBindings,
      logger,
      onError
    };
    frameProps[key] = rtn;
    return rtn;
  }
  function getSlotValue(key, scope) {
    let val = _slotValue[`${key}${scope ? `-${scope.id}-${scope.frameId}` : ""}`];
    if (typeof val === "undefined" && scope?.parent) {
      val = getSlotValue(key, scope.parent);
    }
    return easyClone(val);
  }
  function exeInputForCom(inReg, val, scope, outputRels) {
    const {
      comId,
      def,
      pinId,
      pinType,
      frameKey,
      finishPinParentKey,
      timerPinInputId,
      targetFrameKey
    } = inReg;
    if (pinType === "ext") {
      const props = _Props[comId] || getComProps(comId, scope);
      if (pinId === "show") {
        props.style.display = "";
      } else if (pinId === "hide") {
        props.style.display = "none";
      } else if (pinId === "showOrHide") {
        const sty = props.style;
        if (typeof val === "undefined") {
          if (sty.display === "none") {
            sty.display = "";
          } else {
            sty.display = "none";
          }
        } else {
          sty.display = val ? "" : "none";
        }
      }
      const comDef = getComDef(def);
      if (!comDef) return;
      _logInputVal({
        com: props,
        val,
        pinHostId: pinId,
        frameKey,
        finishPinParentKey,
        comDef,
        conId: inReg.id
      });
    } else if (pinType === "config") {
      const props = getComProps(comId, scope);
      const comDef = getComDef(def);
      if (!comDef) return;
      _logInputVal({
        com: props,
        pinHostId: pinId,
        val,
        frameKey,
        finishPinParentKey,
        comDef,
        conId: inReg.id
      });
      const {
        extBinding
      } = inReg;
      const ary = extBinding.split(".");
      let nowObj = props;
      ary.forEach((nkey, idx) => {
        if (idx !== ary.length - 1) {
          nowObj = nowObj[nkey];
        } else {
          nowObj[nkey] = val;
        }
      });
    } else if (pinType === "timer") {
      const props = getComProps(comId, scope);
      const comDef = getComDef(def);
      if (!comDef) return;
      _logInputVal({
        com: props,
        pinHostId: pinId,
        val,
        frameKey,
        finishPinParentKey,
        comDef,
        conId: inReg.id
      });
      const timerKey = timerPinInputId + "-" + frameKey + (scope?.id ? `-${scope.id}` : "");
      const timerWaitInfo = _timerPinWait[timerKey];
      if (timerWaitInfo) {
        const {
          todo
        } = timerWaitInfo;
        Object.entries(todo).forEach(_ref10 => {
          let [_, fn] = _ref10;
          return fn();
        });
        Reflect.deleteProperty(_timerPinWait, timerKey);
      } else {
        _timerPinWait[timerKey] = {
          ready: true,
          todo: {}
        };
      }
    } else {
      if (def.rtType?.match(/^js/gi)) {
        const jsCom = Coms[comId];
        if (jsCom) {
          const props = getComProps(comId, scope);
          const comDef = getComDef(def);
          if (!comDef) return;
          if (jsCom.global) {
            const globalProps = scenesOperate?.getGlobalComProps(comId);
            if (globalProps) {
              props.data = globalProps.data;
            }
          }
          const scopeId = scope?.id;
          const myId = (scopeId ? scopeId + "-" : "") + comId;
          if (jsCom.inputs.find(inputId => inputId === pinId)) {
            _logInputVal({
              com: jsCom,
              val,
              pinHostId: pinId,
              frameKey,
              finishPinParentKey,
              comDef,
              conId: inReg.id
            });
          } else {
            Object.entries(val).forEach(_ref11 => {
              let [key, value] = _ref11;
              _logInputVal({
                com: jsCom,
                val: value,
                pinHostId: `${pinId}.${key}`,
                frameKey,
                finishPinParentKey,
                comDef,
                conId: inReg.id
              });
            });
          }
          if (!_exedJSCom[myId]) {
            _exedJSCom[myId] = true;
            if (typeof comInstance?.[comId] === "function") {
              comInstance[comId]({
                //exe once
                id: comId,
                env: _Env,
                data: props.data,
                inputs: props.inputs,
                outputs: props.outputs,
                _notifyBindings: props._notifyBindings,
                _inputsCallable: props._inputsCallable,
                logger,
                onError
              });
            } else {
              comDef.runtime({
                //exe once
                id: comId,
                env: _Env,
                data: props.data,
                inputs: props.inputs,
                outputs: props.outputs,
                _notifyBindings: props._notifyBindings,
                _inputsCallable: props._inputsCallable,
                logger,
                onError
              });
            }
          }
          const fn = props._inputRegs[pinId];
          if (typeof fn === "function") {
            fn(val, new Proxy({}, {
              //relOutputs
              get(target, name) {
                return function (val2) {
                  if (Object.prototype.toString.call(name) === "[object Symbol]") {
                    return;
                  }
                  if (PinValueProxies) {
                    const pinValueProxy = PinValueProxies[`${comId}-${pinId}`];
                    if (pinValueProxy) {
                      const frameId = pinValueProxy.frameId;
                      const slotValueKey = `${frameId === json.id ? ROOT_FRAME_KEY : targetFrameKey || frameKey}-${pinValueProxy.pinId}`;
                      val2 = getSlotValue(slotValueKey, scope);
                      if (typeof val2 === "undefined") {
                        val2 = getSlotValue(slotValueKey, null);
                      }
                    }
                  }
                  props.outputs[name](val2, scope, inReg);
                };
              }
            }));
          }
        }
      } else {
        const props = getComProps(comId, scope);
        if (!props) {
          return;
        }
        const comDef = getComDef(def);
        if (!comDef) return;
        _logInputVal({
          com: props,
          pinHostId: pinId,
          val,
          frameKey,
          finishPinParentKey,
          comDef,
          conId: inReg.id
        });
        const fn = props._inputRegs[pinId];
        if (typeof fn === "function") {
          let nowRels;
          if (outputRels) {
            nowRels = outputRels;
          } else {
            nowRels = new Proxy({}, {
              //relOutputs
              get(target, name) {
                return function (val2) {
                  if (Object.prototype.toString.call(name) === "[object Symbol]") {
                    return;
                  }
                  props.outputs[name](val2, scope, inReg);
                };
              }
            });
          }
          fn(val, nowRels);
        } else {
          props.addInputTodo(pinId, val, inReg, scope);
        }
      }
    }
    if (finishPinParentKey) {
      const cons = Cons[_nextConsPinKeyMap[finishPinParentKey]];
      if (cons && !PinRels[`${comId}-${pinId}`]) {
        exeCons({
          logProps: null,
          cons,
          val: void 0
        });
      }
    }
  }
  function searchComInSlot(slot, comId) {
    let result;
    if (slot?.comAry) {
      slot.comAry.find(com => {
        if (com.id === comId) {
          result = com;
          return com;
        }
        if (com.slots) {
          for (let id in com.slots) {
            result = searchComInSlot(com.slots[id], comId);
            if (result) {
              return result;
            }
          }
        }
      });
    }
    return result;
  }
  function getSlotProps(comId, slot, scope, notifyAll) {
    const hasSlotDef = typeof slot === "string" ? false : true;
    const slotId = hasSlotDef ? slot.id : slot;
    const slotKey = `${comId}-${slotId}`;
    let frameProps = _Props[slotKey];
    if (!frameProps) {
      frameProps = _Props[slotKey] = {};
    }
    let key = scope ? scope.id : "slot";
    let rtn = frameProps[key];
    if (notifyAll && !rtn) {
      console.log("不应该再走到这儿了: ", {
        comId,
        slotId,
        scope,
        notifyAll
      });
    }
    if (!rtn) {
      let slotDef = hasSlotDef ? slot : _slotDefMap[`${comId}-${slotId}`];
      if (!slotDef) {
        const foundCom = searchComInSlot(UIRoot, comId);
        if (!foundCom?.slots) {
          return null;
        }
        slotDef = foundCom?.slots[slotId];
      }
      const _inputRegs = {};
      let todo = void 0;
      if (scope) {
        const errorPorps = _Props[comId + "-" + slotId];
        if (errorPorps) {
          todo = errorPorps.todo;
        }
      }
      const Cur = {
        scope,
        todo
      };
      const _inputs = new Proxy({}, {
        get(target, name) {
          return function (fn) {
            if (Object.prototype.toString.call(name) === "[object Symbol]") {
              return;
            }
            _inputRegs[name] = fn;
          };
        }
      });
      const inputs = new Proxy({}, {
        get(target, name) {
          const exe = function (val, curScope) {
            if (Object.prototype.toString.call(name) === "[object Symbol]") {
              return;
            }
            const key2 = comId + "-" + slotId + "-" + name;
            const cons = Cons[key2];
            _slotValue[`${key2}${curScope ? `-${curScope.id}-${curScope.frameId}` : ""}`] = val;
            if (cons) {
              exeCons({
                logProps: ["frame", {
                  comId,
                  frameId: slotId,
                  pinHostId: name,
                  val
                }],
                cons,
                val,
                curScope: curScope || Cur.scope
              });
            } else {
              _logOutputVal("frame", {
                comId,
                frameId: slotId,
                pinHostId: name,
                val
              });
            }
          };
          exe.getConnections = () => {
            return Cons[comId + "-" + slotId + "-" + name] || [];
          };
          return exe;
        }
      });
      const outputs = new Proxy({}, {
        get(target, name, receiver) {
          return function (fn) {
            if (Object.prototype.toString.call(name) === "[object Symbol]") {
              return;
            }
            _frameOutputProxy[`${comId}-${slotId}-${scope?.id}-${name}`] = fn;
            _frameOutputProxy[`${comId}-${slotId}-${scope?.parent?.id}-${name}`] = fn;
            _frameOutputProxy[key + "-" + name] = fn;
            _frameOutputProxy[slotKey + "-" + name] = fn;
          };
        }
      });
      let runExed = {};
      rtn = frameProps[key] = {
        type: slotDef?.type,
        run(newScope) {
          let scope2 = Cur.scope;
          if (newScope && scope2 !== newScope) {
            Cur.scope = newScope;
            scope2 = newScope;
          }
          const scopeId = scope2?.id || "none";
          if (!runExed[scopeId]) {
            runExed[scopeId] = true;
            exeForFrame({
              comId,
              frameId: slotId,
              scope: scope2
            });
          }
          if (Array.isArray(Cur.todo)) {
            Cur.todo.forEach(fn => {
              Promise.resolve().then(() => {
                fn(scope2);
              });
            });
            Cur.todo = void 0;
          }
          if (scope2 && key !== "slot") {
            const frameKey = `${comId}-${slotId}`;
            const frameToComIdMap = _variableRelationship[frameKey];
            Promise.resolve().then(() => {
              if (frameToComIdMap) {
                Object.entries(frameToComIdMap).forEach(_ref12 => {
                  let [comId2, consMap] = _ref12;
                  const fromCom = Coms[comId2];
                  if (!fromCom.parentComId) {
                    const cons = Object.entries(consMap).map(_ref13 => {
                      let [key2, con] = _ref13;
                      return con;
                    });
                    if (cons.length) {
                      exeCons({
                        logProps: null,
                        cons,
                        val: _var[comId2],
                        curScope: scope2,
                        notifyAll: true,
                        fromCom: Coms[comId2],
                        isAutoRun: true
                      });
                    }
                  }
                });
              }
            });
          }
        },
        destroy() {
          if (scope) {
            const frameKey = `${scope.parentComId}-${scope.frameId}`;
            const slotMap = _varSlotMap[frameKey];
            if (slotMap) {
              Object.keys(slotMap).forEach(key2 => {
                Reflect.deleteProperty(_var, `${key2}-${scope.id}`);
              });
            }
          }
          Reflect.deleteProperty(frameProps, key);
        },
        //_outputRegs,
        _inputs,
        _inputRegs,
        inputs,
        outputs,
        get curScope() {
          return Cur.scope;
        },
        setCurScope(scope2) {
          Cur.scope = scope2;
        },
        get todo() {
          return Cur.todo;
        },
        pushTodo(fn) {
          if (!Cur.todo) {
            Cur.todo = [];
          }
          Cur.todo.push(fn);
        },
        setSlotValue(slotValues, curScope) {
          const scope2 = curScope || Cur.scope;
          Object.entries(slotValues).forEach(_ref14 => {
            let [name, value] = _ref14;
            const key2 = comId + "-" + slotId + "-" + name;
            _slotValue[`${key2}${scope2 ? `-${scope2.id}-${scope2.frameId}` : ""}`] = value;
          });
        }
      };
    }
    return rtn;
  }
  function exeForFrame(opts2) {
    const {
      comId,
      frameId,
      scope
    } = opts2;
    const idPre = comId ? `${comId}-${frameId}` : `${frameId}`;
    const autoAry = ComsAutoRun[idPre];
    if (autoAry) {
      autoAry.forEach(com => {
        const {
          id,
          def
        } = com;
        const jsCom = Coms[id];
        if (jsCom) {
          const props = getComProps(id, scope);
          const comDef = getComDef(def);
          if (!comDef) return;
          log(`${comDef.namespace} 开始执行`);
          if (typeof comInstance?.[id] === "function") {
            comInstance[id]({
              id,
              env: _Env,
              data: props.data,
              inputs: props.inputs,
              outputs: props.outputs,
              _inputsCallable: props._inputsCallable,
              logger,
              onError
            });
          } else {
            comDef.runtime({
              id,
              env: _Env,
              data: props.data,
              inputs: props.inputs,
              outputs: props.outputs,
              _inputsCallable: props._inputsCallable,
              logger,
              onError
            });
          }
        }
      });
    }
  }
  function exeInputForFrame(_ref15) {
    let {
      options,
      value,
      scope = void 0,
      log: log2 = true,
      comProps
    } = _ref15;
    const {
      frameId,
      comId,
      pinId,
      sceneId
    } = options;
    const idPre = comId ? `${comId}-${frameId}` : `${frameId}`;
    const cons = Cons[idPre + "-" + pinId];
    _slotValue[`${frameId}-${pinId}`] = value;
    if (cons) {
      exeCons({
        logProps: ["frame", {
          comId,
          frameId,
          pinHostId: pinId,
          val: value,
          sceneId
        }],
        cons,
        val: value,
        curScope: scope
      });
    } else {
      if (log2) {
        _logOutputVal("frame", {
          comId,
          frameId,
          pinHostId: pinId,
          val: value,
          sceneId
        });
      }
      if (frameId !== ROOT_FRAME_KEY) {
        if (json.id === frameId) {
          _frameOutput[pinId](value);
        } else {
          scenesOperate?.open({
            frameId,
            todo: {
              pinId,
              value
            },
            comProps,
            parentScope: scope.proxyComProps
          });
        }
      }
    }
  }
  const rst = {
    get(_ref16) {
      let {
        comId,
        slotId,
        slot,
        scope,
        _ioProxy
      } = _ref16;
      let ioProxy;
      if (_ioProxy && (_ioProxy.inputs || _ioProxy.outputs || _ioProxy._inputs || _ioProxy._outputs)) {
        ioProxy = _ioProxy;
      }
      if (slotId) {
        if (slot) {
          _slotDefMap[`${comId}-${slotId}`] = slot;
        }
        return getSlotProps(comId, slotId, scope);
      } else {
        const rtn = getComProps(comId, scope);
        if (ioProxy) {
          return rtn.clone(ioProxy);
        } else {
          return rtn;
        }
      }
    },
    getComInfo(id) {
      return Coms[id];
    }
  };
  if (typeof ref === "function") {
    const refs = {
      run() {
        exeForFrame({
          frameId: ROOT_FRAME_KEY
        });
      },
      inputs: new Proxy({}, {
        get(target, pinId) {
          return function (val) {
            let sceneId = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : void 0;
            let log2 = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : true;
            if (Object.prototype.toString.call(pinId) === "[object Symbol]") {
              return;
            }
            exeInputForFrame({
              options: {
                frameId: ROOT_FRAME_KEY,
                pinId,
                sceneId
              },
              value: val,
              scope: void 0,
              log: log2
            });
          };
        }
      }),
      outputs(id, fn) {
        _frameOutput[id] = fn;
      },
      get: rst.get,
      getComInfo: rst.getComInfo
    };
    ref(refs);
  }
  return rst;
}

export { executor as default };
//# sourceMappingURL=executor.js.map
