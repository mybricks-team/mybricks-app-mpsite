// @ts-nocheck
import { temporarilyNotSupport } from '../utils'

// 无障碍
export const checkIsOpenAccessibility = /* @__PURE__ */ temporarilyNotSupport('checkIsOpenAccessibility')
