const _injectConfig = {
  status: {
    fileId: 685536211546181,
    apiEnv: "prod",
    serviceDomain: "http://localhost:8080",
    serviceFx: {
      env: "prod"
    }
  },
  routeMap: {
    u_NFEBq: {
      path: "/pages/u_NFEBq/index",
      isTabbar: false
    },
    u_wrtYl: {
      path: "/pages/u_wrtYl/index",
      isTabbar: false
    }
  },
  scenes: [{
    id: "u_NFEBq"
  }, {
    id: "u_wrtYl"
  }],
  fxFrames: [],
  globalVarMap: {}
};

export { _injectConfig as default };
//# sourceMappingURL=root-config.js.map
