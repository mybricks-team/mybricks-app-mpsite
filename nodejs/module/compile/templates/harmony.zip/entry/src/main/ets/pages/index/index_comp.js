import { useState, useRef } from '../../npm/react';
import Taro from '../../npm/@tarojs/taro';
import './comDefs.js';
import { getGlobalData, parsePakoJson } from '../../utils.js';
import { polyfillCoreComlib } from '../../app/utils/polyfill-core-comlib.js';
import injectPageConfig from './mybricks/page-config.js';
import pageFx from './mybricks/page-fx.js';
import pageCode from './mybricks/page-code.js';
import '../../style.less.xss.js';
import comDefs from '../../components/comDefs.js';

const app = getGlobalData();
const shareConfig = {
  message: null,
  timeline: null
};
const setShareConfig = (type, value) => {
  shareConfig[type] = value;
};
const component = () => {
  const [isReady, setIsReady] = useState(false);
  const [router] = useState(Taro.getCurrentInstance().router);
  const ioRefs = useRef(null);
  const isShowedRef = useRef(false);
  let toJson, pageConfig;
  const sceneId = router.path.split("/").reverse()[1];
  if ("harmony" === "h5") {
    toJson = injectPageConfig[sceneId]?.pageToJson;
    pageConfig = injectPageConfig[sceneId]?.pageConfig;
  } else if ("harmony" === "harmony") {
    toJson = injectPageConfig.toJson;
  } else {
    const injectPageConfigParsed = parsePakoJson(injectPageConfig);
    toJson = injectPageConfigParsed.toJson;
  }
  Taro.useLoad(() => {
    app.h.render(JSON.parse(pageFx || "{}").pageOnLoad || {}, {
      comDefs: polyfillCoreComlib(comDefs),
      comInstance: pageCode,
      ref: refs => {
        refs.outputs("next", val => {
          console.log("next", val);
          setIsReady(true);
        });
        refs.inputs["onLoad"]({
          id: "",
          path: "",
          query: {}
        });
        refs.run();
      },
      setShareConfig
    });
  });
  Taro.useDidShow(() => {
    if (!isShowedRef.current) {
      isShowedRef.current = true;
      return;
    }
    Taro.eventCenter.trigger("pageDidShow", {
      path: router.path || "",
      query: fixRouterAndDecodeParams(router.params || {})
    });
  });
  Taro.useDidHide(() => {
    Taro.eventCenter.trigger("pageDidHide", {
      path: router.path || "",
      query: fixRouterAndDecodeParams(router.params || {})
    });
  });
  Taro.useUnload(() => {
    app.h.destroy?.(sceneId);
  });
  Taro.useShareAppMessage(() => {
    if (shareConfig.message) {
      return shareConfig.message;
    }
  });
  if ("harmony" === "h5") {
    console.warn(`useLoad [pageConfig]`, pageConfig?.navigationBarTitleText);
    if (pageConfig?.navigationBarTitleText) {
      Taro.setNavigationBarTitle({
        title: pageConfig.navigationBarTitleText
      });
    }
  }
  let jsx = app.h.render(toJson, {
    comDefs: polyfillCoreComlib(comDefs),
    comInstance: pageCode,
    ref: refs => {
      if (ioRefs.current) {
        return;
      }
      ioRefs.current = refs;
      try {
        let value = Taro.getCurrentInstance()?.router?.params || {};
        if (value.params) {
          try {
            let params = decodeURIComponent(value.params);
            let rule = typeof params === "string" && params.indexOf("{") === 0 && params.indexOf("}") === params.length - 1;
            if (rule) {
              value = JSON.parse(params);
            } else {}
          } catch (e) {}
        }
        let result = fixRouterAndDecodeParams(value);
        if (result.mb_key) {
          result = result.mb_key;
        }
        console.log(`%c [render-mpsite] %c 页面打开 ${sceneId} | open -> ${safaParse(result)}`, "color:white;background-color:green", "color:white;background-color:black");
        refs?.inputs["open"]?.(result);
      } catch (e) {
        console.error("open", e);
        refs?.inputs["open"]?.({});
      }
    },
    setShareConfig
  });
  let pageOnLoad = JSON.parse(pageFx || "{}")?.pageOnLoad || {};
  let cons = pageOnLoad.cons || {};
  if (cons["_rootFrame_-onLoad"]?.length && !isReady) {
    return null;
  }
  return jsx;
};
function fixRouterAndDecodeParams(params) {
  if (!params) {
    return params;
  }
  const {
    stamp,
    $taroTimestamp,
    ...newParams
  } = params;
  console.log(`[newParams]`, JSON.parse(JSON.stringify(newParams)));
  let result = parseEncodedObject(newParams);
  console.log(`[result]`, JSON.parse(JSON.stringify(result)));
  return result;
}
function parseEncodedObject(encodedObj) {
  const decodedObj = {};
  for (const key in encodedObj) {
    if (encodedObj.hasOwnProperty(key)) {
      let value;
      try {
        value = decodeURIComponent(encodedObj[key]);
      } catch (e) {}
      try {
        let _value = JSON.parse(value);
        if (typeof _value === "number") {} else {
          value = _value;
        }
      } catch (e) {}
      decodedObj[key] = value;
    }
  }
  return decodedObj;
}
function safaParse(target) {
  let res = target;
  try {
    res = JSON.stringify(target);
  } catch (error) {}
  return res;
}

export { component as default };
//# sourceMappingURL=index_comp.js.map
