const injectConfig = {
  toJson: {}
};

export { injectConfig as default };
//# sourceMappingURL=page-config.js.map
