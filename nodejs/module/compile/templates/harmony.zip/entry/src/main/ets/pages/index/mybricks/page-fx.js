const pageFx = JSON.stringify({
  pageOnLoad: null
});

export { pageFx as default };
//# sourceMappingURL=page-fx.js.map
