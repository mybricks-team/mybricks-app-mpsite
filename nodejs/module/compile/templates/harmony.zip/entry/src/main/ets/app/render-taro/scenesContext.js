import { window } from '../../npm/@tarojs/runtime';
import _defineProperty from '../../node_modules/@babel/runtime/helpers/esm/defineProperty.js';
import coreLib from '../../node_modules/@mybricks/comlib-core/index.js';
import { setLoggerSilent } from './logger.js';
import { observable } from './observable/index.js';
import executor from './executor.js';
import { compareVersion } from './utils.js';

class PageContext {
  // 传入的配置项
  constructor(options) {
    this.options = options;
    _defineProperty(this, "onCompleteCallBacks", []);
    _defineProperty(this, "mode", void 0);
    _defineProperty(this, "comDefs", {});
    _defineProperty(this, "onError", e => {
      console.error(e);
    });
    _defineProperty(this, "logger", void 0);
    _defineProperty(this, "observable", observable);
    const {
      env,
      debug,
      observable: observable$1,
      onError,
      plugins = []
    } = options;
    this.mode = debug ? "development" : "production";
    if (!observable$1) {} else {
      this.observable = observable$1;
    }
    const {
      onCompleteCallBacks
    } = this;
    if (!env.runtime) {
      env.runtime = {
        // debug: {
        //   onComplete(fn: any) {
        //     onCompleteCallBacks.push(fn)
        //   }
        // },
        onComplete(fn) {
          onCompleteCallBacks.push(fn);
        }
      };
    }
    if (!env.i18n) {
      env.i18n = text => text;
    }
    if (!env.renderModule) {
      env.renderModule = (json, options2) => {};
    } else {
      const renderModule = env.renderModule;
      env.renderModule = (json, options2) => {
        return renderModule(json, {
          ...options2,
          env,
          _isNestedRender: true
        });
      };
    }
    if (!env.renderCom) {
      env.renderCom = (json, options2) => {};
    } else {
      const renderCom = env.renderCom;
      env.renderCom = (json, options2) => {
        return renderCom(json, {
          ...options2,
          _isNestedRender: true
        });
      };
    }
    const that = this;
    this.initOther();
    this.initComdefs();
    const arr = [];
    arr.concat(plugins).forEach(plugin => {
      plugin.apply(this);
    });
  }
  // 初始化其它信息
  initOther() {
    const {
      env
    } = this.options;
    if (!!env.silent) {
      setLoggerSilent();
    }
    this.logger = {
      info: console.info,
      trace: console.trace,
      warn: console.warn,
      error: e => {
        console.error(e);
      }
    };
  }
  // 初始化组件信息
  initComdefs() {
    const regAry = (comAray, comDefs2) => {
      comAray.forEach(comDef => {
        if (comDef.comAray) {
          regAry(comDef.comAray, comDefs2);
        } else {
          comDefs2[`${comDef.namespace}-${comDef.version}`] = comDef;
        }
      });
    };
    const {
      comDefs: defaultComdefs
    } = this.options;
    const {
      comDefs
    } = this;
    if (defaultComdefs) {
      Object.assign(comDefs, defaultComdefs);
    }
    let comLibs = [...(window["__comlibs_edit_"] || []), ...(window["__comlibs_rt_"] || [])];
    if (coreLib.comAray) {
      coreLib.comAray = coreLib.comAray.filter(com => !["mybricks.core-comlib.group", "mybricks.core-comlib.selection"].includes(com.namespace));
    }
    comLibs.push(coreLib, comDefs);
    comLibs.forEach(lib => {
      const comAray = lib.comAray;
      if (comAray && Array.isArray(comAray)) {
        regAry(comAray, comDefs);
      }
    });
  }
  /** 
   * 通过namespace-version查找组件
   * 
   * TODO: 优化查询方式，目前每个找不到的组件都重复全量查，找不到的组件在第一次使用最新版本后做好记录，后面不会重复查找
   */
  getComDef(def) {
    const {
      comDefs
    } = this;
    const rtn = comDefs[def?.namespace + "-" + def?.version];
    if (!rtn) {
      const ary = [];
      for (let ns in comDefs) {
        if (ns.startsWith(def?.namespace + "-")) {
          ary.push(comDefs[ns]);
        }
      }
      if (ary && ary.length > 0) {
        ary.sort((a, b) => {
          return compareVersion(a.version, b.version);
        });
        const rtn0 = ary[0];
        console.warn(`【Mybricks】组件${def?.namespace + "@" + def?.version}未找到，使用${rtn0.namespace}@${rtn0.version}代替.`);
        return rtn0;
      } else {
        console.error(`组件${def?.namespace + "@" + def?.version}未找到，请确定是否存在该组件以及对应的版本号.`);
        return null;
      }
    }
    return rtn;
  }
}
class ScenesContext {
  constructor(json) {
    let _options = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {
      disableAutoRun: false
    };
    _defineProperty(this, "json", {});
    _defineProperty(this, "scenesMap", {});
    _defineProperty(this, "scenesOperateInputsTodo", {});
    _defineProperty(this, "globalVarMap", {});
    _defineProperty(this, "fxToJsonMap", {});
    _defineProperty(this, "currentFxFrameIdsMap", {});
    _defineProperty(this, "scenesOperate", {});
    _defineProperty(this, "contextMap", {});
    _defineProperty(this, "createPageContext", (jsonId, options) => {
      this.contextMap[jsonId] = new PageContext(options);
      return this.contextMap[jsonId];
    });
    _defineProperty(this, "destroyPage", jsonId => {
      const scene = this.scenesMap[jsonId];
      if (scene) {
        scene.show = false;
        scene.todo = [];
        scene._refs = null;
      }
    });
    _defineProperty(this, "getPageContext", pageJsonId => {
      return this.contextMap[pageJsonId];
    });
    _defineProperty(this, "getExistContext", () => {
      return Object.values(this.contextMap)?.[0];
    });
    _defineProperty(this, "getScenesOperate", () => {
      const {
        scenesMap,
        currentFxFrameIdsMap,
        fxToJsonMap,
        scenesOperateInputsTodo,
        globalVarMap,
        json: json2
      } = this;
      const _this = this;
      return {
        open(_ref) {
          let {
            todo,
            frameId,
            parentScope,
            comProps
          } = _ref;
          const _context = _this.getExistContext();
          const {
            options
          } = _context;
          const fxtojson = fxToJsonMap[frameId];
          if (fxtojson) {
            const {
              env
            } = options;
            const scenesOperate = _this.getScenesOperate();
            executor({
              json: fxtojson,
              getComDef: def => _context.getComDef(def),
              events: options.events,
              env,
              ref(_refs) {
                const {
                  inputs,
                  outputs
                } = _refs;
                fxtojson.outputs.forEach(output => {
                  outputs(output.id, value => {
                    parentScope.outputs[output.id](value);
                  });
                });
                const configs = comProps?.data?.configs;
                if (configs) {
                  Object.entries(configs).forEach(_ref2 => {
                    let [key, value] = _ref2;
                    _refs.inputs[key](value, void 0, false);
                  });
                }
                _refs.inputs[todo.pinId](todo.value, void 0, false);
                _refs.run();
              },
              comInstance: options.comInstance,
              onError: _context.onError,
              debug: options.debug,
              debugLogger: options.debugLogger,
              logger: _context.logger,
              scenesOperate,
              _context
            }, {
              //////TODO goon
              observable: _context.observable
              //传递获取响应式的方法
            });
          } else {
            options.env.callServiceFx?.(frameId, todo.value).then(_ref3 => {
              let {
                id,
                value
              } = _ref3;
              parentScope.outputs[id](value);
            });
          }
        },
        inputs(_ref4) {
          let {
            frameId,
            parentScope,
            value,
            pinId
          } = _ref4;
          console.log("场景触发inputs: ", {
            frameId,
            parentScope,
            value,
            pinId
          });
          const scenes = scenesMap[frameId];
          if (!scenes) {
            if (!scenesOperateInputsTodo[frameId]) {
              scenesOperateInputsTodo[frameId] = {
                parentScope,
                todo: [{
                  value,
                  pinId
                }]
              };
            } else {
              scenesOperateInputsTodo[frameId].todo.push({
                frameId,
                parentScope,
                value,
                pinId
              });
            }
          } else {
            scenes.parentScope = parentScope;
            if (scenes.type !== "popup" && scenes.type !== "module") {
              return;
            }
            if (scenes._refs) {
              scenes._refs.inputs[pinId](value);
            } else {
              scenes.todo = scenes.todo.concat({
                type: "inputs",
                todo: {
                  pinId,
                  value
                }
              });
            }
          }
        },
        _notifyBindings(val, com) {
          const {
            bindingsTo
          } = com.model;
          if (bindingsTo) {
            for (let comId in bindingsTo) {
              for (let i in scenesMap) {
                const scenes = scenesMap[i];
                const com2 = scenes.json.coms[comId];
                if (com2) {
                  if (scenes._refs) {
                    _notifyBindings(scenes._refs, comId, bindingsTo[comId], val);
                  } else {
                    const bindings = bindingsTo[comId];
                    scenes.todo = scenes.todo.concat({
                      type: "globalVar",
                      todo: {
                        comId,
                        bindings,
                        value: val
                      }
                    });
                  }
                }
              }
            }
          }
        },
        getGlobalComProps(comId) {
          return {
            data: {
              val: globalVarMap[comId]
            }
          };
        },
        exeGlobalCom(_ref5) {
          let {
            com,
            value,
            pinId
          } = _ref5;
          const globalComId = com.id;
          globalVarMap[globalComId] = value;
          Object.keys(scenesMap).forEach(key => {
            const scenes = scenesMap[key];
            if (scenes.show && scenes._refs) {
              const globalCom = scenes._refs.get({
                comId: globalComId
              });
              if (globalCom) {
                globalCom.outputs[pinId](value, true, null, true);
              }
            }
          });
        }
      };
    });
    this.json = json;
    this.globalVarMap = json.globalVarMap || {};
    this.scenesMap = (json?.scenes ?? []).reduce((acc, json2, index) => {
      return {
        ...acc,
        [json2.id]: {
          show: index === 0,
          todo: [],
          json: json2,
          disableAutoRun: !!(_options.disableAutoRun || index),
          useEntryAnimation: false,
          type: json2.slot?.showType || json2.type
        }
      };
    }, {});
    const _fxToJsonMap = {};
    const {
      global
    } = json;
    if (global) {
      const {
        fxFrames
      } = global;
      if (Array.isArray(fxFrames)) {
        fxFrames.forEach(fxFrame => {
          _fxToJsonMap[fxFrame.id] = fxFrame;
        });
      }
    }
    this.fxToJsonMap = _fxToJsonMap;
    this.scenesOperate = this.getScenesOperate();
    console.log("初始化 ScenesContext => ", this);
  }
}
function _notifyBindings(_refs, comId, bindings, value) {
  const com = _refs.get(comId);
  if (com) {
    if (Array.isArray(bindings)) {
      bindings.forEach(binding => {
        let nowObj = com;
        const ary = binding.split(".");
        ary.forEach((nkey, idx) => {
          if (idx !== ary.length - 1) {
            nowObj = nowObj[nkey];
          } else {
            nowObj[nkey] = value;
          }
        });
      });
    }
  }
}

export { PageContext, ScenesContext };
//# sourceMappingURL=scenesContext.js.map
