// @ts-nocheck
import { temporarilyNotSupport } from '../utils'

// 加密
export const getRandomValues = /* @__PURE__ */ temporarilyNotSupport('getRandomValues')
