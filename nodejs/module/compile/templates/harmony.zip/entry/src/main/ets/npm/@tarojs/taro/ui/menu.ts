// @ts-nocheck
import { temporarilyNotSupport } from '../utils'

// 菜单
export const getMenuButtonBoundingClientRect = /* @__PURE__ */ temporarilyNotSupport('getMenuButtonBoundingClientRect')
