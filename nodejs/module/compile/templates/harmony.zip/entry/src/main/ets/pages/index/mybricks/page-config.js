const injectPageConfig = {
  toJson: {
    "scenes": [{
      "-v": "1.1.1",
      "deps": [{
        "namespace": "mybricks.taro.systemPage",
        "version": "1.0.1"
      }, {
        "namespace": "mybricks.taro.button",
        "version": "1.0.0"
      }, {
        "namespace": "mybricks.taro.text",
        "version": "1.0.0"
      }, {
        "namespace": "mybricks.taro.image",
        "version": "1.0.0"
      }, {
        "namespace": "mybricks.core-comlib.scenes",
        "version": "1.0.0",
        "rtType": "js"
      }, {
        "namespace": "mybricks.taro._showActionSheet",
        "version": "1.0.0",
        "rtType": "js"
      }, {
        "namespace": "mybricks.taro._showToast",
        "version": "1.0.1",
        "rtType": "js"
      }, {
        "namespace": "mybricks.taro._muilt-inputJs",
        "version": "1.0.0",
        "rtType": "js-autorun"
      }, {
        "namespace": "mybricks.taro.tabs2",
        "version": "1.0.0"
      }],
      "coms": {
        "u_2wzlB": {
          "id": "u_2wzlB",
          "def": {
            "namespace": "mybricks.taro.systemPage",
            "version": "1.0.1"
          },
          "title": "页面",
          "model": {
            "data": {
              "useNavigationStyle": "default",
              "navigationStyle": "default",
              "navigationBarBackgroundColor": "#464646",
              "navigationBarTextStyle": "white",
              "navigationBarTitleText": "页面标题",
              "backgroundColorTop": "#ffffff",
              "backgroundColorBottom": "#ffffff",
              "homeButton": false,
              "customNavigation": {
                "style": {
                  "backgroundColor": "#464646"
                },
                "mainSlotStyle": {},
                "useFixed": true
              },
              "useTabBar": false,
              "tabBar": [],
              "background": "#ffffff",
              "enablePullDownRefresh": false,
              "backgroundTextStyle": "dark",
              "backgroundColor": "#464646",
              "enableShareAppMessage": false,
              "onReachBottomDistance": 30,
              "pageOrientation": "portrait",
              "disableScroll": false,
              "disableSwipeBack": false,
              "useFooter": false,
              "useSkeleton": false,
              "skeleton": [{
                "type": "thumbnail"
              }, {
                "type": "avatar"
              }, {
                "type": "title"
              }, {
                "type": "paragraph"
              }],
              "layout": {
                "position": "smart"
              },
              "bottomSpace": 30,
              "useLoading": false,
              "backgroundSize": "cover",
              "isEntryPagePath": false,
              "showNavigationBarCapsule": true,
              "id": "u_NFEBq"
            },
            "outputEvents": {},
            "style": {
              "width": "100%",
              "height": "100%",
              "_new": true,
              "flex": 1
            }
          },
          "asRoot": true,
          "configs": [],
          "_inputs": [],
          "inputs": ["cancelPulldown", "setShare"],
          "outputs": ["pageDidShow", "pageDidHide", "pulldown"],
          "pageId": "u_NFEBq"
        },
        "u_S6lQT": {
          "id": "u_S6lQT",
          "def": {
            "namespace": "mybricks.taro.button",
            "version": "1.0.0"
          },
          "title": "按钮",
          "model": {
            "data": {
              "variant": "text",
              "color": "primary",
              "size": "",
              "shape": "",
              "block": true,
              "loading": false,
              "icon": "",
              "disabled": false,
              "hairline": true,
              "style": {
                "background": "#ea732e",
                "color": "#ffffff",
                "border-radius": "0px",
                "border-width": "0px"
              },
              "text": "按钮",
              "asHotarea": false,
              "openType": "",
              "useBeforeIcon": false,
              "beforeIconUrl": "",
              "useAfterIcon": false,
              "afterIconUrl": "",
              "placeholderIconUrl": ""
            },
            "outputEvents": {
              "onClick": [{
                "type": "defined",
                "options": {
                  "id": "u_z_ixY",
                  "title": "按钮 > 单击"
                },
                "active": true
              }]
            },
            "style": {
              "visibility": "visible",
              "width": 120,
              "height": 42,
              "zIndex": 1,
              "position": "relative",
              "marginTop": 0,
              "marginLeft": 0,
              "_new": true
            }
          },
          "style": {
            "width": 120,
            "height": 42
          },
          "configs": [],
          "_inputs": [],
          "inputs": ["buttonText", "setDisabled", "setEnabled", "_setStyle", "show", "hide", "showOrHide"],
          "outputs": ["onClick", "setDisabledSuccess", "setEnabledSuccess"],
          "pageId": "u_NFEBq"
        },
        "u_wWur3": {
          "id": "u_wWur3",
          "def": {
            "namespace": "mybricks.taro.text",
            "version": "1.0.0"
          },
          "title": "文本",
          "model": {
            "data": {
              "useDynamic": false,
              "text": "我的内容会被按钮修改",
              "ellipsis": false,
              "maxLines": 1,
              "displayState": "static",
              "useLongPress": "none"
            },
            "outputEvents": {
              "onClick": [{
                "type": "defined",
                "options": {
                  "id": "u_xhqDz",
                  "title": "文本 > 单击"
                },
                "active": true
              }]
            },
            "style": {
              "visibility": "visible",
              "width": "fit-content",
              "height": "fit-content",
              "zIndex": 2,
              "position": "relative",
              "inSmartLayout": true,
              "marginTop": 26,
              "marginLeft": 57,
              "_new": true
            }
          },
          "style": {
            "width": 140,
            "height": 16
          },
          "configs": [],
          "_inputs": [],
          "inputs": ["value", "getValue", "_setStyle", "show", "hide", "showOrHide"],
          "outputs": ["onClick", "onGetValue"],
          "pageId": "u_NFEBq"
        },
        "u_7TkU6": {
          "id": "u_7TkU6",
          "def": {
            "namespace": "mybricks.taro.text",
            "version": "1.0.0"
          },
          "title": "文本1",
          "model": {
            "data": {
              "useDynamic": false,
              "text": "点击我跳转页面a ",
              "ellipsis": false,
              "maxLines": 1,
              "displayState": "static",
              "useLongPress": "none"
            },
            "outputEvents": {
              "onClick": [{
                "type": "defined",
                "options": {
                  "id": "u_2xF71",
                  "title": "文本1 > 单击"
                },
                "active": true
              }]
            },
            "style": {
              "visibility": "visible",
              "width": "fit-content",
              "height": "fit-content",
              "zIndex": 3,
              "position": "relative",
              "inSmartLayout": true,
              "marginTop": 45,
              "marginLeft": 220,
              "_new": true
            }
          },
          "style": {
            "width": 112,
            "height": 16
          },
          "configs": [],
          "_inputs": [],
          "inputs": ["value", "getValue", "_setStyle", "show", "hide", "showOrHide"],
          "outputs": ["onClick", "onGetValue"],
          "pageId": "u_NFEBq"
        },
        "u_LyHCt": {
          "id": "u_LyHCt",
          "def": {
            "namespace": "mybricks.taro.image",
            "version": "1.0.0"
          },
          "title": "图片",
          "model": {
            "data": {
              "src": "https://my.mybricks.world/image/icon.png",
              "svgPolyfill": "",
              "mode": "aspectFill",
              "loadSmooth": false,
              "showMenuByLongpress": false,
              "clickType": ""
            },
            "outputEvents": {
              "onClick": [{
                "type": "defined",
                "options": {},
                "active": true
              }],
              "onLoad": [{
                "type": "defined",
                "options": {},
                "active": true
              }],
              "onError": [{
                "type": "defined",
                "options": {},
                "active": true
              }]
            },
            "style": {
              "visibility": "visible",
              "width": 249,
              "height": 193,
              "zIndex": 4,
              "position": "relative",
              "marginTop": 22,
              "marginLeft": 14,
              "_new": true
            }
          },
          "style": {
            "width": 249,
            "height": 193
          },
          "configs": [],
          "_inputs": [],
          "inputs": ["setSrc", "_setStyle", "show", "hide", "showOrHide"],
          "outputs": ["onLoad", "onError", "onClick"],
          "pageId": "u_NFEBq"
        },
        "u_rikhU": {
          "id": "u_rikhU",
          "def": {
            "namespace": "mybricks.core-comlib.scenes",
            "version": "1.0.0",
            "rtType": "js"
          },
          "title": "新建 小程序页面",
          "model": {
            "data": {
              "_sceneId": "u_wrtYl",
              "_sceneShowType": "normal",
              "openType": "blank"
            },
            "outputEvents": {},
            "style": {
              "display": "block"
            }
          },
          "style": {},
          "configs": [],
          "_inputs": ["_open"],
          "inputs": ["open"],
          "outputs": [],
          "pageId": "u_NFEBq"
        },
        "u_9pc8b": {
          "id": "u_9pc8b",
          "def": {
            "namespace": "mybricks.taro._showActionSheet",
            "version": "1.0.0",
            "rtType": "js"
          },
          "title": "显示操作菜单1",
          "model": {
            "data": {
              "itemList": [{
                "label": "选项一",
                "value": "选项一"
              }, {
                "label": "选项二",
                "value": "选项二"
              }]
            },
            "outputEvents": {},
            "style": {
              "display": "block"
            }
          },
          "style": {},
          "configs": [],
          "_inputs": [],
          "inputs": ["showActionSheet"],
          "outputs": ["onSelect", "onCancel"],
          "pageId": "u_NFEBq"
        },
        "u_DDdEz": {
          "id": "u_DDdEz",
          "def": {
            "namespace": "mybricks.taro._showToast",
            "version": "1.0.1",
            "rtType": "js"
          },
          "title": "显示 Toast",
          "model": {
            "data": {
              "title": "提示的内容",
              "duration": 1e3,
              "icon": "none",
              "mask": false,
              "dynamic": false,
              "id": "u_snfmzf"
            },
            "outputEvents": {},
            "style": {
              "display": "block"
            }
          },
          "style": {},
          "configs": [],
          "_inputs": [],
          "inputs": ["showToast"],
          "outputs": ["afterShowToast"],
          "pageId": "u_NFEBq"
        },
        "u_3q3G8": {
          "id": "u_3q3G8",
          "def": {
            "namespace": "mybricks.taro._muilt-inputJs",
            "version": "1.0.0",
            "rtType": "js-autorun"
          },
          "title": "JS计算",
          "model": {
            "data": {},
            "outputEvents": {},
            "style": {
              "display": "block"
            }
          },
          "style": {},
          "configs": [],
          "_inputs": [],
          "inputs": ["input.inputValue0"],
          "outputs": ["output0"],
          "pageId": "u_NFEBq"
        },
        "u_HBffb": {
          "id": "u_HBffb",
          "def": {
            "namespace": "mybricks.taro.tabs2",
            "version": "1.0.0"
          },
          "title": "Tabs",
          "model": {
            "data": {
              "mode": "topbar",
              "new_index": 3,
              "tabs": [{
                "_id": "tabId1",
                "tabName": "标签项1",
                "badge": ""
              }, {
                "_id": "tabId2",
                "tabName": "标签项2",
                "badge": ""
              }],
              "edit": {
                "currentItemId": ""
              },
              "initChangeTab": false,
              "navBarGutter": 12,
              "sticky": false,
              "slotStyle": {
                "position": "smart"
              },
              "lastTabHeight": -1,
              "contentShowType": "switch"
            },
            "outputEvents": {
              "changeTab": [{
                "type": "defined",
                "options": {},
                "active": true
              }],
              "changeTab_tabId2": [{
                "type": "defined",
                "options": {},
                "active": true
              }],
              "changeTab_tabId1": [{
                "type": "defined",
                "options": {},
                "active": true
              }]
            },
            "style": {
              "visibility": "visible",
              "width": 292,
              "height": 200,
              "zIndex": 5,
              "position": "relative",
              "marginTop": 28,
              "marginLeft": 14,
              "_new": true
            }
          },
          "style": {
            "width": 292,
            "height": 200
          },
          "configs": [],
          "_inputs": [],
          "inputs": ["dataSource", "activeTabId", "getActiveTabId", "setBadge", "setDesc", "tabId1", "tabId2", "_setStyle", "show", "hide", "showOrHide"],
          "outputs": ["changeDone", "changeTab", "activeTabId", "changeTab_tabId1", "changeTab_tabId2"],
          "frames": [],
          "pageId": "u_NFEBq"
        }
      },
      "id": "u_NFEBq",
      "title": "新建 小程序标签页",
      "comsAutoRun": {},
      "_inputs": [],
      "_outputs": [],
      "inputs": [{
        "id": "open",
        "title": "打开",
        "type": "normal"
      }],
      "outputs": [{
        "id": "click",
        "title": "点击",
        "type": "event"
      }, {
        "id": "scroll",
        "title": "滚动",
        "type": "event"
      }, {
        "id": "load",
        "title": "加载完成",
        "type": "event"
      }, {
        "id": "unload",
        "title": "卸载",
        "type": "event"
      }],
      "cons": {
        "u_S6lQT-onClick": [{
          "id": "u_c_KKx",
          "type": "com",
          "frameKey": "_rootFrame_",
          "targetFrameKey": "_rootFrame_",
          "comId": "u_3q3G8",
          "def": {
            "namespace": "mybricks.taro._muilt-inputJs",
            "version": "1.0.0",
            "rtType": "js-autorun"
          },
          "pinId": "input.inputValue0",
          "pinType": "param",
          "direction": "input"
        }],
        "u_wWur3-onClick": [{
          "id": "u_CNr19",
          "type": "com",
          "frameKey": "_rootFrame_",
          "targetFrameKey": "_rootFrame_",
          "comId": "u_9pc8b",
          "def": {
            "namespace": "mybricks.taro._showActionSheet",
            "version": "1.0.0",
            "rtType": "js"
          },
          "pinId": "showActionSheet",
          "pinType": "normal",
          "direction": "input"
        }],
        "u_7TkU6-onClick": [{
          "id": "u_oXcJo",
          "type": "com",
          "frameKey": "_rootFrame_",
          "targetFrameKey": "_rootFrame_",
          "comId": "u_rikhU",
          "def": {
            "namespace": "mybricks.core-comlib.scenes",
            "version": "1.0.0",
            "rtType": "js"
          },
          "pinId": "open",
          "pinType": "normal",
          "direction": "input"
        }],
        "u_9pc8b-onSelect": [{
          "id": "u_8Uirv",
          "type": "com",
          "frameKey": "_rootFrame_",
          "targetFrameKey": "_rootFrame_",
          "comId": "u_DDdEz",
          "def": {
            "namespace": "mybricks.taro._showToast",
            "version": "1.0.1",
            "rtType": "js"
          },
          "pinId": "showToast",
          "pinType": "normal",
          "direction": "input"
        }],
        "u_3q3G8-output0": [{
          "id": "u_Dndv_",
          "type": "com",
          "frameKey": "_rootFrame_",
          "targetFrameKey": "_rootFrame_",
          "finishPinParentKey": "u_L6L0m",
          "comId": "u_wWur3",
          "def": {
            "namespace": "mybricks.taro.text",
            "version": "1.0.0"
          },
          "pinId": "value",
          "pinType": "normal",
          "direction": "input"
        }]
      },
      "pinRels": {
        "u_S6lQT-setDisabled": ["setDisabledSuccess"],
        "u_S6lQT-setEnabled": ["setEnabledSuccess"],
        "u_wWur3-getValue": ["onGetValue"],
        "u_7TkU6-getValue": ["onGetValue"],
        "u_HBffb-getActiveTabId": ["activeTabId"],
        "u_HBffb-tabId1": ["changeDone"],
        "u_HBffb-tabId2": ["changeDone"]
      },
      "pinProxies": {
        "u_rikhU-_open": {
          "type": "frame",
          "frameId": "u_wrtYl",
          "pinId": "open"
        }
      },
      "pinValueProxies": {},
      "slot": {
        "id": "u_NFEBq",
        "title": "新建 小程序标签页",
        "comAry": [{
          "id": "u_2wzlB",
          "name": "u_LNvcn",
          "def": {
            "namespace": "mybricks.taro.systemPage",
            "version": "1.0.1"
          },
          "slots": {
            "content": {
              "id": "content",
              "title": "内容",
              "layoutTemplate": [{
                "id": "u_LyHCt",
                "name": "u_xjT76",
                "def": {
                  "namespace": "mybricks.taro.image",
                  "version": "1.0.0"
                }
              }, {
                "id": "u_7TkU6",
                "name": "u_48iKl",
                "def": {
                  "namespace": "mybricks.taro.text",
                  "version": "1.0.0"
                }
              }, {
                "id": "u_S6lQT",
                "style": {
                  "display": "flex",
                  "flexDirection": "row",
                  "marginLeft": 36,
                  "marginTop": 2
                },
                "elements": [{
                  "id": "u_S6lQT",
                  "name": "u_aNI9T",
                  "def": {
                    "namespace": "mybricks.taro.button",
                    "version": "1.0.0"
                  }
                }, {
                  "id": "u_wWur3",
                  "name": "u_sKryp",
                  "def": {
                    "namespace": "mybricks.taro.text",
                    "version": "1.0.0"
                  }
                }]
              }, {
                "id": "u_HBffb",
                "name": "u_js3q_",
                "def": {
                  "namespace": "mybricks.taro.tabs2",
                  "version": "1.0.0"
                },
                "slots": {
                  "tabId1": {
                    "id": "tabId1",
                    "title": "标签项1",
                    "comAry": [],
                    "style": {}
                  },
                  "tabId2": {
                    "id": "tabId2",
                    "title": "标签项2",
                    "comAry": [],
                    "style": {}
                  }
                }
              }],
              "comAry": {
                "length": 5
              },
              "style": {
                "layout": "smart",
                "height": 583
              }
            }
          }
        }],
        "style": {
          "overflowX": "hidden",
          "overflowY": "auto",
          "width": 375,
          "height": 667
        }
      }
    }]
  }
};

export { injectPageConfig as default };
//# sourceMappingURL=page-config.js.map
