import { convertNumber2VP, __env__, window, navigator, location, __combine_nesting_style__, calcStaticStyle, document } from '../npm/@tarojs/runtime';
import Taro from '../npm/@tarojs/taro';
/* empty css                  */import React__default, { useMemo, useCallback, useState, useRef, useEffect } from '../npm/react';
import { TaroViewTagName, TaroImageTagName, TaroScrollViewTagName, TaroButtonTagName, TaroTextTagName } from '../npm/@tarojs/components/tag';

let __inner_style_data__;
let __nesting_style_data__;
function __nesting_style__() {
  if (__nesting_style_data__) return __nesting_style_data__;
  __nesting_style_data__ = [{
    "selectors": [["index_place__IvS1F", "index_none__yqXJj"]],
    "declaration": {
      zIndex: -1,
      opacity: 0
    }
  }, {
    "selectors": [["item_item__JjgfE", "item_horizontal__ad3At"]],
    "declaration": {
      display: "flex",
      alignItems: ItemAlign.Center,
      justifyContent: FlexAlign.Center
    }
  }, {
    "selectors": [["item_item__JjgfE", "item_vertical__4YJ5-"]],
    "declaration": {
      display: "flex",
      flexDirection: FlexDirection.Column,
      alignItems: ItemAlign.Center,
      justifyContent: FlexAlign.Center
    }
  }, {
    "selectors": [["style_page__2c4W0", "style_debug__hmr7r"]],
    "declaration": {
      height: "100%"
    }
  }, {
    "selectors": [["style_popup__bisqh", "style_show__6k-p5"]],
    "declaration": {
      display: "block"
    }
  }, {
    "selectors": ["index_com__G-HMq", " ", "taro-img__mode-aspectfill"],
    "declaration": {
      width: "100%",
      height: "100%",
      objectFit: "cover"
    }
  }, {
    "selectors": ["item_item__JjgfE", " ", "item_icon__WGZ-H"],
    "declaration": {
      display: "block",
      width: convertNumber2VP(24),
      height: convertNumber2VP(24)
    }
  }, {
    "selectors": ["item_item__JjgfE", " ", "item_text__GICp-"],
    "declaration": {
      fontSize: convertNumber2VP(14),
      lineHeight: convertNumber2VP(18),
      whiteSpace: "nowrap",
      overflow: "hidden",
      textOverflow: {
        overflow: TextOverflow.Ellipsis
      }
    }
  }, {
    "selectors": [["item_item__JjgfE", "item_horizontal__ad3At"], " ", "item_icon__WGZ-H"],
    "declaration": {
      marginRight: convertNumber2VP(6)
    }
  }, {
    "selectors": [["item_item__JjgfE", "item_horizontal__ad3At"], " ", "item_text__GICp-"],
    "declaration": {
      flexBasis: "0%",
      flexGrow: 1,
      flexShrink: 1
    }
  }, {
    "selectors": [["item_item__JjgfE", "item_vertical__4YJ5-"], " ", "item_icon__WGZ-H"],
    "declaration": {
      marginBottom: convertNumber2VP(6)
    }
  }, {
    "selectors": [["item_item__JjgfE", "item_vertical__4YJ5-"], " ", "item_text__GICp-"],
    "declaration": {
      width: "100%"
    }
  }, {
    "selectors": ["style_button__00vWp", " ", "style_icon__9pUc5"],
    "declaration": {
      display: "block",
      width: convertNumber2VP(16),
      height: convertNumber2VP(16)
    }
  }, {
    "selectors": ["style_button__00vWp", " ", "style_text__sOFvV"],
    "declaration": {
      flexBasis: "0%",
      flexGrow: 1,
      flexShrink: 1
    }
  }, {
    "selectors": ["style_checkList__2MwAo", " ", "style_checkListTrack__37que"],
    "declaration": {
      width: "100%",
      height: "100%",
      overflow: "scroll",
      WebkitOverflowScrolling: "touch",
      overscrollBehavior: "none"
    }
  }, {
    "selectors": ["style_checkList__2MwAo", " ", ["style_checkListTrack__37que", "style_checkListTrackWrap__yvYfr"]],
    "declaration": {
      overflow: "hidden"
    }
  }, {
    "selectors": ["style_checkList__2MwAo", " ", "style_checkListTrack__37que::-webkit-scrollbar"],
    "declaration": {
      display: "none"
    }
  }, {
    "selectors": ["style_condition__2puQg", " ", "style_content__ftKiQ"],
    "declaration": {
      width: "100%",
      height: "100%"
    }
  }, {
    "selectors": ["style_condition__2puQg", " ", "style_switch__aRVfl"],
    "declaration": {
      position: "absolute",
      top: convertNumber2VP(0),
      right: convertNumber2VP(0),
      width: convertNumber2VP(100),
      transform: {
        Translate: {
          x: convertNumber2VP(120)
        }
      },
      height: "100%",
      display: "flex",
      justifyContent: FlexAlign.Center,
      alignItems: ItemAlign.Center,
      backgroundColor: "#f0f0f0",
      cursor: "pointer"
    }
  }, {
    "selectors": ["style_customNavigation__ddSi4", " ", "style_main__nDuLd"],
    "declaration": {
      position: "relative"
    }
  }, {
    "selectors": ["style_customNavigation__ddSi4", " ", "style_safearea__Aqfot"],
    "declaration": {
      width: "100%"
    }
  }, {
    "selectors": ["style_defaultNavigation__e3FjL", " ", "style_main__U61qz"],
    "declaration": {
      width: "100%",
      height: convertNumber2VP(40),
      position: "relative",
      display: "flex",
      alignItems: ItemAlign.Center,
      justifyContent: FlexAlign.Center
    }
  }, {
    "selectors": ["style_defaultNavigation__e3FjL", " ", "style_safearea__Px1zS"],
    "declaration": {
      width: "100%",
      height: convertNumber2VP(44)
    }
  }, {
    "selectors": ["style_footer__SXeSh", " ", "style_safearea__8uJxv"],
    "declaration": {
      width: "100%",
      height: __env__("safe-area-inset-bottom")
    }
  }, {
    "selectors": ["style_loading__nVEJd", " ", "style_icon__CJWe6"],
    "declaration": {
      position: "absolute",
      top: "50%",
      left: "50%",
      width: convertNumber2VP(36),
      height: convertNumber2VP(36),
      marginTop: convertNumber2VP(-18),
      marginRight: convertNumber2VP(0),
      marginBottom: convertNumber2VP(0),
      marginLeft: convertNumber2VP(-18),
      borderTopWidth: convertNumber2VP(4),
      borderRightWidth: convertNumber2VP(4),
      borderBottomWidth: convertNumber2VP(4),
      borderLeftWidth: convertNumber2VP(4),
      borderTopStyle: BorderStyle.Solid,
      borderRightStyle: BorderStyle.Solid,
      borderBottomStyle: BorderStyle.Solid,
      borderLeftStyle: BorderStyle.Solid,
      borderTopColor: "rgba(0, 0, 0, 0.06)",
      borderRightColor: "rgba(224, 224, 224, 0.06)",
      borderBottomColor: "rgba(0, 0, 0, 0.06)",
      borderLeftColor: "rgba(224, 224, 224, 0.06)",
      borderTopLeftRadius: "50%",
      borderTopRightRadius: "50%",
      borderBottomLeftRadius: "50%",
      borderBottomRightRadius: "50%",
      animationDelay: 0,
      animationIterationCount: -1,
      animationDuration: 1000,
      animationTimeingFunction: "linear",
      animationName: [{
        "percentage": 0,
        "event": {
          transform: {
            Rotate: {
              z: 1,
              angle: 0
            }
          }
        }
      }, {
        "percentage": 1,
        "event": {
          transform: {
            Rotate: {
              z: 1,
              angle: 360
            }
          }
        }
      }]
    }
  }, {
    "selectors": ["style_noneNavigation__W0Lnn", " ", "style_main__6Tc-W"],
    "declaration": {
      position: "relative",
      display: "flex",
      alignItems: ItemAlign.Center,
      justifyContent: FlexAlign.Center
    }
  }, {
    "selectors": ["style_noneNavigation__W0Lnn", " ", "style_safearea__pqYOV"],
    "declaration": {
      width: "100%"
    }
  }, {
    "selectors": ["style_page__2c4W0", " ", "style_contentPlaceholder__Kqmdi"],
    "declaration": {
      flexBasis: "0%",
      flexGrow: 1,
      flexShrink: 1
    }
  }, {
    "selectors": ["style_page__2c4W0", " ", "style_contentScrollView__iSgvw"],
    "declaration": {
      flexBasis: "0%",
      flexGrow: 1,
      flexShrink: 1,
      overflow: "scroll",
      height: convertNumber2VP(1)
    }
  }, {
    "selectors": ["style_page__2c4W0", " ", "style_fixedContainer__IvUfK"],
    "declaration": {
      transform: {
        Translate: {
          "z": convertNumber2VP(1)
        }
      },
      flexBasis: "0%",
      flexGrow: 1,
      flexShrink: 1,
      overflow: "hidden",
      display: "flex",
      flexDirection: FlexDirection.Column
    }
  }, {
    "selectors": ["style_popup__bisqh", " ", "style_content__PGOgq"],
    "declaration": {
      width: "100%",
      height: "100%",
      backgroundColor: "#fff",
      overflowX: "hidden"
    }
  }, {
    "selectors": ["style_popup__bisqh", " ", "style_main__bts6l"],
    "declaration": {
      position: "absolute"
    }
  }, {
    "selectors": ["style_popup__bisqh", " ", ["style_main__bts6l", "style_bottom__KVoj-"]],
    "declaration": {
      bottom: convertNumber2VP(0),
      left: convertNumber2VP(0),
      width: "100%"
    }
  }, {
    "selectors": ["style_popup__bisqh", " ", ["style_main__bts6l", "style_bottom__KVoj-", "style_empty__q43Zh"]],
    "declaration": {
      width: "100%",
      height: convertNumber2VP(180),
      display: "flex",
      justifyContent: FlexAlign.Center
    }
  }, {
    "selectors": ["style_popup__bisqh", " ", ["style_main__bts6l", "style_center__R3ESJ"]],
    "declaration": {
      top: "50%",
      left: "50%",
      transform: {
        Translate: {
          x: "-50%",
          y: "-50%"
        }
      }
    }
  }, {
    "selectors": ["style_popup__bisqh", " ", ["style_main__bts6l", "style_center__R3ESJ", "style_empty__q43Zh"]],
    "declaration": {
      width: convertNumber2VP(240),
      height: convertNumber2VP(300),
      display: "flex",
      alignItems: ItemAlign.Center,
      justifyContent: FlexAlign.Center
    }
  }, {
    "selectors": ["style_popup__bisqh", " ", ["style_main__bts6l", "style_left__DWWtV"]],
    "declaration": {
      top: convertNumber2VP(0),
      left: convertNumber2VP(0),
      height: "100%"
    }
  }, {
    "selectors": ["style_popup__bisqh", " ", ["style_main__bts6l", "style_left__DWWtV", "style_empty__q43Zh"]],
    "declaration": {
      width: convertNumber2VP(180),
      height: "100%",
      display: "flex",
      alignItems: ItemAlign.Center
    }
  }, {
    "selectors": ["style_popup__bisqh", " ", ["style_main__bts6l", "style_right__g5U5y"]],
    "declaration": {
      top: convertNumber2VP(0),
      right: convertNumber2VP(0),
      height: "100%"
    }
  }, {
    "selectors": ["style_popup__bisqh", " ", ["style_main__bts6l", "style_right__g5U5y", "style_empty__q43Zh"]],
    "declaration": {
      width: convertNumber2VP(180),
      height: "100%",
      display: "flex",
      alignItems: ItemAlign.Center
    }
  }, {
    "selectors": ["style_popup__bisqh", " ", ["style_main__bts6l", "style_top__tphmn"]],
    "declaration": {
      top: convertNumber2VP(0),
      left: convertNumber2VP(0),
      width: "100%"
    }
  }, {
    "selectors": ["style_popup__bisqh", " ", ["style_main__bts6l", "style_top__tphmn", "style_empty__q43Zh"]],
    "declaration": {
      width: "100%",
      height: convertNumber2VP(180),
      display: "flex",
      justifyContent: FlexAlign.Center
    }
  }, {
    "selectors": ["style_popup__bisqh", " ", "style_overlay__JdoAF"],
    "declaration": {
      position: "absolute",
      top: convertNumber2VP(0),
      left: convertNumber2VP(0),
      width: convertNumber2VP(375),
      height: "100%",
      backgroundColor: "rgba(0, 0, 0, 0.4)"
    }
  }, {
    "selectors": [["style_popup__bisqh", "style_show__6k-p5"], " ", "style_overlay__JdoAF"],
    "declaration": {
      animationDelay: 0,
      animationIterationCount: 1,
      animationDuration: 300,
      animationTimeingFunction: "linear",
      animationName: [{
        "percentage": 0,
        "event": {
          opacity: 0
        }
      }, {
        "percentage": 1,
        "event": {
          opacity: 1
        }
      }]
    }
  }, {
    "selectors": ["style_skeleton__Di6mB", " ", "style_paragraph__Vf-Z0"],
    "declaration": {
      marginTop: convertNumber2VP(24),
      marginRight: "5%",
      marginBottom: convertNumber2VP(24),
      marginLeft: "5%"
    }
  }, {
    "selectors": ["style_skeleton__Di6mB", " ", "style_thumbnail__NPoX8"],
    "declaration": {
      marginTop: convertNumber2VP(12),
      marginRight: "auto",
      marginBottom: convertNumber2VP(12),
      marginLeft: "auto",
      width: "90%",
      height: convertNumber2VP(197),
      backgroundColor: "rgba(0, 0, 0, 0.06)"
    }
  }, {
    "selectors": ["style_skeleton__Di6mB", " ", "style_title__AzNZl"],
    "declaration": {
      marginTop: convertNumber2VP(24),
      marginRight: "5%",
      marginBottom: convertNumber2VP(24),
      marginLeft: "5%",
      width: "50%",
      height: convertNumber2VP(24),
      backgroundColor: "rgba(0, 0, 0, 0.06)"
    }
  }, {
    "selectors": ["style_tabBar__Hevxs", " ", "style_item__z8J2r"],
    "declaration": {
      flexBasis: "0%",
      flexGrow: 1,
      flexShrink: 1,
      height: "100%",
      paddingTop: convertNumber2VP(6),
      paddingBottom: convertNumber2VP(6),
      backgroundColor: "#fff",
      display: "flex",
      flexDirection: FlexDirection.Column,
      alignItems: ItemAlign.Center
    }
  }, {
    "selectors": ["style_tabBar__Hevxs", " ", "style_items__5wO3h"],
    "declaration": {
      width: convertNumber2VP(375),
      height: convertNumber2VP(54),
      display: "flex"
    }
  }, {
    "selectors": ["style_checkList__2MwAo", " ", "style_checkListTrack__37que", " ", "style_line__axciN"],
    "declaration": {
      display: "flex",
      flexWrap: FlexWrap.NoWrap,
      minWidth: "100%"
    }
  }, {
    "selectors": ["style_checkList__2MwAo", " ", "style_checkListTrack__37que", " ", "style_lines__rR6Eq"],
    "declaration": {
      display: "flex",
      flexWrap: FlexWrap.Wrap
    }
  }, {
    "selectors": ["style_customNavigation__ddSi4", " ", "style_main__nDuLd", " ", "style_left__DAxhG"],
    "declaration": {
      position: "absolute",
      zIndex: 100
    }
  }, {
    "selectors": ["style_customNavigation__ddSi4", " ", "style_main__nDuLd", " ", "style_right__vFBLx"],
    "declaration": {
      width: convertNumber2VP(87),
      height: convertNumber2VP(32),
      position: "absolute",
      top: convertNumber2VP(4),
      right: convertNumber2VP(0),
      zIndex: 10
    }
  }, {
    "selectors": ["style_customNavigation__ddSi4", " ", "style_main__nDuLd", " ", "style_title__Rg8y4"],
    "declaration": {
      width: "100%",
      height: "100%"
    }
  }, {
    "selectors": ["style_defaultNavigation__e3FjL", " ", "style_main__U61qz", " ", "style_left__9fz15"],
    "declaration": {
      width: convertNumber2VP(87),
      height: convertNumber2VP(32),
      position: "absolute",
      top: convertNumber2VP(4),
      left: convertNumber2VP(7)
    }
  }, {
    "selectors": ["style_defaultNavigation__e3FjL", " ", "style_main__U61qz", " ", "style_right__OayUv"],
    "declaration": {
      width: convertNumber2VP(87),
      height: convertNumber2VP(32),
      position: "absolute",
      top: convertNumber2VP(4),
      right: convertNumber2VP(7)
    }
  }, {
    "selectors": ["style_defaultNavigation__e3FjL", " ", "style_main__U61qz", " ", "style_title__ZxaaN"],
    "declaration": {
      fontWeight: 500,
      fontSize: convertNumber2VP(16)
    }
  }, {
    "selectors": ["style_noneNavigation__W0Lnn", " ", "style_main__6Tc-W", " ", "style_left__L-ozj"],
    "declaration": {
      zIndex: 100,
      position: "absolute",
      top: convertNumber2VP(20),
      left: convertNumber2VP(12)
    }
  }, {
    "selectors": ["style_noneNavigation__W0Lnn", " ", "style_main__6Tc-W", " ", "style_right__KKGPT"],
    "declaration": {
      width: convertNumber2VP(87),
      height: convertNumber2VP(32),
      position: "absolute",
      top: convertNumber2VP(4),
      right: convertNumber2VP(0),
      zIndex: 10,
      pointerEvents: "none"
    }
  }, {
    "selectors": ["style_noneNavigation__W0Lnn", " ", "style_main__6Tc-W", " ", "style_title__KEBnS"],
    "declaration": {
      fontWeight: 500,
      fontSize: convertNumber2VP(16),
      zIndex: 100
    }
  }, {
    "selectors": ["style_popup__bisqh", " ", "style_main__bts6l", " ", "style_close__zK7yY"],
    "declaration": {
      position: "absolute",
      bottom: convertNumber2VP(-72),
      left: "50%",
      transform: {
        Translate: {
          x: "-50%"
        }
      },
      width: convertNumber2VP(60),
      height: convertNumber2VP(60),
      backgroundImage: {
        src: "http://my.mybricks.world/mfs/files/1695653728233/JzVwhKRQzkLu8bqo9vOe4EQo8aLeoc9o-1695653728444.png"
      },
      backgroundSize: {
        width: convertNumber2VP(36),
        height: convertNumber2VP(36)
      },
      backgroundPosition: Alignment.Center,
      backgroundRepeat: ImageRepeat.NoRepeat
    }
  }, {
    "selectors": ["style_popup__bisqh", " ", "style_main__bts6l", " ", "style_title__jehQY"],
    "declaration": {
      lineHeight: convertNumber2VP(42),
      fontSize: convertNumber2VP(16),
      textAlign: TextAlign.Center,
      fontWeight: 500
    }
  }, {
    "selectors": [["style_popup__bisqh", "style_show__6k-p5"], " ", ["style_main__bts6l", "style_bottom__KVoj-"], " ", "style_content__PGOgq"],
    "declaration": {
      animationDelay: 0,
      animationIterationCount: 1,
      animationDuration: 300,
      animationTimeingFunction: "ease-in-out",
      animationName: [{
        "percentage": 0,
        "event": {
          transform: {
            Translate: {
              y: "100%"
            }
          }
        }
      }, {
        "percentage": 1,
        "event": {
          transform: {
            Translate: {
              y: convertNumber2VP(0)
            }
          }
        }
      }]
    }
  }, {
    "selectors": [["style_popup__bisqh", "style_show__6k-p5"], " ", ["style_main__bts6l", "style_center__R3ESJ"], " ", "style_content__PGOgq"],
    "declaration": {
      animationDelay: 0,
      animationIterationCount: 1,
      animationDuration: 300,
      animationTimeingFunction: "ease-in-out",
      animationName: [{
        "percentage": 0,
        "event": {
          transform: {
            Scale: {
              x: 0.800000011920929,
              y: 0.800000011920929
            }
          }
        }
      }, {
        "percentage": 1,
        "event": {
          transform: {
            Scale: {
              x: 1,
              y: 1
            }
          }
        }
      }]
    }
  }, {
    "selectors": [["style_popup__bisqh", "style_show__6k-p5"], " ", ["style_main__bts6l", "style_left__DWWtV"], " ", "style_content__PGOgq"],
    "declaration": {
      animationDelay: 0,
      animationIterationCount: 1,
      animationDuration: 300,
      animationTimeingFunction: "ease-in-out",
      animationName: [{
        "percentage": 0,
        "event": {
          transform: {
            Translate: {
              x: "-100%"
            }
          }
        }
      }, {
        "percentage": 1,
        "event": {
          transform: {
            Translate: {
              x: convertNumber2VP(0)
            }
          }
        }
      }]
    }
  }, {
    "selectors": [["style_popup__bisqh", "style_show__6k-p5"], " ", ["style_main__bts6l", "style_right__g5U5y"], " ", "style_content__PGOgq"],
    "declaration": {
      animationDelay: 0,
      animationIterationCount: 1,
      animationDuration: 300,
      animationTimeingFunction: "ease-in-out",
      animationName: [{
        "percentage": 0,
        "event": {
          transform: {
            Translate: {
              x: "100%"
            }
          }
        }
      }, {
        "percentage": 1,
        "event": {
          transform: {
            Translate: {
              x: convertNumber2VP(0)
            }
          }
        }
      }]
    }
  }, {
    "selectors": [["style_popup__bisqh", "style_show__6k-p5"], " ", ["style_main__bts6l", "style_top__tphmn"], " ", "style_content__PGOgq"],
    "declaration": {
      animationDelay: 0,
      animationIterationCount: 1,
      animationDuration: 300,
      animationTimeingFunction: "ease-in-out",
      animationName: [{
        "percentage": 0,
        "event": {
          transform: {
            Translate: {
              y: "-100%"
            }
          }
        }
      }, {
        "percentage": 1,
        "event": {
          transform: {
            Translate: {
              y: convertNumber2VP(0)
            }
          }
        }
      }]
    }
  }, {
    "selectors": ["style_skeleton__Di6mB", " ", "style_paragraph__Vf-Z0", " ", "style_line__X1rUl"],
    "declaration": {
      marginBottom: convertNumber2VP(12),
      display: "block",
      width: "100%",
      height: convertNumber2VP(24),
      backgroundColor: "rgba(0, 0, 0, 0.06)"
    }
  }, {
    "selectors": ["style_skeleton__Di6mB", " ", "style_paragraph__Vf-Z0", " ", "style_shortLine__nXNG0"],
    "declaration": {
      marginBottom: convertNumber2VP(12),
      display: "block",
      width: "30.000002%",
      height: convertNumber2VP(24),
      backgroundColor: "rgba(0, 0, 0, 0.06)"
    }
  }, {
    "selectors": ["style_tabBar__Hevxs", " ", "style_item__z8J2r", " ", "style_iconSlot__P7NBw"],
    "declaration": {
      position: "relative",
      width: convertNumber2VP(22),
      height: convertNumber2VP(22)
    }
  }, {
    "selectors": ["style_tabBar__Hevxs", " ", "style_item__z8J2r", " ", "style_textSlot__h4G6a"],
    "declaration": {
      marginTop: convertNumber2VP(6),
      height: convertNumber2VP(14)
    }
  }, {
    "selectors": ["style_checkList__2MwAo", " ", "style_checkListTrack__37que", " ", "style_line__axciN", " ", "style_item__crYg8"],
    "declaration": {
      flexBasis: "0%",
      flexGrow: 1,
      flexShrink: 0,
      overflow: "hidden",
      ["::last-child"]: {
        paddingRight: convertNumber2VP(0)
      }
    }
  }, {
    "selectors": ["style_customNavigation__ddSi4", " ", "style_main__nDuLd", " ", "style_left__DAxhG", " ", "style_backIcon__M0ZMT"],
    "declaration": {
      position: "absolute",
      top: "50%",
      transform: {
        Translate: {
          y: "-50%"
        }
      },
      left: convertNumber2VP(12),
      width: convertNumber2VP(18),
      height: convertNumber2VP(18)
    }
  }, {
    "selectors": ["style_customNavigation__ddSi4", " ", "style_main__nDuLd", " ", "style_left__DAxhG", " ", "style_homeIcon__xut-3"],
    "declaration": {
      position: "absolute",
      top: "50%",
      transform: {
        Translate: {
          y: "-50%"
        }
      },
      right: convertNumber2VP(12),
      display: "block",
      width: convertNumber2VP(18),
      height: convertNumber2VP(18)
    }
  }, {
    "selectors": ["style_defaultNavigation__e3FjL", " ", "style_main__U61qz", " ", "style_left__9fz15", " ", "style_backIcon__-KP0E"],
    "declaration": {
      position: "absolute",
      top: "50%",
      transform: {
        Translate: {
          y: "-50%"
        }
      },
      left: convertNumber2VP(12),
      width: convertNumber2VP(18),
      height: convertNumber2VP(18)
    }
  }, {
    "selectors": ["style_defaultNavigation__e3FjL", " ", "style_main__U61qz", " ", "style_left__9fz15", " ", "style_homeIcon__G6bAn"],
    "declaration": {
      position: "absolute",
      top: "50%",
      transform: {
        Translate: {
          y: "-50%"
        }
      },
      right: convertNumber2VP(12),
      display: "block",
      width: convertNumber2VP(18),
      height: convertNumber2VP(18)
    }
  }, {
    "selectors": ["style_tabBar__Hevxs", " ", "style_item__z8J2r", " ", "style_iconSlot__P7NBw", " ", "style_icon__kxloc"],
    "declaration": {
      display: "block",
      position: "absolute",
      left: "50%",
      bottom: convertNumber2VP(0),
      transform: {
        Translate: {
          x: "-50%",
          y: convertNumber2VP(0)
        }
      }
    }
  }, {
    "selectors": ["style_tabBar__Hevxs", " ", "style_item__z8J2r", " ", ["style_iconSlot__P7NBw", "style_iconSlotCenter__UW--l"], " ", "style_icon__kxloc"],
    "declaration": {
      bottom: "50%",
      transform: {
        Translate: {
          x: "-50%",
          y: "50%"
        }
      }
    }
  }];
  return __nesting_style_data__;
}
function __inner_style__() {
  if (__inner_style_data__) return __inner_style_data__;
  __inner_style_data__ = {
    "index_com__G-HMq": {
      width: "100%",
      height: "100%",
      display: "flex",
      alignItems: ItemAlign.Center,
      justifyContent: FlexAlign.Center,
      position: "relative",
      overflow: "hidden"
    },
    "index_place__IvS1F": {
      position: "absolute",
      top: convertNumber2VP(0),
      left: convertNumber2VP(0),
      right: convertNumber2VP(0),
      bottom: convertNumber2VP(0),
      opacity: 0.4,
      backgroundImage: {
        angle: 90,
        colors: [["#f0f0f0", 0.25], ["#e0e0e0", 0.5], ["#f0f0f0", 0.75]]
      },
      backgroundSize: {
        width: "200%",
        height: "100%"
      },
      animationDelay: 0,
      animationIterationCount: -1,
      animationDuration: 2500,
      animationTimeingFunction: "ease",
      animationName: [{
        "percentage": 0,
        "event": {
          backgroundPosition: {
            x: "-200%",
            y: 0
          }
        }
      }, {
        "percentage": 1,
        "event": {
          backgroundPosition: {
            x: "200%",
            y: 0
          }
        }
      }],
      zIndex: 3
    },
    "item_itemSelected__UlnJf": {
      width: "100%",
      overflow: "hidden",
      paddingTop: convertNumber2VP(6),
      paddingRight: convertNumber2VP(6),
      paddingBottom: convertNumber2VP(6),
      paddingLeft: convertNumber2VP(6),
      borderTopLeftRadius: convertNumber2VP(3),
      borderTopRightRadius: convertNumber2VP(3),
      borderBottomLeftRadius: convertNumber2VP(3),
      borderBottomRightRadius: convertNumber2VP(3),
      backgroundColor: "#fa6400",
      color: "#fff",
      fontWeight: 500,
      borderTopWidth: convertNumber2VP(1),
      borderRightWidth: convertNumber2VP(1),
      borderBottomWidth: convertNumber2VP(1),
      borderLeftWidth: convertNumber2VP(1),
      borderTopStyle: BorderStyle.Solid,
      borderRightStyle: BorderStyle.Solid,
      borderBottomStyle: BorderStyle.Solid,
      borderLeftStyle: BorderStyle.Solid,
      borderTopColor: "#fa6400",
      borderRightColor: "#fa6400",
      borderBottomColor: "#fa6400",
      borderLeftColor: "#fa6400"
    },
    "item_item__JjgfE": {
      width: "100%",
      overflow: "hidden",
      paddingTop: convertNumber2VP(6),
      paddingRight: convertNumber2VP(6),
      paddingBottom: convertNumber2VP(6),
      paddingLeft: convertNumber2VP(6),
      borderTopWidth: convertNumber2VP(1),
      borderRightWidth: convertNumber2VP(1),
      borderBottomWidth: convertNumber2VP(1),
      borderLeftWidth: convertNumber2VP(1),
      borderTopStyle: BorderStyle.Solid,
      borderRightStyle: BorderStyle.Solid,
      borderBottomStyle: BorderStyle.Solid,
      borderLeftStyle: BorderStyle.Solid,
      borderTopColor: "#c8c9cc",
      borderRightColor: "#c8c9cc",
      borderBottomColor: "#c8c9cc",
      borderLeftColor: "#c8c9cc",
      borderTopLeftRadius: convertNumber2VP(3),
      borderTopRightRadius: convertNumber2VP(3),
      borderBottomLeftRadius: convertNumber2VP(3),
      borderBottomRightRadius: convertNumber2VP(3)
    },
    "mybricks_slot": {},
    "style_backIcon__VfapO": {
      display: "block",
      width: convertNumber2VP(18),
      height: convertNumber2VP(18),
      transform: {
        Translate: {
          y: "-50%"
        }
      }
    },
    "style_button__00vWp": {
      width: "100%",
      height: "100%",
      display: "flex",
      alignItems: ItemAlign.Center,
      textAlign: TextAlign.Center,
      backgroundColor: "#fa6400",
      color: "#fff",
      borderTopLeftRadius: convertNumber2VP(60),
      borderTopRightRadius: convertNumber2VP(60),
      borderBottomLeftRadius: convertNumber2VP(60),
      borderBottomRightRadius: convertNumber2VP(60),
      borderTopWidth: convertNumber2VP(0),
      borderBottomWidth: convertNumber2VP(0),
      borderLeftWidth: convertNumber2VP(0),
      borderRightWidth: convertNumber2VP(0),
      borderTopStyle: BorderStyle.Solid,
      borderBottomStyle: BorderStyle.Solid,
      borderLeftStyle: BorderStyle.Solid,
      borderRightStyle: BorderStyle.Solid,
      fontSize: convertNumber2VP(14),
      ["::after"]: {
        display: "none"
      }
    },
    "style_checkList__2MwAo": {
      width: "100%",
      height: "100%"
    },
    "style_com__ha2-U": {
      width: "100%",
      height: "100%",
      display: "flex",
      alignItems: ItemAlign.Center,
      justifyContent: FlexAlign.Center,
      pointerEvents: "auto"
    },
    "style_condition__2puQg": {
      width: "100%",
      height: "100%",
      position: "relative",
      overflow: "visible"
    },
    "style_container__wthZ8": {
      width: "100%",
      height: "100%",
      overflow: "hidden",
      pointerEvents: "auto"
    },
    "style_ellipsis-line__BiWvf": {
      display: "block",
      WebkitBoxOrient: "vertical",
      WebkitLineClamp: 1,
      overflow: "hidden"
    },
    "style_fixedBottom__TEffq": {
      position: "fixed",
      zIndex: 10000,
      left: convertNumber2VP(0),
      bottom: convertNumber2VP(0),
      width: convertNumber2VP(375)
    },
    "style_fixedTop__XVHVh": {
      position: "fixed",
      zIndex: 10000,
      left: convertNumber2VP(0),
      top: convertNumber2VP(0),
      width: convertNumber2VP(375)
    },
    "style_footerPlaceholder__skMD1": {
      width: "100%",
      height: __env__("safe-area-inset-bottom")
    },
    "style_footer__SXeSh": {
      width: "100%",
      position: "fixed",
      transform: {
        Scale: {
          x: 1,
          y: 1
        }
      },
      bottom: convertNumber2VP(0),
      left: convertNumber2VP(0),
      zIndex: 10000
    },
    "style_h5page__ur7Zn": {
      maxHeight: "100%"
    },
    "style_image__QhtkT": {
      width: "100%",
      height: "100%",
      display: "flex",
      alignItems: ItemAlign.Center,
      justifyContent: FlexAlign.Center
    },
    "style_loading__nVEJd": {
      position: "relative",
      width: convertNumber2VP(100, "vw"),
      height: convertNumber2VP(100, "vh")
    },
    "style_noneNavigation__W0Lnn": {
      position: "absolute",
      top: convertNumber2VP(0),
      left: convertNumber2VP(0),
      width: "100%"
    },
    "style_page__2c4W0": {
      width: convertNumber2VP(375),
      position: "relative",
      display: "flex",
      flexDirection: FlexDirection.Column,
      backgroundColor: "#fff",
      height: convertNumber2VP(100, "vh"),
      overflow: "hidden"
    },
    "style_popup__bisqh": {
      position: "fixed",
      top: convertNumber2VP(0),
      left: convertNumber2VP(0),
      width: convertNumber2VP(375),
      height: "100%",
      zIndex: 1001,
      display: "none"
    },
    "style_skeleton__Di6mB": {
      width: "100%"
    },
    "style_skeleton__iK542": {
      backgroundImage: {
        angle: 90,
        colors: [["#f0f0f0", 0.25], ["#e0e0e0", 0.5], ["#f0f0f0", 0.75]]
      },
      backgroundSize: {
        width: "200%",
        height: "100%"
      },
      animationDelay: 0,
      animationIterationCount: -1,
      animationDuration: 2500,
      animationTimeingFunction: "ease",
      animationName: [{
        "percentage": 0,
        "event": {
          backgroundPosition: {
            x: "-200%",
            y: 0
          }
        }
      }, {
        "percentage": 1,
        "event": {
          backgroundPosition: {
            x: "200%",
            y: 0
          }
        }
      }],
      borderTopLeftRadius: convertNumber2VP(3),
      borderTopRightRadius: convertNumber2VP(3),
      borderBottomLeftRadius: convertNumber2VP(3),
      borderBottomRightRadius: convertNumber2VP(3),
      opacity: 0.4
    },
    "style_tabBarPlaceholder__mRVDY": {
      width: convertNumber2VP(375),
      height: `auto`
    },
    "style_tabBar__Hevxs": {
      width: convertNumber2VP(375),
      boxShadow: {
        offsetX: convertNumber2VP(0),
        offsetY: convertNumber2VP(4),
        radius: convertNumber2VP(10),
        color: "rgba(0, 0, 0, 0.1)",
        fill: false
      },
      zIndex: 9999
    },
    "style_text__NdCnF": {
      wordBreak: "break-word",
      whiteSpace: "pre-wrap",
      display: "block",
      fontSize: convertNumber2VP(14),
      lineHeight: convertNumber2VP(16),
      color: "#333",
      position: "relative",
      overflow: "visible"
    },
    "style_tooltip__DH2mp": {
      width: "100%",
      borderTopLeftRadius: convertNumber2VP(5),
      borderTopRightRadius: convertNumber2VP(5),
      borderBottomLeftRadius: convertNumber2VP(5),
      borderBottomRightRadius: convertNumber2VP(5),
      position: "fixed",
      zIndex: 999999,
      top: convertNumber2VP(-10),
      left: "50%",
      transform: {
        Translate: {
          x: "-50%",
          y: "-100%"
        }
      },
      backgroundColor: "rgba(17, 17, 17, 0.7)",
      paddingTop: convertNumber2VP(6),
      paddingRight: convertNumber2VP(12),
      paddingBottom: convertNumber2VP(6),
      paddingLeft: convertNumber2VP(12),
      fontSize: convertNumber2VP(13),
      fontWeight: 500,
      lineHeight: convertNumber2VP(18),
      color: "#fff",
      pointerEvents: "none",
      ["::after"]: {
        boxSizing: "border-box",
        position: "absolute",
        width: convertNumber2VP(10),
        height: convertNumber2VP(10),
        borderTopWidth: convertNumber2VP(5),
        borderRightWidth: convertNumber2VP(5),
        borderBottomWidth: convertNumber2VP(5),
        borderLeftWidth: convertNumber2VP(5),
        borderTopStyle: BorderStyle.Solid,
        borderRightStyle: BorderStyle.Solid,
        borderBottomStyle: BorderStyle.Solid,
        borderLeftStyle: BorderStyle.Solid,
        borderTopColor: "rgba(17, 17, 17, 0.7)",
        borderRightColor: "rgba(0, 0, 0, 0)",
        borderBottomColor: "rgba(0, 0, 0, 0)",
        borderLeftColor: "rgba(0, 0, 0, 0)",
        bottom: convertNumber2VP(0),
        left: "50%",
        transform: {
          Translate: {
            x: "-50%",
            y: "100%"
          }
        },
        pointerEvents: "none"
      }
    }
  };
  return __inner_style_data__;
}
function _iterableToArrayLimit(r, l) {
  var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
  if (null != t) {
    var e,
      n,
      i,
      u,
      a = [],
      f = true,
      o = false;
    try {
      if (i = (t = t.call(r)).next, 0 === l) {
        if (Object(t) !== t) return;
        f = !1;
      } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0);
    } catch (r) {
      o = true, n = r;
    } finally {
      try {
        if (!f && null != t.return && (u = t.return(), Object(u) !== u)) return;
      } finally {
        if (o) throw n;
      }
    }
    return a;
  }
}
function ownKeys(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var o = Object.getOwnPropertySymbols(e);
    r && (o = o.filter(function (r) {
      return Object.getOwnPropertyDescriptor(e, r).enumerable;
    })), t.push.apply(t, o);
  }
  return t;
}
function _objectSpread2(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = null != arguments[r] ? arguments[r] : {};
    r % 2 ? ownKeys(Object(t), true).forEach(function (r) {
      _defineProperty(e, r, t[r]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) {
      Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
    });
  }
  return e;
}
function _toPrimitive(t, r) {
  if ("object" != typeof t || !t) return t;
  var e = t[Symbol.toPrimitive];
  if (void 0 !== e) {
    var i = e.call(t, r);
    if ("object" != typeof i) return i;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return ("string" === r ? String : Number)(t);
}
function _toPropertyKey(t) {
  var i = _toPrimitive(t, "string");
  return "symbol" == typeof i ? i : i + "";
}
function _typeof(o) {
  "@babel/helpers - typeof";

  return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) {
    return typeof o;
  } : function (o) {
    return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
  }, _typeof(o);
}
function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, _toPropertyKey(descriptor.key), descriptor);
  }
}
function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  Object.defineProperty(Constructor, "prototype", {
    writable: false
  });
  return Constructor;
}
function _defineProperty(obj, key, value) {
  key = _toPropertyKey(key);
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }
  return obj;
}
function _extends() {
  _extends = Object.assign ? Object.assign.bind() : function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends.apply(this, arguments);
}
function _objectWithoutPropertiesLoose(source, excluded) {
  if (source == null) return {};
  var target = {};
  var sourceKeys = Object.keys(source);
  var key, i;
  for (i = 0; i < sourceKeys.length; i++) {
    key = sourceKeys[i];
    if (excluded.indexOf(key) >= 0) continue;
    target[key] = source[key];
  }
  return target;
}
function _objectWithoutProperties(source, excluded) {
  if (source == null) return {};
  var target = _objectWithoutPropertiesLoose(source, excluded);
  var key, i;
  if (Object.getOwnPropertySymbols) {
    var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
    for (i = 0; i < sourceSymbolKeys.length; i++) {
      key = sourceSymbolKeys[i];
      if (excluded.indexOf(key) >= 0) continue;
      if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
      target[key] = source[key];
    }
  }
  return target;
}
function _slicedToArray(arr, i) {
  return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
}
function _arrayWithHoles(arr) {
  if (Array.isArray(arr)) return arr;
}
function _unsupportedIterableToArray(o, minLen) {
  if (!o) return;
  if (typeof o === "string") return _arrayLikeToArray(o, minLen);
  var n = Object.prototype.toString.call(o).slice(8, -1);
  if (n === "Object" && o.constructor) n = o.constructor.name;
  if (n === "Map" || n === "Set") return Array.from(o);
  if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}
function _arrayLikeToArray(arr, len) {
  if (len == null || len > arr.length) len = arr.length;
  for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];
  return arr2;
}
function _nonIterableRest() {
  throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function callCon(_ref) {
  var env = _ref.env,
    data = _ref.data;
  _ref.inputs;
  var outputs = _ref.outputs;
  _ref.onError;
  var params = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  if (data.connector || data.dynamicConfig) {
    try {
      var _finnalConnector;
      var finnalConnector = _objectSpread2(_objectSpread2({}, data.connector || {}), {}, {
        outputSchema: data.outputSchema
      });
      if (data.dynamicConfig) {
        finnalConnector = data.dynamicConfig;
      }
      if (data.timeout) {
        finnalConnector.timeout = data.timeout;
      }
      env.callConnector(finnalConnector, params, _objectSpread2(_objectSpread2({}, data.connectorConfig || {}), {}, {
        outputSchema: (_finnalConnector = finnalConnector) === null || _finnalConnector === void 0 ? void 0 : _finnalConnector.outputSchema,
        isMultipleOutputs: true
      })).then(function (val) {
        var _val$__OUTPUT_ID__, _val$__ORIGIN_RESPONS;
        outputs[(_val$__OUTPUT_ID__ = val === null || val === void 0 ? void 0 : val.__OUTPUT_ID__) !== null && _val$__OUTPUT_ID__ !== void 0 ? _val$__OUTPUT_ID__ : "then"]((_val$__ORIGIN_RESPONS = val === null || val === void 0 ? void 0 : val.__ORIGIN_RESPONSE__) !== null && _val$__ORIGIN_RESPONS !== void 0 ? _val$__ORIGIN_RESPONS : val);
      })["catch"](function (err) {
        outputs["catch"](err);
      });
    } catch (ex) {
      console.error(ex);
      outputs["catch"]("\u6267\u884C\u9519\u8BEF ".concat(ex.message || ex));
      //onError(ex.message)
    }
  } else {
    outputs["catch"]("\u6CA1\u6709\u9009\u62E9\u63A5\u53E3");
  }
}
function isPlainObject(value) {
  if (_typeof(value) !== "object" || value === null) return false;
  var proto = Object.getPrototypeOf(value);
  if (proto === null) return true; // 没有原型的对象也视为普通对象
  // 检查对象是否是由Object构造函数创建的
  return proto === Object.prototype;
}
function mybricks_taro__connector(_ref2) {
  var env = _ref2.env,
    data = _ref2.data,
    inputs = _ref2.inputs,
    outputs = _ref2.outputs,
    onError = _ref2.onError;
  if (!env.runtime) {
    return;
  }
  if (data.immediate) {
    callCon({
      env: env,
      data: data,
      outputs: outputs
    });
  } else {
    inputs["call"](function (params) {
      // 如果 params 不是 对象，则转换为空对象
      if (!isPlainObject(params)) {
        params = {};
      }
      callCon({
        env: env,
        data: data,
        outputs: outputs,
        onError: onError
      }, params);
    });
  }
}
function mybricks_taro__connectorGlobalHeaders(_ref) {
  var env = _ref.env;
  _ref.data;
  var inputs = _ref.inputs;
  _ref.outputs;
  _ref.onError;
  if (env.runtime) {
    //
    inputs["call"](function (obj, outputRels) {
      if (_typeof(obj) === "object" && obj !== null && !Array.isArray(obj)) {
        Taro.setStorageSync("_MYBRICKS_GLOBAL_HEADERS_", obj);
      }
      outputRels["then"](obj);
      return;
    });
  }
}
var rawWindowInterval = window.setInterval;
var rawWindowClearInterval = window.clearInterval;
var rawWindowTimeout = window.setTimeout;
var rawWindowClearTimeout = window.clearTimeout;
var originWindow = window;
var constructableMap = new WeakMap();
function isConstructable(fn) {
  if (constructableMap.has(fn)) {
    return constructableMap.get(fn);
  }
  var constructableFunctionRegex = /^function\b\s[A-Z].*/;
  var classRegex = /^class\b/;
  var constructable = fn.prototype && fn.prototype.constructor === fn && Object.getOwnPropertyNames(fn.prototype).length > 1 || constructableFunctionRegex.test(fn.toString()) || classRegex.test(fn.toString());
  constructableMap.set(fn, constructable);
  return constructable;
}
var isCallable = function isCallable(fn) {
  return typeof fn === 'function';
};
var boundedMap = new WeakMap();
function isBoundedFunction(fn) {
  if (boundedMap.has(fn)) {
    return boundedMap.get(fn);
  }
  var bounded = fn.name.indexOf('bound ') === 0 && !fn.hasOwnProperty('prototype');
  boundedMap.set(fn, bounded);
  return bounded;
}
var functionBoundedValueMap = new WeakMap();
function getTargetValue(target, value) {
  var cachedBoundFunction = functionBoundedValueMap.get(value);
  if (cachedBoundFunction) {
    return cachedBoundFunction;
  }
  var boundValue = Function.prototype.bind.call(value, target);
  for (var key in value) {
    boundValue[key] = value[key];
  }
  if (value.hasOwnProperty('prototype') && !boundValue.hasOwnProperty('prototype')) boundValue.prototype = value.prototype;
  functionBoundedValueMap.set(value, boundValue);
  return boundValue;
}
var unscopables = {
  undefined: true,
  Array: true,
  Object: true,
  String: true,
  Boolean: true,
  Math: true,
  Number: true,
  Symbol: true,
  parseFloat: true,
  Float32Array: true
};
function removeSemicolon(text) {
  while (text.trim().endsWith(';')) {
    text = text.slice(0, text.length - 1);
  }
  return text;
}
function getModuleScript(scriptText) {
  scriptText = removeSemicolon(scriptText);
  return "(\n                function(window, params, cb) {\n                    with(window) {\n                        return (".concat(scriptText, ")(...params, cb)\n                    }\n                }\n            )");
}
function getScript(scriptText) {
  scriptText = removeSemicolon(scriptText);
  return "(\n                function(window) {\n                    with(window){\n                        ".concat(scriptText, "\n                    } \n                }\n            ).bind(window.proxy)\n        ");
}
/**
 * 创建fakeWindow
 * @returns fakeWindow
 */
function createFakeWindow() {
  var fakeWindow = {};
  Object.getOwnPropertyNames(originWindow).forEach(function (key) {
    var descriptor = Object.getOwnPropertyDescriptor(originWindow, key);
    if (descriptor && !descriptor.configurable) {
      var hasGetter = Object.prototype.hasOwnProperty.call(descriptor, 'get');
      if (key === 'top' || key === 'parent' || key === 'self' || key === 'window') {
        descriptor.configurable = true;
        if (!hasGetter) {
          descriptor.writable = true;
        }
      }
      Object.defineProperty(fakeWindow, key, Object.freeze(descriptor));
    }
  });
  return fakeWindow;
}
/**
 * 将 window 的属性 p 拷贝到 fakeWindow
 * @param p 
 * @param fakeWindow 
 */
function copyFromWindow(p, fakeWindow) {
  var descriptor = Object.getOwnPropertyDescriptor(window, p);
  if (descriptor && descriptor.writable) {
    Object.defineProperty(fakeWindow, p, {
      configurable: descriptor.configurable,
      enumerable: descriptor.enumerable,
      writable: descriptor.writable,
      value: descriptor.value
    });
  }
}
var Sandbox = /*#__PURE__*/function () {
  // @ts-ignore
  function Sandbox() {
    var _this = this;
    var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    _classCallCheck(this, Sandbox);
    _defineProperty(this, "proxy", void 0);
    _defineProperty(this, "hasDisposed", false);
    _defineProperty(this, "fakeWindow", createFakeWindow());
    _defineProperty(this, "timeoutList", []);
    _defineProperty(this, "intervalList", []);
    _defineProperty(this, "options", {});
    this.options = options || {};
    this.proxy = new Proxy(window, {
      set: function set(target, key, value) {
        if (!_this.hasDisposed) {
          try {
            if (!_this.fakeWindow.hasOwnProperty(key) && target.hasOwnProperty(key)) {
              // @ts-ignore
              copyFromWindow(key, _this.fakeWindow);
            }
            // @ts-ignore
            _this.fakeWindow[key] = value; // 赋值
          } catch (error) {
            console.error('set-key-error', key, error);
            throw error;
          }
        }
        return true;
      },
      get: function get(target, key) {
        if (key === Symbol.unscopables) {
          return unscopables;
        }
        if (key === 'window' || key === 'self') {
          return _this.proxy;
        }
        if (key === 'document') {
          return undefined;
        }
        if (key === 'hasOwnProperty') {
          return target.hasOwnProperty;
        }
        if (key === 'eval') {
          return target.eval;
        }
        if (key === 'location') {
          return target.location;
        }
        try {
          // @ts-ignore
          var value = key in _this.fakeWindow ? _this.fakeWindow[key] : target[key];
          // 仅绑定 isCallable && !isBoundedFunction && !isConstructable 的函数对象，如 window.console、window.atob 这类，
          // 不然微应用中调用时会抛出 Illegal invocation 异常
          if (isCallable(value) && !isBoundedFunction(value) && !isConstructable(value)) {
            value = Function.prototype.bind.call(value, target);
            return getTargetValue(window, value);
          }
          return value;
        } catch (error) {
          console.error('get-key-error', key, error);
          throw error;
        }
      },
      has: function has(target, key) {
        // @ts-ignore
        if (_this.options.module) {
          //参数允许逃逸到函数局部变量
          if (key === 'params' || key === 'cb') {
            return false;
          }
        }
        return true; // 伪造属性的存在性阻止沙盒逃逸
      }
    });
    this.proxy.setTimeout = function (handler, timeout) {
      if (!_this.hasDisposed) {
        for (var _len = arguments.length, args = new Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++) {
          args[_key - 2] = arguments[_key];
        }
        var timeoutId = rawWindowTimeout.apply(void 0, [handler, timeout].concat(args));
        // @ts-ignore
        _this.timeoutList.push(timeoutId);
        return timeoutId;
      } else {
        return 0;
      }
    };
    this.proxy.clearTimeout = function (timeoutId) {
      // @ts-ignore
      var timeoutIndex = _this.timeoutList.indexOf(timeoutId);
      if (timeoutIndex !== -1) {
        _this.timeoutList.splice(timeoutIndex, 1);
      }
      return rawWindowClearTimeout(timeoutId);
    };
    this.proxy.setInterval = function (handler, timeout) {
      if (!_this.hasDisposed) {
        for (var _len2 = arguments.length, args = new Array(_len2 > 2 ? _len2 - 2 : 0), _key2 = 2; _key2 < _len2; _key2++) {
          args[_key2 - 2] = arguments[_key2];
        }
        var intervalId = rawWindowInterval.apply(void 0, [handler, timeout].concat(args));
        // @ts-ignore
        _this.intervalList.push(intervalId);
        return intervalId;
      } else {
        return 0;
      }
    };
    this.proxy.clearInterval = function (intervalId) {
      // @ts-ignore
      var intervalIndex = _this.intervalList.indexOf(intervalId);
      if (intervalIndex !== -1) {
        _this.intervalList.splice(intervalIndex, 1);
      }
      return rawWindowClearInterval(intervalId);
    };
    // @ts-ignore
    originWindow.proxy = this.proxy;
  }
  // @ts-ignore
  return _createClass(Sandbox, [{
    key: "compile",
    value: function compile(scriptText) {
      if (this.hasDisposed) {
        throw new Error('sandbox has been destroyed');
      }
      // @ts-ignore
      var isModule = this.options.module;
      var scriptTextWithSandbox;
      if (isModule) {
        scriptTextWithSandbox = getModuleScript(scriptText);
      } else {
        scriptTextWithSandbox = getScript(scriptText);
      }
      var fn = originWindow.eval("".concat(scriptTextWithSandbox, ";//@ sourceURL=sandbox-code.js"));
      return {
        // @ts-ignore
        run: function run(model, cb) {
          try {
            if (isModule) {
              // @ts-ignore
              return fn(window.proxy, model, cb);
            } else {
              // @ts-ignore
              return fn(window.proxy);
            }
          } catch (err) {
            console.error("js sandbox error occur:", err);
            throw err;
          }
        }
      };
    }
  }, {
    key: "dispose",
    value: function dispose() {
      this.timeoutList.forEach(function (timeoutId) {
        window.clearTimeout(timeoutId);
      });
      this.timeoutList = [];
      this.intervalList.forEach(function (intervalId) {
        return rawWindowClearInterval(intervalId);
      });
      this.intervalList = [];
      this.fakeWindow = createFakeWindow();
      this.options = {};
      // @ts-ignore
      delete originWindow.proxy;
      this.hasDisposed = true;
      // console.info('Sandbox was successfully destroyed')
    }
  }]);
}();
var safeDecoder = function safeDecoder(str) {
  try {
    return decodeURIComponent(str);
  } catch (error) {
    return str;
  }
};
var safeEncoder = function safeEncoder(str) {
  try {
    return encodeURIComponent(str);
  } catch (error) {
    return str;
  }
};
function runJs(scriptText, model, props) {
  var _scriptText3;
  var _ref = {},
    _ref$callback = _ref.callback,
    callback = _ref$callback === void 0 ? function () {} : _ref$callback;
  if (_typeof(scriptText) === 'object' && scriptText !== null) {
    var _scriptText$transform, _scriptText, _scriptText2;
    scriptText = (_scriptText$transform = (_scriptText = scriptText) === null || _scriptText === void 0 ? void 0 : _scriptText.transformCode) !== null && _scriptText$transform !== void 0 ? _scriptText$transform : (_scriptText2 = scriptText) === null || _scriptText2 === void 0 ? void 0 : _scriptText2.code;
  }
  if (!((_scriptText3 = scriptText) !== null && _scriptText3 !== void 0 && _scriptText3.includes('var%20_RTFN_'))) {
    scriptText = transform(scriptText);
  }
  var fn, sandbox;
  if (model && model.length) {
    sandbox = new Sandbox({
      module: true
    });
    var sourceStr = safeDecoder(scriptText);
    if (/export\s+default.*async.*function.*\(/g.test(sourceStr)) {
      fn = sandbox.compile("".concat(sourceStr.replace(/export\s+default.*function.*\(/g, 'async function _RT_(')));
    } else {
      fn = sandbox.compile("".concat(sourceStr.replace(/export\s+default.*function.*\(/g, 'function _RT_(')));
    }
  } else {
    sandbox = new Sandbox();
    fn = sandbox.compile("".concat(safeDecoder(scriptText)));
  }
  fn.run(model, callback);
  return sandbox;
}
var transform = function transform(scriptText) {
  scriptText = safeDecoder(scriptText);
  try {
    if (!window.Babel) {
      throw Error('Babel was not found in window');
    }
    var _window$Babel$transfo = window.Babel.transform("_RTFN_ = ".concat(scriptText, " "), {
        presets: ['env', 'typescript'],
        parserOpts: {
          strictMode: false
        },
        comments: false,
        filename: 'types.d.ts'
      }),
      code = _window$Babel$transfo.code;
    code = "(function() { var _RTFN_; \n".concat(code, "\n return _RTFN_; })()");
    return safeEncoder(code);
  } catch (error) {
    console.error(error);
    return safeEncoder(scriptText);
  }
};
function convertObject2Array(input) {
  var result = [];
  Object.keys(input).sort(function (a, b) {
    var _a$match, _b$match;
    var _a = (a === null || a === void 0 || (_a$match = a.match(/\d+/g)) === null || _a$match === void 0 ? void 0 : _a$match[0]) || 0;
    var _b = (b === null || b === void 0 || (_b$match = b.match(/\d+/g)) === null || _b$match === void 0 ? void 0 : _b$match[0]) || 0;
    return +_a - +_b;
  }).forEach(function (key) {
    result.push(input[key]);
  });
  return result;
}
function mybricks_taro__muilt_inputJs(_ref) {
  var env = _ref.env,
    data = _ref.data,
    inputs = _ref.inputs,
    outputs = _ref.outputs,
    logger = _ref.logger,
    onError = _ref.onError;
  var fns = data.fns,
    runImmediate = data.runImmediate;
  var runJSParams = {
    outputs: convertObject2Array(outputs),
    logger: logger
  };
  var sandbox;
  try {
    var _env$runtime;
    if (runImmediate) {
      if (env.runtime) {
        sandbox = runJs(fns, [runJSParams]);
      }
    }
    inputs['input'](function (val) {
      try {
        sandbox = runJs(fns, [_objectSpread2(_objectSpread2({}, runJSParams), {}, {
          inputs: convertObject2Array(val)
        })]);
      } catch (ex) {
        onError === null || onError === void 0 || onError(ex);
        console.error('js计算组件运行错误.', ex);
        logger.error("".concat(ex));
      }
    });
    if (typeof (env === null || env === void 0 || (_env$runtime = env.runtime) === null || _env$runtime === void 0 ? void 0 : _env$runtime.onComplete) === 'function') {
      env.runtime.onComplete(function () {
        var _sandbox;
        (_sandbox = sandbox) === null || _sandbox === void 0 || _sandbox.dispose();
      });
    }
  } catch (ex) {
    onError === null || onError === void 0 || onError(ex);
    console.error('js计算组件运行错误.', ex);
    logger.error("".concat(ex));
  }
}
var FormatType = /*#__PURE__*/function (FormatType) {
  FormatType["NONE"] = "NONE";
  FormatType["KEYMAP"] = "KEYMAP";
  FormatType["TIME_TEMPLATE"] = "TIME_TEMPLATE";
  FormatType["TIME_CUSTOM"] = "TIME_CUSTOM";
  return FormatType;
}({}); // PRICE_CUSTOM = 'PRICE_CUSTOM'
_defineProperty(_defineProperty(_defineProperty(_defineProperty({}, FormatType.NONE, {
  label: '保持原值',
  name: FormatType.NONE
}), FormatType.KEYMAP, {
  label: '枚举映射',
  name: FormatType.KEYMAP,
  genEditor: function genEditor() {
    return {
      type: 'map'
    };
  }
}), FormatType.TIME_TEMPLATE, {
  label: '时间戳转化',
  name: FormatType.TIME_TEMPLATE,
  genEditor: function genEditor(options) {
    return {
      type: 'select',
      description: '待转换数据格式为字符串或数字型时间戳',
      options: _objectSpread2({
        options: [{
          label: '年-月-日 时:分:秒',
          value: 'YYYY-MM-DD HH:mm:ss'
        }, {
          label: '月-日 时:分:秒',
          value: 'MM-DD HH:mm:ss'
        }, {
          label: '年-月-日',
          value: 'YYYY-MM-DD'
        }, {
          label: '月-日',
          value: 'MM-DD'
        }, {
          label: '时:分:秒',
          value: 'HH:mm:ss'
        }]
      }, options)
    };
  }
}), FormatType.TIME_CUSTOM, {
  label: '自定义时间戳转化',
  name: FormatType.TIME_CUSTOM,
  genEditor: function genEditor(options) {
    return {
      type: 'text',
      description: '待转换数据格式为字符串或数字型时间戳',
      options: _objectSpread2({
        placeholder: 'YYYY-MM-DD HH:mm:ss'
      }, options)
    };
  }
});
function isType(type) {
  return function (value) {
    return Object.prototype.toString.call(value) === "[object ".concat(type, "]");
  };
}
/**
 * 判断是否是未定义
 * @param value 入参cd
 * @returns true/false，undefined、null返回true
 */
function isUndef(value) {
  return value === undefined || value === null;
}
/**
 * 判断是否为Number类型
 * @param value 入参
 */
function isNumber(value) {
  return isType('Number')(value);
}
/**
 * 判断是否为String类型
 * @param value 入参
 */
function isString(value) {
  return isType('String')(value);
}
/**
 * 判断是否为Date类型
 * @param value 入参
 */
function isDate(value) {
  return isType('Date')(value);
}
/**
 * 判断是否为严格Object类型
 * @param value 入参
 */
function isObject(value) {
  return isType('Object')(value);
}
function getDefaultExportFromCjs(x) {
  return x && x.__esModule && Object.prototype.hasOwnProperty.call(x, 'default') ? x['default'] : x;
}
var dayjs_min$1 = {
  exports: {}
};
var dayjs_min = dayjs_min$1.exports;
var hasRequiredDayjs_min;
function requireDayjs_min() {
  if (hasRequiredDayjs_min) return dayjs_min$1.exports;
  hasRequiredDayjs_min = 1;
  (function (module, exports) {
    !function (t, e) {
      module.exports = e();
    }(dayjs_min, function () {
      var t = 1e3,
        e = 6e4,
        n = 36e5,
        r = "millisecond",
        i = "second",
        s = "minute",
        u = "hour",
        a = "day",
        o = "week",
        c = "month",
        f = "quarter",
        h = "year",
        d = "date",
        l = "Invalid Date",
        $ = /^(\d{4})[-/]?(\d{1,2})?[-/]?(\d{0,2})[Tt\s]*(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?[.:]?(\d+)?$/,
        y = /\[([^\]]+)]|Y{1,4}|M{1,4}|D{1,2}|d{1,4}|H{1,2}|h{1,2}|a|A|m{1,2}|s{1,2}|Z{1,2}|SSS/g,
        M = {
          name: "en",
          weekdays: "Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"),
          months: "January_February_March_April_May_June_July_August_September_October_November_December".split("_"),
          ordinal: function (t) {
            var e = ["th", "st", "nd", "rd"],
              n = t % 100;
            return "[" + t + (e[(n - 20) % 10] || e[n] || e[0]) + "]";
          }
        },
        m = function (t, e, n) {
          var r = String(t);
          return !r || r.length >= e ? t : "" + Array(e + 1 - r.length).join(n) + t;
        },
        v = {
          s: m,
          z: function (t) {
            var e = -t.utcOffset(),
              n = Math.abs(e),
              r = Math.floor(n / 60),
              i = n % 60;
            return (e <= 0 ? "+" : "-") + m(r, 2, "0") + ":" + m(i, 2, "0");
          },
          m: function t(e, n) {
            if (e.date() < n.date()) return -t(n, e);
            var r = 12 * (n.year() - e.year()) + (n.month() - e.month()),
              i = e.clone().add(r, c),
              s = n - i < 0,
              u = e.clone().add(r + (s ? -1 : 1), c);
            return +(-(r + (n - i) / (s ? i - u : u - i)) || 0);
          },
          a: function (t) {
            return t < 0 ? Math.ceil(t) || 0 : Math.floor(t);
          },
          p: function (t) {
            return {
              M: c,
              y: h,
              w: o,
              d: a,
              D: d,
              h: u,
              m: s,
              s: i,
              ms: r,
              Q: f
            }[t] || String(t || "").toLowerCase().replace(/s$/, "");
          },
          u: function (t) {
            return void 0 === t;
          }
        },
        g = "en",
        D = {};
      D[g] = M;
      var p = "$isDayjsObject",
        S = function (t) {
          return t instanceof _ || !(!t || !t[p]);
        },
        w = function t(e, n, r) {
          var i;
          if (!e) return g;
          if ("string" == typeof e) {
            var s = e.toLowerCase();
            D[s] && (i = s), n && (D[s] = n, i = s);
            var u = e.split("-");
            if (!i && u.length > 1) return t(u[0]);
          } else {
            var a = e.name;
            D[a] = e, i = a;
          }
          return !r && i && (g = i), i || !r && g;
        },
        O = function (t, e) {
          if (S(t)) return t.clone();
          var n = "object" == typeof e ? e : {};
          return n.date = t, n.args = arguments, new _(n);
        },
        b = v;
      b.l = w, b.i = S, b.w = function (t, e) {
        return O(t, {
          locale: e.$L,
          utc: e.$u,
          x: e.$x,
          $offset: e.$offset
        });
      };
      var _ = function () {
          function M(t) {
            this.$L = w(t.locale, null, true), this.parse(t), this.$x = this.$x || t.x || {}, this[p] = true;
          }
          var m = M.prototype;
          return m.parse = function (t) {
            this.$d = function (t) {
              var e = t.date,
                n = t.utc;
              if (null === e) return new Date(NaN);
              if (b.u(e)) return new Date();
              if (e instanceof Date) return new Date(e);
              if ("string" == typeof e && !/Z$/i.test(e)) {
                var r = e.match($);
                if (r) {
                  var i = r[2] - 1 || 0,
                    s = (r[7] || "0").substring(0, 3);
                  return n ? new Date(Date.UTC(r[1], i, r[3] || 1, r[4] || 0, r[5] || 0, r[6] || 0, s)) : new Date(r[1], i, r[3] || 1, r[4] || 0, r[5] || 0, r[6] || 0, s);
                }
              }
              return new Date(e);
            }(t), this.init();
          }, m.init = function () {
            var t = this.$d;
            this.$y = t.getFullYear(), this.$M = t.getMonth(), this.$D = t.getDate(), this.$W = t.getDay(), this.$H = t.getHours(), this.$m = t.getMinutes(), this.$s = t.getSeconds(), this.$ms = t.getMilliseconds();
          }, m.$utils = function () {
            return b;
          }, m.isValid = function () {
            return !(this.$d.toString() === l);
          }, m.isSame = function (t, e) {
            var n = O(t);
            return this.startOf(e) <= n && n <= this.endOf(e);
          }, m.isAfter = function (t, e) {
            return O(t) < this.startOf(e);
          }, m.isBefore = function (t, e) {
            return this.endOf(e) < O(t);
          }, m.$g = function (t, e, n) {
            return b.u(t) ? this[e] : this.set(n, t);
          }, m.unix = function () {
            return Math.floor(this.valueOf() / 1e3);
          }, m.valueOf = function () {
            return this.$d.getTime();
          }, m.startOf = function (t, e) {
            var n = this,
              r = !!b.u(e) || e,
              f = b.p(t),
              l = function (t, e) {
                var i = b.w(n.$u ? Date.UTC(n.$y, e, t) : new Date(n.$y, e, t), n);
                return r ? i : i.endOf(a);
              },
              $ = function (t, e) {
                return b.w(n.toDate()[t].apply(n.toDate("s"), (r ? [0, 0, 0, 0] : [23, 59, 59, 999]).slice(e)), n);
              },
              y = this.$W,
              M = this.$M,
              m = this.$D,
              v = "set" + (this.$u ? "UTC" : "");
            switch (f) {
              case h:
                return r ? l(1, 0) : l(31, 11);
              case c:
                return r ? l(1, M) : l(0, M + 1);
              case o:
                var g = this.$locale().weekStart || 0,
                  D = (y < g ? y + 7 : y) - g;
                return l(r ? m - D : m + (6 - D), M);
              case a:
              case d:
                return $(v + "Hours", 0);
              case u:
                return $(v + "Minutes", 1);
              case s:
                return $(v + "Seconds", 2);
              case i:
                return $(v + "Milliseconds", 3);
              default:
                return this.clone();
            }
          }, m.endOf = function (t) {
            return this.startOf(t, false);
          }, m.$set = function (t, e) {
            var n,
              o = b.p(t),
              f = "set" + (this.$u ? "UTC" : ""),
              l = (n = {}, n[a] = f + "Date", n[d] = f + "Date", n[c] = f + "Month", n[h] = f + "FullYear", n[u] = f + "Hours", n[s] = f + "Minutes", n[i] = f + "Seconds", n[r] = f + "Milliseconds", n)[o],
              $ = o === a ? this.$D + (e - this.$W) : e;
            if (o === c || o === h) {
              var y = this.clone().set(d, 1);
              y.$d[l]($), y.init(), this.$d = y.set(d, Math.min(this.$D, y.daysInMonth())).$d;
            } else l && this.$d[l]($);
            return this.init(), this;
          }, m.set = function (t, e) {
            return this.clone().$set(t, e);
          }, m.get = function (t) {
            return this[b.p(t)]();
          }, m.add = function (r, f) {
            var d,
              l = this;
            r = Number(r);
            var $ = b.p(f),
              y = function (t) {
                var e = O(l);
                return b.w(e.date(e.date() + Math.round(t * r)), l);
              };
            if ($ === c) return this.set(c, this.$M + r);
            if ($ === h) return this.set(h, this.$y + r);
            if ($ === a) return y(1);
            if ($ === o) return y(7);
            var M = (d = {}, d[s] = e, d[u] = n, d[i] = t, d)[$] || 1,
              m = this.$d.getTime() + r * M;
            return b.w(m, this);
          }, m.subtract = function (t, e) {
            return this.add(-1 * t, e);
          }, m.format = function (t) {
            var e = this,
              n = this.$locale();
            if (!this.isValid()) return n.invalidDate || l;
            var r = t || "YYYY-MM-DDTHH:mm:ssZ",
              i = b.z(this),
              s = this.$H,
              u = this.$m,
              a = this.$M,
              o = n.weekdays,
              c = n.months,
              f = n.meridiem,
              h = function (t, n, i, s) {
                return t && (t[n] || t(e, r)) || i[n].slice(0, s);
              },
              d = function (t) {
                return b.s(s % 12 || 12, t, "0");
              },
              $ = f || function (t, e, n) {
                var r = t < 12 ? "AM" : "PM";
                return n ? r.toLowerCase() : r;
              };
            return r.replace(y, function (t, r) {
              return r || function (t) {
                switch (t) {
                  case "YY":
                    return String(e.$y).slice(-2);
                  case "YYYY":
                    return b.s(e.$y, 4, "0");
                  case "M":
                    return a + 1;
                  case "MM":
                    return b.s(a + 1, 2, "0");
                  case "MMM":
                    return h(n.monthsShort, a, c, 3);
                  case "MMMM":
                    return h(c, a);
                  case "D":
                    return e.$D;
                  case "DD":
                    return b.s(e.$D, 2, "0");
                  case "d":
                    return String(e.$W);
                  case "dd":
                    return h(n.weekdaysMin, e.$W, o, 2);
                  case "ddd":
                    return h(n.weekdaysShort, e.$W, o, 3);
                  case "dddd":
                    return o[e.$W];
                  case "H":
                    return String(s);
                  case "HH":
                    return b.s(s, 2, "0");
                  case "h":
                    return d(1);
                  case "hh":
                    return d(2);
                  case "a":
                    return $(s, u, true);
                  case "A":
                    return $(s, u, false);
                  case "m":
                    return String(u);
                  case "mm":
                    return b.s(u, 2, "0");
                  case "s":
                    return String(e.$s);
                  case "ss":
                    return b.s(e.$s, 2, "0");
                  case "SSS":
                    return b.s(e.$ms, 3, "0");
                  case "Z":
                    return i;
                }
                return null;
              }(t) || i.replace(":", "");
            });
          }, m.utcOffset = function () {
            return 15 * -Math.round(this.$d.getTimezoneOffset() / 15);
          }, m.diff = function (r, d, l) {
            var $,
              y = this,
              M = b.p(d),
              m = O(r),
              v = (m.utcOffset() - this.utcOffset()) * e,
              g = this - m,
              D = function () {
                return b.m(y, m);
              };
            switch (M) {
              case h:
                $ = D() / 12;
                break;
              case c:
                $ = D();
                break;
              case f:
                $ = D() / 3;
                break;
              case o:
                $ = (g - v) / 6048e5;
                break;
              case a:
                $ = (g - v) / 864e5;
                break;
              case u:
                $ = g / n;
                break;
              case s:
                $ = g / e;
                break;
              case i:
                $ = g / t;
                break;
              default:
                $ = g;
            }
            return l ? $ : b.a($);
          }, m.daysInMonth = function () {
            return this.endOf(c).$D;
          }, m.$locale = function () {
            return D[this.$L];
          }, m.locale = function (t, e) {
            if (!t) return this.$L;
            var n = this.clone(),
              r = w(t, e, true);
            return r && (n.$L = r), n;
          }, m.clone = function () {
            return b.w(this.$d, this);
          }, m.toDate = function () {
            return new Date(this.valueOf());
          }, m.toJSON = function () {
            return this.isValid() ? this.toISOString() : null;
          }, m.toISOString = function () {
            return this.$d.toISOString();
          }, m.toString = function () {
            return this.$d.toUTCString();
          }, M;
        }(),
        k = _.prototype;
      return O.prototype = k, [["$ms", r], ["$s", i], ["$m", s], ["$H", u], ["$W", a], ["$M", c], ["$y", h], ["$D", d]].forEach(function (t) {
        k[t[1]] = function (e) {
          return this.$g(e, t[0], t[1]);
        };
      }), O.extend = function (t, e) {
        return t.$i || (t(e, _, O), t.$i = true), O;
      }, O.locale = w, O.isDayjs = S, O.unix = function (t) {
        return O(1e3 * t);
      }, O.en = D[g], O.Ls = D, O.p = {}, O;
    });
  })(dayjs_min$1);
  return dayjs_min$1.exports;
}
var dayjs_minExports = requireDayjs_min();
var dayjs = /*@__PURE__*/getDefaultExportFromCjs(dayjs_minExports);
var transfromData = function transfromData(value, formatType, config) {
  var result = value;
  if (formatType === FormatType.NONE) {
    return result;
  }
  if (formatType === FormatType.KEYMAP) {
    var _config$result;
    return (_config$result = config === null || config === void 0 ? void 0 : config[result]) !== null && _config$result !== void 0 ? _config$result : result;
  }
  if (formatType === FormatType.TIME_TEMPLATE || formatType === FormatType.TIME_CUSTOM) {
    return dayjs(value).format(config);
  }
  return result;
};
function mybricks_taro__format(_ref) {
  var env = _ref.env,
    data = _ref.data,
    inputs = _ref.inputs,
    outputs = _ref.outputs;
  if (!env.runtime) {
    return;
  }
  inputs["call"](function (inputValue) {
    if (env.runtime) {
      var _data$formatData, _data$formatData2;
      var resValue = inputValue;
      var _ref2 = (_data$formatData = data.formatData) !== null && _data$formatData !== void 0 ? _data$formatData : {},
        formatterName = _ref2.formatterName,
        values = _ref2.values;
      if (isUndef(inputValue) && data !== null && data !== void 0 && (_data$formatData2 = data.formatData) !== null && _data$formatData2 !== void 0 && _data$formatData2.voidHandle) {
        var _data$formatData3;
        resValue = data === null || data === void 0 || (_data$formatData3 = data.formatData) === null || _data$formatData3 === void 0 ? void 0 : _data$formatData3.voidTo;
        outputs["success"](resValue);
        return;
      }
      if (!isString(inputValue) && !isNumber(inputValue) && !isDate(inputValue)) {
        outputs["success"](resValue);
        return;
      }
      resValue = transfromData(inputValue, formatterName, values === null || values === void 0 ? void 0 : values[formatterName]);
      outputs["success"](resValue);
      return;
    }
  });
}
var InputIds = {
  Trigger: 'trigger',
  Cancel: 'cancel'
};
/**
 * 数据源
 * @param id 定时器ID
 * @param delay 延迟时间
 * @param useCancel 开启取消
 */ // TODO: 调试结束清除定时器
function mybricks_taro__timerDelay(props) {
  var env = props.env,
    data = props.data,
    outputs = props.outputs,
    inputs = props.inputs;
  var timer;
  if (env !== null && env !== void 0 && env.runtime && inputs) {
    var _inputs$InputIds$Canc;
    inputs[InputIds.Trigger](function (val) {
      clearInterval(timer);
      timer = setTimeout(function () {
        outputs[InputIds.Trigger](val);
      }, data.delay);
    });
    (_inputs$InputIds$Canc = inputs[InputIds.Cancel]) === null || _inputs$InputIds$Canc === void 0 || _inputs$InputIds$Canc.call(inputs, function () {
      clearTimeout(timer);
    });
  }
}
function mybricks_taro__setStorage(_ref) {
  var env = _ref.env;
  _ref.data;
  var inputs = _ref.inputs,
    outputs = _ref.outputs;
  _ref.logger;
  if (!env.runtime) {
    return;
  }
  inputs["setStorage"](function (props) {
    try {
      Object.keys(props).forEach(function (key) {
        Taro.setStorageSync(key, props[key]);
      });
      outputs["onSuccess"](props);
    } catch (e) {
      outputs["onFail"](props);
    }
  });
}
function mybricks_taro__getStorage(_ref) {
  var env = _ref.env,
    data = _ref.data,
    inputs = _ref.inputs,
    outputs = _ref.outputs;
  _ref.logger;
  if (!env.runtime) {
    return;
  }
  inputs["getStorage"](function (key) {
    var myKey = data.useDynamicKey ? key : data.key;
    if (!myKey || typeof myKey !== "string") {
      outputs["onComplete"](null);
      return;
    }
    try {
      var value = Taro.getStorageSync(myKey);
      outputs["onComplete"](value);
    } catch (e) {
      outputs["onComplete"](null);
    }
  });
}
var ExtLinkype = /*#__PURE__*/function (ExtLinkype) {
  ExtLinkype["miniapp_open"] = "miniapp_open";
  ExtLinkype["parent_open"] = "parent_open";
  ExtLinkype["parent_back"] = "parent_back";
  ExtLinkype["web_open"] = "web_open";
  return ExtLinkype;
}({});
var OpenType = /*#__PURE__*/function (OpenType) {
  OpenType["navigate"] = "navigate";
  OpenType["redirect"] = "redirect";
  OpenType["relaunch"] = "relaunch";
  return OpenType;
}({});
var runtimeEnv = function runtimeEnv() {
  var isH5 = Taro.getEnv() === Taro.ENV_TYPE.WEB || Taro.getEnv() === "Unknown";
  if (isH5) {
    if (window.__wxjs_environment === "miniprogram") {
      return "IN_WEAPP";
    }
    if (/(MicroMessenger)/i.test(navigator.userAgent)) {
      return "IN_WEIXIN";
    }
    return Taro.ENV_TYPE.WEB;
  } else {
    return Taro.getEnv();
  }
};
function mybricks_taro_open(_ref) {
  var env = _ref.env,
    data = _ref.data,
    inputs = _ref.inputs,
    outputs = _ref.outputs;
  if (env.runtime && !env.runtime.debug) {
    inputs["open"](function (value) {
      var _validValue$url;
      var validValue = isObject(value) ? value : {};
      var finalUrl = (_validValue$url = validValue === null || validValue === void 0 ? void 0 : validValue.url) !== null && _validValue$url !== void 0 ? _validValue$url : data.url;
      var _env = runtimeEnv();
      switch (true) {
        case data.type === ExtLinkype.parent_open:
          {
            var _wx;
            var params = {
              url: finalUrl,
              success: function success() {
                outputs["onSuccess"]();
              },
              fail: function fail() {
                outputs["onFail"]();
              }
            };
            if (_env === "IN_WEAPP" && (_wx = wx) !== null && _wx !== void 0 && _wx.miniProgram) {
              if (data.openType === OpenType.redirect) {
                var _wx$miniProgram, _wx$miniProgram$redir;
                (_wx$miniProgram = wx.miniProgram) === null || _wx$miniProgram === void 0 || (_wx$miniProgram$redir = _wx$miniProgram.redirectTo) === null || _wx$miniProgram$redir === void 0 || _wx$miniProgram$redir.call(_wx$miniProgram, params);
              } else {
                var _wx$miniProgram2, _wx$miniProgram2$navi;
                (_wx$miniProgram2 = wx.miniProgram) === null || _wx$miniProgram2 === void 0 || (_wx$miniProgram2$navi = _wx$miniProgram2.navigateTo) === null || _wx$miniProgram2$navi === void 0 || _wx$miniProgram2$navi.call(_wx$miniProgram2, params);
              }
            }
            break;
          }
        case data.type === ExtLinkype.parent_back:
          {
            var _wx2;
            if (_env === "IN_WEAPP" && (_wx2 = wx) !== null && _wx2 !== void 0 && (_wx2 = _wx2.miniProgram) !== null && _wx2 !== void 0 && _wx2.navigateBack) {
              wx.miniProgram.navigateBack({
                success: function success() {
                  outputs["onSuccess"]();
                },
                fail: function fail() {
                  outputs["onFail"]();
                }
              });
            }
            break;
          }
        case data.type === ExtLinkype.web_open:
          {
            // H5环境下
            if ((Taro.getEnv() === Taro.ENV_TYPE.WEB || Taro.getEnv() === "Unknown") && finalUrl) {
              if (data.openType === OpenType.redirect) {
                location.href = finalUrl;
                outputs["onSuccess"]();
              } else {
                // 微信小程序内不支持 window.open 
                window.open(finalUrl);
                outputs["onSuccess"]();
              }
            }
            break;
          }
        case data.type === ExtLinkype.miniapp_open:
          {
            Taro.navigateToMiniProgram(_objectSpread2(_objectSpread2({}, validValue), {}, {
              success: function success(e) {
                outputs["onSuccess"](e);
              },
              fail: function fail(e) {
                outputs["onFail"](e);
              }
            }));
            break;
          }
      }
    });
  }
}
function mybricks_taro__goto(_ref) {
  var env = _ref.env,
    data = _ref.data,
    inputs = _ref.inputs;
  _ref.outputs;
  _ref._inputsCallable;
  if (!env.runtime) {
    return;
  }
  inputs["goto"](function (val) {
    var sceneId = getSceneIdFromPath(val);
    // 从 val 中解析出参数
    var params = getParamsFromPath(val);
    console.log("env", env, "sceneId", sceneId, "params", params, "data.action", data.action);
    if (env.runtime.debug) {
      env.canvas.open(sceneId, params, data.action);
    } else {
      if (data.action === "redirectTo") {
        Taro.redirectTo({
          url: val
        });
      } else if (data.action === "navigateTo") {
        Taro.navigateTo({
          url: val
        });
      } else if (data.action === "reLaunch") {
        Taro.reLaunch({
          url: val
        });
      }
    }
  });
  function getSceneIdFromPath(path) {
    // path 可能的格式为 /pages/U_aabb/index?sceneId=123
    // sceneId 为 pages 后面的这段 U_aabb
    if (!path) {
      return;
    }
    var parts = path.split("/");
    var sceneId = parts[2];
    return sceneId;
  }
  function getParamsFromPath(path) {
    var parts = path.split("?");
    if (parts.length < 2) {
      return {};
    }
    var paramsStr = parts[1] || "";
    var params = {};
    paramsStr.split("&").forEach(function (item) {
      var _item$split = item.split("="),
        _item$split2 = _slicedToArray(_item$split, 2),
        key = _item$split2[0],
        value = _item$split2[1];
      // value 可能经过 encodeURIComponent 编码，需要解码
      try {
        value = decodeURIComponent(value);
      } catch (e) {}
      try {
        value = JSON.parse(value);
      } catch (e) {}
      params[key] = value;
    });
    return params;
  }
}
function mybricks_taro__navigateBack(_ref) {
  var env = _ref.env,
    data = _ref.data,
    inputs = _ref.inputs;
  _ref.outputs;
  if (!env.runtime) {
    return;
  }
  inputs["navigateBack"](function (val) {
    var delta = data.delta;
    if (val !== null && val !== void 0 && val.delta) {
      delta = val.delta;
    }
    delta = isNaN(parseInt(delta)) ? 1 : parseInt(delta);
    // 在引擎内，使用 mock 方法
    if (env.runtime.debug) {
      env.canvas.back(-delta);
      return;
    }
    //runtime
    Taro.navigateBack({
      delta: delta
    });
  });
}
function mybricks_taro__getRouter(_ref) {
  var env = _ref.env,
    data = _ref.data,
    inputs = _ref.inputs,
    outputs = _ref.outputs;
  if (!env.runtime) {
    return;
  }
  inputs["call"](function () {
    var _env$runtime, _Taro$getCurrentInsta;
    // mock
    if ((_env$runtime = env.runtime) !== null && _env$runtime !== void 0 && _env$runtime.debug) {
      try {
        var result = data.mock;
        outputs["onComplete"](JSON.parse(decodeURIComponent(result)));
      } catch (e) {
        outputs["onComplete"]({
          path: "",
          query: {},
          scene: 0
        });
      }
      return;
    }
    var router = (_Taro$getCurrentInsta = Taro.getCurrentInstance()) === null || _Taro$getCurrentInsta === void 0 ? void 0 : _Taro$getCurrentInsta.router;
    var path = (router === null || router === void 0 ? void 0 : router.path) || "";
    var query = (router === null || router === void 0 ? void 0 : router.params) || {};
    var scene = Taro.getEnterOptionsSync().scene || 0;
    // 兼容 H5 的 hash 模式，重置 path 和 query
    // const isH5 =
    //   Taro.getEnv() === Taro.ENV_TYPE.WEB ||
    //   Taro.getEnv() === "Unknown";
    // if (isH5) {
    //   let hash = window.location.hash.slice(1);
    //   //
    //   path = hash.split("?")[0];
    //   query = hash.split("?")[1] || "";
    //   if (query) {
    //     query = query.split("&").reduce((acc, curr) => {
    //       let [key, value] = curr.split("=");
    //       acc[key] = value;
    //       return acc;
    //     }, {});
    //   } else {
    //     query = {};
    //   }
    // }
    outputs["onComplete"]({
      path: path,
      query: query,
      scene: scene
    });
  });
}
function mybricks_taro__toast(_ref) {
  var env = _ref.env,
    data = _ref.data,
    inputs = _ref.inputs,
    outputs = _ref.outputs;
  if (env.runtime) {
    inputs["onTrigger"](function (val) {
      /** 动态输入 */if (data !== null && data !== void 0 && data.dynamic) {
        Taro.showToast(_objectSpread2(_objectSpread2({}, typeof val === "string" ? {
          title: val
        } : val), {}, {
          complete: function complete() {
            outputs["onComplete"]();
          }
        }));
      } else {
        /** 非动态输入 */Taro.showToast(_objectSpread2(_objectSpread2({}, data), {}, {
          complete: function complete() {
            outputs["onComplete"]();
          }
        }));
      }
    });
    // inputs["onDynamic"]((val) => {
    //   if (typeof val === "string") {
    //     val = {
    //       title: val,
    //     };
    //   }
    //   Taro.showToast({
    //     ...val,
    //     complete: () => {
    //       outputs["onComplete"]();
    //     },
    //   });
    // });
  }
}
function mybricks_taro__showToast(_ref) {
  var env = _ref.env,
    data = _ref.data,
    inputs = _ref.inputs,
    outputs = _ref.outputs;
  if (env.runtime) {
    inputs["showToast"](function (val) {
      /** 动态输入 */if (data !== null && data !== void 0 && data.dynamic) {
        console.log("动态输入", _objectSpread2(_objectSpread2({}, val), {}, {
          duration: val.duration === undefined || isNaN(val.duration) ? 1000 : typeof val.duration === "string" ? Number(val.duration) : val.duration
        }));
        Taro.showToast(_objectSpread2(_objectSpread2({}, typeof val === "string" ? {
          title: val,
          duration: 1000
        } : _objectSpread2(_objectSpread2({}, val), {}, {
          duration: val.duration === undefined || isNaN(val.duration) ? 1000 : typeof val.duration === "string" ? Number(val.duration) : val.duration
        })), {}, {
          complete: function complete() {
            if (data.asynchronous) {
              setTimeout(function () {
                outputs["afterShowToast"]();
              }, data === null || data === void 0 ? void 0 : data.duration); //提示结束后触发
            } else {
              outputs["afterShowToast"](val);
            }
          }
        }));
      } else {
        /** 非动态输入 */Taro.showToast(_objectSpread2(_objectSpread2({}, data), {}, {
          complete: function complete() {
            if (data.asynchronous) {
              setTimeout(function () {
                outputs["afterShowToast"]();
              }, data === null || data === void 0 ? void 0 : data.duration); //提示结束后触发
            } else {
              outputs["afterShowToast"](val);
            }
          }
        }));
      }
    });
  }
}
function mybricks_taro__hideToast(_ref) {
  var env = _ref.env;
  _ref.data;
  var inputs = _ref.inputs,
    outputs = _ref.outputs;
  if (!env.runtime) {
    return;
  }
  inputs["hideToast"](function (val) {
    Taro.hideToast({
      noConflict: true,
      complete: function complete() {
        outputs["afterHideToast"](val);
      }
    });
  });
}
function mybricks_taro__showLoading(_ref) {
  var _env$runtime2;
  var env = _ref.env,
    data = _ref.data,
    inputs = _ref.inputs,
    outputs = _ref.outputs;
  if (!env.runtime) {
    return;
  }
  inputs["showLoading"](function (val) {
    var _env$runtime;
    Taro.showLoading({
      title: data.title,
      mask: (_env$runtime = env.runtime) !== null && _env$runtime !== void 0 && _env$runtime.debug ? false : data.mask,
      // debug 模式下不显示蒙层
      complete: function complete() {
        outputs["afterShowLoading"](val);
      }
    });
  });
  //退出调试时自动隐藏掉loading
  if (typeof (env === null || env === void 0 || (_env$runtime2 = env.runtime) === null || _env$runtime2 === void 0 ? void 0 : _env$runtime2.onComplete) === 'function') {
    env.runtime.onComplete(function () {
      Taro.hideLoading();
    });
  }
}
function mybricks_taro__hideLoading(_ref) {
  var env = _ref.env;
  _ref.data;
  var inputs = _ref.inputs,
    outputs = _ref.outputs;
  if (!env.runtime) {
    return;
  }
  inputs["hideLoading"](function (val) {
    Taro.hideLoading({
      noConflict: true,
      complete: function complete(e) {
        outputs["afterHideLoading"](val);
      }
    });
  });
}
function mybricks_taro__setNavigationBarTitle(_ref) {
  var env = _ref.env;
  _ref.data;
  var inputs = _ref.inputs;
  _ref.outputs;
  _ref.logger;
  if (!env.runtime) {
    return;
  }
  inputs["setTitle"](function (value) {
    if (value && typeof value === "string") {
      Taro.setNavigationBarTitle({
        title: value
      });
    }
  });
}
function mybricks_taro__scan_qrcode(_ref) {
  var env = _ref.env,
    data = _ref.data,
    inputs = _ref.inputs,
    outputs = _ref.outputs;
  if (env.runtime) {
    inputs["scan"](function () {
      Taro.scanCode({
        onlyFromCamera: data.onlyFromCamera,
        success: function success(_ref2) {
          var result = _ref2.result,
            scanType = _ref2.scanType;
          _ref2.errMsg;
          if (result) {
            var _outputs$onSuccess;
            (_outputs$onSuccess = outputs["onSuccess"]) === null || _outputs$onSuccess === void 0 || _outputs$onSuccess.call(outputs, {
              result: result,
              scanType: scanType
            });
          } else {
            var _outputs$onFail;
            (_outputs$onFail = outputs["onFail"]) === null || _outputs$onFail === void 0 || _outputs$onFail.call(outputs, {});
          }
        },
        fail: function fail(_ref3) {
          var _outputs$onFail2;
          var errMsg = _ref3.errMsg;
          (_outputs$onFail2 = outputs["onFail"]) === null || _outputs$onFail2 === void 0 || _outputs$onFail2.call(outputs, {
            errMsg: errMsg
          });
        }
      });
    });
  }
}
function mybricks_taro__call_phone(_ref) {
  var env = _ref.env;
  _ref.data;
  var inputs = _ref.inputs,
    outputs = _ref.outputs;
  if (env.runtime) {
    inputs["call"](function (val) {
      Taro.makePhoneCall({
        phoneNumber: String(val),
        success: function success(_ref2) {
          var _outputs$onSuccess;
          _ref2.errMsg;
          (_outputs$onSuccess = outputs["onSuccess"]) === null || _outputs$onSuccess === void 0 || _outputs$onSuccess.call(outputs, true);
        },
        fail: function fail(_ref3) {
          var _outputs$onFail;
          var errMsg = _ref3.errMsg;
          (_outputs$onFail = outputs["onFail"]) === null || _outputs$onFail === void 0 || _outputs$onFail.call(outputs, {
            errMsg: errMsg
          });
        }
      });
    });
  }
}
var css$d = {
  "h5page": "style_h5page__ur7Zn",
  "page": "style_page__2c4W0",
  "fixedContainer": "style_fixedContainer__IvUfK",
  "contentScrollView": "style_contentScrollView__iSgvw",
  "debug": "style_debug__hmr7r",
  "fixedTop": "style_fixedTop__XVHVh",
  "fixedBottom": "style_fixedBottom__TEffq",
  "tabBarPlaceholder": "style_tabBarPlaceholder__mRVDY",
  "footerPlaceholder": "style_footerPlaceholder__skMD1",
  "footer": "style_footer__SXeSh",
  "safearea": "style_safearea__8uJxv",
  "loading": "style_loading__nVEJd",
  "icon": "style_icon__CJWe6"
};
var classnames = {
  exports: {}
};
/*!
	Copyright (c) 2018 Jed Watson.
	Licensed under the MIT License (MIT), see
	http://jedwatson.github.io/classnames
*/
var hasRequiredClassnames;
function requireClassnames() {
  if (hasRequiredClassnames) return classnames.exports;
  hasRequiredClassnames = 1;
  (function (module) {
    /* global define */(function () {
      var hasOwn = {}.hasOwnProperty;
      function classNames() {
        var classes = '';
        for (var i = 0; i < arguments.length; i++) {
          var arg = arguments[i];
          if (arg) {
            classes = appendClass(classes, parseValue(arg));
          }
        }
        return classes;
      }
      function parseValue(arg) {
        if (typeof arg === 'string' || typeof arg === 'number') {
          return arg;
        }
        if (typeof arg !== 'object') {
          return '';
        }
        if (Array.isArray(arg)) {
          return classNames.apply(null, arg);
        }
        if (arg.toString !== Object.prototype.toString && !arg.toString.toString().includes('[native code]')) {
          return arg.toString();
        }
        var classes = '';
        for (var key in arg) {
          if (hasOwn.call(arg, key) && arg[key]) {
            classes = appendClass(classes, key);
          }
        }
        return classes;
      }
      function appendClass(value, newClass) {
        if (!newClass) {
          return value;
        }
        if (value) {
          return value + ' ' + newClass;
        }
        return value + newClass;
      }
      if (module.exports) {
        classNames.default = classNames;
        module.exports = classNames;
      } else {
        window.classNames = classNames;
      }
    })();
  })(classnames);
  return classnames.exports;
}
var classnamesExports = requireClassnames();
var cx = /*@__PURE__*/getDefaultExportFromCjs(classnamesExports);
var css$c = {
  "defaultNavigation": "style_defaultNavigation__e3FjL",
  "safearea": "style_safearea__Px1zS",
  "main": "style_main__U61qz",
  "left": "style_left__9fz15",
  "backIcon": "style_backIcon__-KP0E",
  "homeIcon": "style_homeIcon__G6bAn",
  "right": "style_right__OayUv",
  "title": "style_title__ZxaaN"
};
var backIconWhite = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGYAAABmBAMAAADL8flRAAAAJFBMVEUAAADj4+OIiIiIiIjX19eqqqqEhITMzMydnZ2dnZ3Ly8v///9fInaOAAAAC3RSTlMA+zw+9sAf75uc7jAcvgoAAAChSURBVFjD7dgxCoNQEIThSbp0koBNGr1B7mGfJlWKnMIm9/AUwhPFvZx7hRkQFObvl29hu8W5+/XlD67rM2JsQNVGVrNMNvFMzDST0UwmMEVgFp6JimfGhmfuZsyYMWPGzLGYC89g4Bl0PAOO0Wd6YbePAH2DgfSbojVkyJAhQweBHgr0MpTVAjSBh2YIEAQIPFTAQwt4qNr/x4Vbt75xljYCngLkXfXd2AAAAABJRU5ErkJggg==";
var backIconBlack = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGYAAABmCAYAAAA53+RiAAAACXBIWXMAACE4AAAhOAFFljFgAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAHTSURBVHgB7dzRbZtgAEXho07gEW4nczZpJqvVBZoN4k3SYtlRq0qNDPyQq+R80n3zkw8IeACQJH1Ah2nfpp2m/brtadoRvZtMO/MnyL87336jHYW3o/wd54B2Ee6L8rpHtLkwL8plJ7SpMD/K67SRsDyKYTYS1kV5QsOFdVEuO6KhwvooZzRUGBMlaJhglDrBKHWCUeoEo9QJRqkTjFInGKVOMEqdYJQ6wSh1glHqBKPUCUapE4xSJxilTjBKnWCUOsEodYJR6gSj1AlGqROMUicYpU4wSp1glDrBKHWCUeoEo9QJRqkTjFInGKVOMEqdYJRKRin0gFEqXV69NkohoyzwBX1aJzxrZtvjjPnBcuEaNmi4y0fXLke+d2aFgnFqBePUCsapFYxTKxinVjBOrWCcWsE4tYJxagXj1ArGqRWMUysYp1YwTq1gnFrBOLWCcWoF49QKxqkVjFMrGKdWME6tYJxawTi1gnFqBePUCsapFYxTK4yJ8xUNF4xTKxinVjBOrWCcWsE4tcKYOAc0XFgf5xFtIqyLc0KbybRnlsfRhsLyONpYmB/nJ9pFmBfniHYT7ovzjHYXrn/8C/+PEvRuHrheR15u+8712cUHS0m632/vANpnfRPiMAAAAABJRU5ErkJggg==";
var homeButtonWhite = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGYAAABmCAMAAAAOARRQAAAAAXNSR0IB2cksfwAAAAlwSFlzAAAhOAAAITgBRZYxYAAAAF1QTFRFAAAAhISEnZ2dubm519fX8PDw////4+PjzMzMsrKykpKSqqqqnZ2diIiIsbGxjY2No6OjwsLCurq6qqqql5eXo6Ojw8PDl5eXkpKSgICAhISE4uLi/v7+7+/v1tbWQTkgiwAAAB90Uk5TAB+c2/b+//vvz3C/mzzOV6/m3MCHrueGcQIh+//+9jmzlEcAAAKqSURBVHic7ZrbdoMgEEVDUPASkhrt/fL/n9mmqwoDg8BA1uoD5zEqW+CEOZAcDlVV/1DsyJtWCNn1wx0h4w9ilTzdiXIyIDd16h6Us7AlL8UhjDuUHz0UpqgGowgxlqVInCLEuSDl0vooQkysFOXkh9yMUMhwI2y245O8AwcaWf5+/R/AZ23+ksAm2JW/mbBmK9fYlpGv+gIcuDxjW43N/ks5xh72hsYazoZsbGhkd6JnaA6i4cZgKyU40MgN2sYR9ndJhrAOtNB5Rv6SZzjLR33sjWmci9/IDgd+s3gCBRq5Pe7ezK4Rk4jpEU5ssBTTDBc2coATFRFg0Y8bgwWOcjhbMWutjFxCEg23s1YW5FhGTikj1jDwnWFYUozsqI+c1IVgGFOW4Tz9UaAvlPUWRoQOvwnMC61KweUDnVqwqF+xOyIEDNdir2reEG/kXQ7SzBDqbaTMiCDdy9qOuenOMJxrI10ts3d7uin3m7d5pMmlGOPvTs52yV+Qo7W9sltLC7hsk6yYiqFj1CNvpKGuX3yrOB0zwEy9NoMXJSpGoZCb0GxBxAw7xw/YXoGGWdD2VyE1n4RRO3357U8ZjPdYaJVTBSmYEW3aVGv7jYIJdsatHQSMGXgarjUZM2ZHGAJGJwgrIygjzFrpgYDRL+2EXc2xRi0do4T/Eba9wlMuRseHZ+eRw7bXsGJKDgZJb9se2sp9FVMxFVMxFVMx/wUD6zoJs7OTlvgjFMyLZ2Ru0kEJZFUC5lUHSDc/GCctJicZ8/pm7IXcXZZ5AiX7eZU+meezoy3ZtPozbqRR7HzQuyGjCztkGsKPJeodoZgmKCT8xIxFbDFS5N35F+X4fzAqyPnY+71VXcMNROkzcCqLn2ak6eNzDh+Wq+MEzma8esf1dR6K/SGiqipN3wHRX/62YhtSAAAAAElFTkSuQmCC";
var homeButtonBlack = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGYAAABmCAYAAAA53+RiAAAACXBIWXMAACE4AAAhOAFFljFgAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAARcSURBVHgB7Z3tcdw2EIafZFJAUoFRgjoIUoGUCu46sDs4duCkgdx1EKeBnFKBrAbCcwP+aMBn7lAeezTWebkEySW5z8z7x6KPIF5isSBAEIIgCIIgCILp+YH58nOjm0a/NrpqlB7+TTg96L7Rq0a3BIMjlb9r9K7RWam60YZgMKRyuxjyWEfalhUU5CV2Qx63niuC3kjo2lPGlK/1gsBManRHeVM+a0fQmUQbds4D6yWBGukD+nTyXfU3X1Lt4Ak2jGfI46QgEXyTHfaKPdImCXL314Q5xbCmw1KZ+Ru/98L4e++e+L3VIbFd7nJrK7nUN/Tpq1adTifs6fChwzlq4zl2rJCEvcIqupF6nGtV6XRm/BDTJ2TesYJ0eoOtckp1ypXx/DULzth2+KiUykk5XGBNhyWMJMqzNZZHWu4NC0Bi8xFbJRwZNrZLOl0by7ZjxiTsF/4H45BYmTl97saKcUnYx1N7ZkTGlg7L/9kyDRIyD9jMGaofLMpzbBcnpniY8q2wlb/GsTk7lnFRFfbrcLeeYM+ywoCkxNZwvMEBEpv7PIj0/KgjMdOMLTGfzMtKYmbm9EmH5zbX0Scq7BkxKvSJv1vmiwx6LeaM0o/eYCtczTJWQFbYr3+wlpOwtZSaZT2Vta4nODIQtaEwS51kythu0uL969ZQiAPLJtH9ZhUzi96oXQtQsQ4SE9ZN7njitS396bqeoKYQ2jRx7YvlKvTmJApwVJ5sQ6Ctqy0F0GQfdwRCpkA/8yM6NFnEfwTCbaP3iuOeXfqj1hgNmsKshd51UdKYoCBhjFPCGKeEMU4JY5zyE/MhNbqmndMRdX0QeKLd9OcWfUrrnt4Dph5k7GufL2nPcHNEtfL8T+I5lCVaQ0SZ8mxpK3CHQ7wak2kf8WSGp2L4two649EYWVMwdkVlnM20ejMmMd3q+UQ7p+ICb8ZMHVIyTib5PBkjnXBielyUw5MxW3wgLXbyVuNlgLml2136+kFapLIz+jC5oc3WJhuEejHmWnmcVNTv2LbrTbQt4bniWDHwigm3BfYSyrLyuN+wV9aJ1pg/lcdP+sq4B2MSuhBzoFv4eooKXYhKTIgXYzS8ogxiyklx3DMmZE6P/T9QjnvFMZM+BYj5GKeEMU4JY5wSxjgljHFKGOOUMMYpYYxTwhinhDFOCWOcEsY4JYxxShjjlDDGKWGMU0oas8SNfKz0rgutMSfFMdqVLktHFoxojHlz6Y9aYzSLIBLxNVb52vtfymMvblihNUYzRy7IFy/WaI4Y8kujf9EvLrn/3g9qyHTbne7U6B/0y4Q0e9Ac+E7z78DnVwYvIWXXrkGTFTWyDk3bt9zShrwiDPG63Vq1oSAZOId6638GwPrxtdAXbRgAiaE1cA6ZVDEgiTDHoj0jkAhztPrIyB85Tdi/ULQWvWXCcV0mUumvJS1EDKno8cxMO8DUkGhNukb/zsvYnBkOGZDK9pMysH5N7HgYBEEQBEGwAD4BbqKsewkJLDYAAAAASUVORK5CYII=";
var menuButtonWhite = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQUAAABgCAYAAAAU2GfMAAAAAXNSR0IArs4c6QAAAARzQklUCAgICHwIZIgAABt6SURBVHic7Z1bUFvXucfXvmlvCSSDAQG6cJMMseglVJimc+wTceozdqaxPW2HFjd2TTMpyYiZPJAMD34xfmhm6ibKjGdgEtrJKDPt2DNM4wHs2p7TFuU4iVsHDtgxsiFgjBHCiIuuaGtr385DTOIQSUigG/H6Pe699tofbO3/Xutb3/o+BGQpnZ2d+MzMTL4oinkcx8kZhpGLoihDUZTEMEzC8zwmCAIqiiKSaVshkMdBEEREUVTAMIzneT4sCAKDIEiQJEk/juN+BEE809PTbpvNxmXa1khkzQvV1NQkxTCsmOd5pSiKSgDAjrUXHkEQkWEYNhQKsaIoCizLCoIgCBzH8RyXlf9XCATgOA4kEgkhkUhwiUSC4zhO4DiOAvDFbxpBEA+Koi4Mw1wSiWTBarWGMm0zABkWhdbWVpnX6y3nOK4SQZB8URQRlmU5v98fdLvdtNfrZbxeL7uyssICAMRM2gqBJAOFQoGrVCppXl6eNC8vTyqTySgEQVAEQUQAwApBENMlJSUzb7/9Np0pG9MuCqIoIr/4xS+0AAA9AKCE4zjE4/EEFhYWAg8fPgyurKyE020TBJIpCIJANBqNrLi4OKewsFBBkiSBoqiAIMg8iqKT58+fd4A0fxDTJgpNTU0YQRBV4XDYIIqiPBAI0E6n0zs5OemjaZpPlx0QSDZTVlYm1Wq1ioKCAgVBELgoij4Mw+wAgOne3t60vCcpF4WmpiYMAFAjiuJToijKVlZWfOPj40tOp5NJ9b0hkG0MUlNTI9+1a1cBSZIUiqKrgiDcQVH081SLQ0pFoampqUQUxR+KoihfWlry3rlzZ9nlckExgEASQK/Xy3ft2lUok8koAIBXEIR/X7hwwZWq+6VEFFpaWqhAIPADURSrAoEAPTIyMg/FAALZGrW1tYrKykolSZKEKIqTNE2PXL58OenvVdJF4fjx42U0Tf+Q4zj83r17rlu3bnmSfQ8I5EmFIAjUaDQWqtXqAgAAjaLov3p7e+eSeY+kiUJnZyd+//79er/fr19dXQ1+8skncz6fDwYRQCApQKVSSevq6kopiiJxHB/fvXv3cGdnp5CMvpMiCk1NTbkIgvwnz/M7nU7n0vXr15cAjCuAQFIKQRBIQ0ODsqSkZCeGYYs0TV8bGBgIbrVfbKsd/PrXvy7gOO6/WZaVjY6OOj777DM4XYBA0oAgCGB2dnZVFEWmoKCgGMfxyrq6uoefffbZliIjtyQKj/wHJpqmxY8//nhmfn4+K8I0IZAniaWlpfDy8nJArVbnAwD05eXlnsnJSd9m+9u0KPzyl7/czTDMj4LBYHhwcPCB3++H/gMIJEOsrq7y8/PzPpVKpZDJZLqKigrm888/X95MX5sShZ///Oe1giD8wOv1Bj/66KMHNE0nxcEBgUA2D8MwgsPh8Gk0mhypVFqxa9eu4Pj4+Eqi/SQsCsePH69kWbbB5/Otfvjhh7MMw0CHIgSSJXAcJ87Nzfk0Gk0ORVEVer1+eXx83J9IHwmJwm9+85uiYDD47OrqKnPt2jUoCBBIFsKyrOhwOPxarVYulUorqqur5+7evRu3vy9uUXjxxRflfr9/P8Mw4rVr12YCgQCcMkAgWQrHceLCwoJfrVbnSSSScp1ONzMxMcHGcy0aT6POzk48GAz+J8dx+Mcff/zA5/PBXY0QSJbj8/m4GzduPGBZlpJIJPs6Ozvjet/jajQzM9PAsmz+zZs35x4lPIF8y2hoaJAdO3asKNN2QJKLy+UKj42NOQEARRMTE3XxXLOhKJw4cULn8/mqHjx4sDQ9Pb26ZSshWUl1dXVOXV1dYabtgCSfyclJ/8OHD1cYhtn9s5/9TLNR+5iiYDabc4PBYP3q6mrw008/XUqemRAIJJ3cuHHDFQqFGADAM8899xwZqy0e66Tf7zeyLIt+8sknaU8JBYGkCrPZrHrxxRefzcvLUykUilKFQlENAAAkSaoAAIDneT/HcX6apueXl5cnZmdnJ3p7e4e7u7udmbV887AsK46MjMz/6Ec/qpBKpXUAgH9FaxtVFF566SWN2+3W3rt3bx46FiHbHavVaty7d6+poqLieQzD5LHaYhgmxzBMTpKkKi8vz6jT6YDJZAK///3vJ4aGhs5tV4FwOp30w4cPV0pKSvTPPffc1OXLlxcjtYs4fTCZTLjP56unaZqG+RAg25nBwcFDbrf73RMnTryr0+mObiQIscjNza02mUynurq6+h0Oxymz2axKpq3pYGRkZJHneZ4giAYQ5f2PeLC0tLSG5/nc0dHRhym1EAJJEVar1RgKhfpNJtOpvLw8Y7L7V6vVh7q6uvonJydf207iEAwGhampqUWCIPIPHDhQFanNN0Shs7MT5zhu98rKis/pdMJdj5BthdlsVq2NDNZ8BKlEp9MdtVgs71it1qQLT6q4e/euh2EYNicnxwAiaMA3DkxOTuoEQaDGx8fhagNkW9HX12c6e/bsX1IxMogFSZKqEydOvDs2NtaazvtuFpZlxenp6UUEQRQHDx4sW3/+a47Gzs5O1G637/Z6vX6Ygh2ynRgbG2s1GAxxv5QMwzgdDseHs7OzEzMzM84bN27M2+12v81m85vNZlVDQ0Npfn6+3Gg0PltYWGiMZ9RhMBhaJycn5Xq9/q2t/TWpZ2JiwldZWVlEUdRuAMD9x8/h6xpqeZ7PtdvtX2sEgWQz8QoCz/P+0dHRnvfee+/DWKsH3d3dzsfO2wD4wkexf//+59Vq9aFY99DpdEcdDkeuRqM5ncjfkG5YlhXn5uaWq6qqSn784x8X/+Mf/1hYO/e16YMoitU0TdNOpzNjdewgkESIRxB4nvfb7fae/fv3H66vrz+3meXElpaWYY1Gc7qtre2wx+MZjtVWrVYfcjgcpxK9R7oZHx/3iqIoSKXSXY8f/1IUOjo65BzHFTmdzk2ncYJA0snQ0NDRjQRhamrq3P79+w/X1tb22Gy2hPIKRKK7u9uZn5//ss1mO83zfNT+1Gr1oWz3MQSDQWFlZcVHUZSmqalJsnb8S1GYn58vFwQBvXfvnjczJkIg8WM2m1VGo/G1WG2Gh4ff0uv1byVDDNbT2Ng4YLFYXmYYJuqow2AwtGb7qsTMzIxXFEWcZVnt2rEvRYFhmEqfz7cKoxch2wGLxfJOtHM8z/vff//9l+vr68+l0oaOjo6J9vb2V2IJQ3Nz8ymTybTpgKlUMz09HWRZlmNZtnLtGArAFxufBEFQOJ1OOEqAZD1jY2OtsVYDLBbLyy0tLTHn/cmiu7vb2d7e/kq0qQRJkqo//elPWT2NcLvdfoqiioxGIwHAI1FgGKZEFEVkfn5+y4UkIJBUYjabVbH8CHa7vaejo2MinTZ1d3c7L126FHW1QafTHc3mqMf5+flVAABWWlqqBOCRKHAcV8xxHAsTqECynZMnT/422rmpqalztbW1Pem0Z40jR47Ypqamok5XYtmdaZxO5yoAAJAk+ZUohMPhIo/HA0cJkKzGbDarosUJMAzjtFgsKfUhbMRLL73UE20aoVarD2WrbyEYDArBYDDEcdwXotDZ2SljWTbH5/PB2ARIVtPU1BTVk3/9+vU/bnY7s9VqNQ4ODh4aGxtrHRwcPLTZFQObzeYfHR2NOlLp6uo6upl+00EgEKARBNkJAEBxp9O5QxRFxOPxhDNtWCZY22ev0WiexXFcjmGYnGEYJ03T86Ojoxe36975byP19fURXyqGYZyNjY0DifRlMpnkXV1dR2tqar62ndpgMAAAAGhubnZOTU1d7OrqupjI86+vrz8XCoWORnKElpWVmQAAGZnebITX6w0plcr8/fv3y1EAwA4AAFheXn6iROHx3XQ6ne4oSZKqtR/HWnINk8l0ymKxvDM4OBgztBWSesxmsyo3N7c60rnbt28nNG04c+ZM9ZUrV/5iMBhao+VXIElSZTAYWi0WyzuJOgmj2ZObm1udrQ5Hj8fDAACARCLJQ0OhkEIURcHn8z0xTkar1WqMdzcdSZIqk8l0yuFwZPV687edWFOHf/7zn3EvP5rNZlV7e3vc26pJklSdPXv2L2fOnIkoSJF47733Pox2LtbfkUkWFxfDAABAkqQc5ThOwTDMEyMIZrNZdeLEiXcTzcCjVqsP/fnPf25PlV2Q2Gi12ogvJcMwzniXIM1ms8pisbyT6LPHMEz+6quvvhnvR6G7u9sZLaAp2t+RaWia5kVRFFiWlaMAgByGYbbN1MFsNqvWnEJ9fX2mRIdjsSLhNkKtVh8aGhqK21lkMpnkVqvVODQ0dHRoaOhotoe8ZjMFBQURX6alpaW4RwltbW3PbzbxCkmSqkQchQ6HI+JoQaFQlG7m/umAYRgWw7AcHEEQgmXZrM+dYDKZ5BcuXHjz8SG/wWAAhw8fBidPnhx44403NvQ+bxQJFw9PP/10q8lkurhRPP3g4OChffv2tT/+VTIajaC5udl5/fr1PybqGHvSkUqlEV+m4eHhqEP19dTU1GzJ+//o+rgchbOzsxM6ne4bx9cyR2cjPM/zOI5LUJ7nMUEQsroupNlsVl25ciWqD0CtVh+yWCzvbDS80+l0z2/VFgzD5G+++WbMfsbGxlpNJtOpSMPUNR9FIiMOCAA4jkd8tm63O67NTlar1biVpK0AfPHs4x3tzczMRPxARfs7sgGO43gEQSSoIAioIAhZXdPh5MmTv93oC0+SpOrChQtvRjtvtVrjyp4TDzqdzhTt3EZhuGsYjcbX4HQifqK90C6XKy5RKC8vT8qzj7efGzduzEc6vlVhSiWPRIFABUFAw+Fw1o4UYkWxrScvL88YzceQrB8FANGHsgAkFs66f//+LY9cnnT+9re/RXz51qNUKpMyl4+3H7vdnvTt2qkmFArxKIricRWYzSQHDhxIaA4WbcknWT8KAL6qJBSJHTt21MTbT2FhIRwpxEk0b368uRJcLldc4pGsfqLZFWubdabheV5EEARFEQThMAxDMm1QNPR6fUKiEO3lp2k6acodK+NOtACbSKQjBfm3nXhXn6LN8RMl3n6i2cWybCAZdqQCDMMQBEE4FADAZ7MoJKrwk5OTEdes/X5/0h4GTdNRbUrkSxAIBNK6xXc74/P5Iv6vGhoa4hoBtrS0DMcS83hgGMYZb56GaHZxHJe10woURVEAAI+KosjiOI5l2qBo9Pb2JpQs4+rVqxF/PKdPn7YlxSAAgNfrHY92LpF181j9QL6Oz+eLKMSJ+IrGx8e3tItyamrqYrxt8/PzIzoUl5eXs/ZDQJIkBgAIowCAcDaLQnd3t3Oj7LlrzM3NDUSLVbDZbP54+9mIv//971F/HLHOreeNN974YzLseRLweDxbjhBsa2s7t9k5PcMwzq6urrifrdFofDbS8dnZ2awVBRzHMZZlWRRBkCBFUUSmDYrFT3/609c3epgMwzg3esn6+vq2vENtbm5uINYQsqWlZXh4eHjDYiB2u70H7r6Mn2j7CSoqKuJewbHZbP6zZ8++nug0gud5f3t7+yuJPK9oTuRPP/00a0eHEokER1F0FcUwzEeSZFaLgs1m87e3t78yNzcXMQrQ4/EMHzx48IWNHlpLS8twrOw4GxGP8ADwxfZZm812OpKQ8Tzvt9lspzOVIWi70t3d7Yz0MicSUATAF8lWX3311RfiHTE8St7yciKCEC0mJpF9GpmAJEkCwzAfjuO4n2VZVKFQYNmcyflR1Z7TZrP5jwcOHKjW6/XVLpdrPtF8B3q9/i23212daL1Bnuf9V69etcR7r0dhzANWq9X4ne98pxoAAG7fvj1htVonUpFy/Eng/v37F3U63TciQR/Fe8Q9NXz0DF9pa2t7fn0+hTV4nvePj4+fa2trO5fo84oWf5KIvyndKBQKHEEQlCAIH87zvAcAAAoKCiifz7eaaeM24rGSXrbN9pGfn/9yIrUHGYZxnj179vXNqPyjqUbW/hi2Ex999JEtkiio1epDVqv1YiIZnB/9jnoAAD1Wq9VYXl6uUiqVpS6Xa35mZibuVYb1xAq2S8TflG6USiUFAAA0TXuR1tZWYmVl5Rf37993DQ0NrWTauHRiNptVv/vd705FGzVs5Wux3Th27FhRXV1d4WuvvXYn07bEwu12vxvpeXk8nuH8/PyXM2HT4zgcjlORRIFhGCdFUYczYVM8NDQ0FJaVlRUiCHIe7enpYQEAXrlcLsu0YelmrQRYW1vb4f7+/teHh4ffstvtPTab7fT777//Mo7jjckqNwZJDtGcxXl5ecZMZ8jq6+szRRslXL9+PatXmuRyuVQQBE9vby+PAwCARCJxyeXyqkwblinWVRmGZDEtLS3Dzc3NzkiOvH379rWfOXNmPBPOPLPZrDpw4EDEJDybySGZZpDc3FwZQRCfA/BV2bgFgiBwpVJJZtAwCCQuzp8/H7HwylqGpHTnQTSZTHKLxfJOtLD1bB8llJWVUTiOo4IgLADwSBQkEskCgiCiVqvNzax5EMjGtLS0DEdbniZJUrWZZKubxWQyyQcGBqLmfFxcXLRl+SgBFBcX5yIIIgYCga9EwWq1hgAAK4WFhVm71xsCeZxjx45ZosUarAlDX1+fKZU2rCX/ibYJjmEYZ2dnpyWVNiQDpVIpZ1l26fLlywwAj1WdJghiOjc3V7pz586sDmSCQADYODqRJEnV4cOH3xwbG0tJcde1jOCxdromEteSKZRKJUlRFImi6PTasS9FoaSkZAZFUUGv1+/IjHkQSGJ0dHRMXLt2LeaX2GAwtIZCof5krUw8Xi8kVhYlu93ec+TIEVsy7plKqqqqdgAAeLfb/WDt2Jei8Pbbb9MIgswrlcq8jFgHgWyCxsbGAZvNFrXiMwBf5cVcE4fN+BusVqvR4XCc6urq6t8oGtZut/dshzB2giCQ0tLSHaIoztlsttDacfzxRhzHfU6SpFqv1+dOTk5mbTIICORxGhsbBwYHB8H67NnrWRMHk8kELBaL0+FwfDg2Njbsdrv9LpfLv5bazWAwyBsaGkrLy8tVWq22uqKi4vl4cytuF0EAAIDq6mo5iqJ4IBD4/PHj65OrIE1NTYf8fj9+5cqVmTTaB8kw2yWiMRZrxV4ykdGK53n/6OhoT319fUYrXyfCT37ykyqJREJfuHDha+HX63M0ioIg3MnJyZFptdonLsIRsr3p7u52xtpNmyrWdlJuJ0HQ6/VyiqLIcDhsX3/uG4lbURS9hyBIsLa2tig95kEgyaO7u9up0WhO9/f3b5iDIxnY7faegwcPvpDNW6IjUVNTUwQACFy6dOn++nPfEIXe3l6e5/k7OTk5ssrKypx0GAiBJJsjR47YKIo6HC2vxVaZm5sbaGtrO7wd98bU1tbuoCiKZBhmDADwjfIOEVO84zg+gSCI32AwFINv+h0gkG1DY2PjAEVRh//whz/8am5ubmArAhEIBCbsdntPY2Njo0ajOZ3tMQiRIAgC0ev1RYIgeC5evDgVqQ0e6WBvby/f3Nz8KUVR/1VXV5c3MjLiTq2pEEhq6ejomOjo6DgNAABnzpyp3rNnT41Wq60uKCioxnFcThBE7pqDkud5P8dxfp/PN+Hz+eZnZ2cnTp8+bdtuI4JI1NfXF+I4TgiCcANEGCUAEEUUAADg/Pnzzubm5pnKykrtzMxMYGVl5YkpVw/5dvNo/r+tfADJQKlUkmq1ugBBkKm//vWvrmjtYlaIUigUwxiG8UajMWvLZ0MgkI0hCAIxGo0qAEB4cXFxJFbbDf0Fx48frwwGg/9x7969h3AaAYFsT5555hmlWq0uEEXR9sEHHzhitd2w3sOtW7c8e/bsyZHJZFqfzxfw+/1c8kyFQCCpprKyMqempqaUIIi7vb29dzdqH1eB2aqqqk+lUql7z549GoVCEdUPAYFAsoudO3dKvv/976sBAItPPfXU/8VzTVyVoWw2m7Bnz56HHMfpSkpKFDMzMz5BEMQtWQuBQFKKQqHA9+7dWy6RSMLhcPifPT094Xiui7tc3MjISHjv3r0uURR3lZSUyGZnZ32CEHFFAwKBZBipVIrt27evnKIohOf5v/f398e9nJpQDcnh4eHgd7/73QBBEPqSkhJydnbWD4UBAskuCIJATSZTmUwmI3me/7Cvr28xkesTLix7+/Ztj8Fg4CmKKi8uLqYcDgcUBggkS5BKpZjJZCrLzc2V0jT9r0uXLj3Y+Kqvs6lq03fu3Fl8+umnwwRBVGg0GpnT6fSzLAt9DBBIBlEoFLjJZCqnKIr0+/03rl69OrmZfjZdgv727dtL9fX1HhRFKzQazY6FhQU/wzBwyACBZAClUknu3bu3giAIlGXZ/71y5cr9zfa1aVEAAIBbt2556+vr5xEEqdBqtQXBYDDk8/lgODQEkkZqamoU9fX1WgRBGFEU/6e/vz8hH8J6tiQKAABw8+ZNura29gFBECVqtbpEKpWK8/PzoY2vhEAgW4EgCPSZZ54p1ul0ShRFFzEM+8cHH3yw5TSKWxYFAACw2+3hpqam6UAgIMvJydGWl5fLfD4fvbq6mrWl7SGQ7UxZWZl07969ZXl5ebkEQdw1GAwfd3d3J2WUnvRcCb/61a/Kw+FwA8/zktnZWdfNmzfd0AkJgSQHgiDQhoaGopKSkp08z9OCIFzv7+9Pal6HlCRQaWpqkmIYVseybFUoFGLsdvvC9PT0airuBYE8KdTW1u7Q6XRKgiBwnucnJiYmRu12e1xRiomQ0qxKx44dKw2FQg2iKMq9Xm9wfHx8cXZ2NpjKe0Ig3zaeeuopuU6nK6IoihQEwRMKhf59+fLlLTkTY5HyVGsmkwkvKiqqRhBkN8/z0tXV1eD4+PgSHDlAINEhCAKprq5WVFRUFFAURQIAAizL3unv7/8cRMmYlCzSln/RZDLhxcXFVQCA3RzHyRmGYZeXl71TU1M+l8vFpMsOCCSb0Wq1soqKCkVBQYECwzAMAOAVRXHse9/73v3Ozs60xAGlPSmrKIrICy+8UCYIgp7n+WJBENBQKMS4XC7/wsJC4MGDB3S6bYJAMgVBEIhGo5GpVKrcwsJCOY7jBIqiAgBgDgAw2dvbO5dumzKaqfn111/PmZ+fLw+Hw5WiKOaJoohwHCcEg0Ha4/HQbrebnpubo2mahkubkG8FO3fuJIqKiqSFhYXS3NxcqUwmo1AURRAEEXmeX8ZxfDonJ2fGarVmLNYna9K3NzU1SSmKKmFZVsmyrBJBEIUoiggAAPA8z7Msy4VCIZZhGI5hGJj9CZL1YBiGkCSJSyQSnCAIgqIoHEEQFAAAEAQRRVF0EwTh4nneFQgEFi5fvpwV0+isEYX1tLa2EjRN5yMIksdxnJxl2VwAgFQQBAJBEEIURRxFUVwQhLiyR0Eg6QJFUUEQBE4URRZFUZbneQ5BkCBBEAGCIHw8z3s4jnP39vZm5Qj4/wHYxqZkR4lQjQAAAABJRU5ErkJggg==";
var menuButtonBlack = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQUAAABgCAYAAAAU2GfMAAAAAXNSR0IArs4c6QAAAARzQklUCAgICHwIZIgAABqbSURBVHic7Z1vUBNZ+u/P6e7T6dAN4Y8kkFVB+eeYAdxZZpmCdVz1tytlzXK92RrE2ipu1ZS1szWW6wu3toq4L3wxwpv1hWO5L6as3Srr3pKBuinXe8uf1JbDjn+44w6DGIw/ERmJKJCACYFuk/Tf+0LiqpNAQgJJxvN52X9OP9Cd73nOOc95HgjSlNHRUd3Tp08LIYQFCCGDKIoMQRAcwzDFsiyTAAAAISQghDDVtmIwL6M9R4UQKgCAkCzLPlmW/TRNh2RZntc07Wl9fb0HQiim2tZIpM0Pqq+vj8nKytoIISxiWfYtSZKywucghCpJkjJN0zJFUTJFUQpBEFoq7cVglkNVVSjLMinLMiXLMiVJEqVpGhE+DyF8ShDElCzL41NTU4/27t0bSqW9YVIqCrdv32ZFUawEAJQhhDYA8FwAdDpdKCsrK8hxXJBl2SBN00oq7cRgkoUoiqQgCAzP88yzZ8+YUCikCwuFJEmPKIoaUxTlfl1d3bNU2bjmoqBpGnQ4HJWaplk0TdsIIYQIISk7O5vPycl5xnFckCRJ7AVg3ggURYE8zzPz8/NZCwsLnCRJSNM0TVXVMb1ef++tt956ACFc09/DmonCwMAAoijqbYqiGmRZpkmSlDmO49etW7fAcVxauE0YTKrx+/3M/Pw85/f7sxVFIQEAfk3TBufm5u7s3LlTXgsbVl0UNE0jBwcHt5EkWQcAyGIYJmg0Gn15eXnCaj8bg8lUFEWBPp+PnZmZyRNFUacoygxJks7a2trbEEJ1NZ+9qqJw7969TcFgcCcAwMAwTLCwsNCbn5+fsrESBpOJ+Hw+dnp6Oj8YDJIURS1QFNW3detW12o9b1VEwel0cpqm7ZRluRwhJBUXF89izwCDSYzZ2Vluenp6naIoFE3TI7m5uf80m81J72STLgpOp9MiiuIOgiDogoICb1FR0RyeOMRgkgacmJjI93q9eQCAAMMwfVu2bBlJ6gOS1dDo6KiO5/ndEMIqhmGCGzdu9Oj1+rQMzsBgMh2/389MTk4aRVGkAQB3EUJ9FoslKb+3pIiCw+HIU1V1H4Qwp6CgYK6oqMiHvQMMZtWB4+PjBX6/PxdC+JTjuL+XlZX5E2400QaGh4c3BIPBXzAMw23YsGHaYDAEEm0Tg8HEzuzsLDc5OWnUNC3EMMzFLVu2TCbSXkKi4HQ6t4ZCoR00TRMVFRWTNE2vyToqBoN5FZ7n6fHxcbOqqoROp7ucyDzDikXB6XTWS5LUQNN0sLKycpIkyVVdO8VgMEsjiiI1NjZmliQJURT1D4vF4lxJOysShVu3bm2DEO7U6/VCZWXlNAAAzx9gMGmAKIrkw4cPi4PBIMNx3NXy8vJv420jblG4ffv225qm/UKv1wtlZWXTeEIRg0kvFEUhHjx4YA6FQjqdTvef8Q4liOUv+TcDAwMbAQD/wTBMoLKyEgsCBpOGkCSplpeXT5IkKT179mznvXv3zPHcH7MoOJ3OfJIkP9DpdKHy8vIpgIcMGEzaQpKkWlFR8QQhhARB+OXY2Jgh1ntjEoW+vj4mFArtoyiK3LRp0xSeVMRg0h+appWysrInFEUZeJ7/b06nk47lvphEIScn5z9IkswpLS2dwglPfph4PB40MjKiT7UdmOSi1+sls9nsVlU1X1XVn8dyz7KiMDg4WEuSZEVhYeEsznvww8Xn81EulwuLwg+QdevWCbm5uX5FUSz3799/a7nrlxSFgYEBg6Zp27Oysp4VFxcnHD6JwWBSQ2lp6VOapsVAIPDz6elpdqlrqaVOQgh3UxRFlpSUPEmuiRhManA4HGxXV9fma9euvT0zM2N0u92bJEliRVHkJEliAQCAZVk3QkgwGAyeDRs2PNy+ffudjo6O4VTbniCa2Wz2jI+Pr5+ZmdkJAPi/0S6MGqdw69atCgjhB8XFxR6j0Ti/KmZi0oaRkRG9y+XS//KXv/Sm2pZkExaCv/71r61er3dz+McfLyUlJV//9Kc/vdnd3X0l2TauFePj4+v8fn9udnb2/y4rK3sU6ZqInkJfXx8FANhB03QICwImU3E4HOyhQ4eab9682bxSIXgZl8v1nsvleo/juAO1tbVXjh49esVqtXqSYetasWHDBi/P89mBQODnmqb9z0ip3SLOKRgMhm2apunNZvPs6puJwSSfpqam5rq6urPXr18/kAxBeBlBEIz9/f0H2traOlpaWnYns+3VhiRJtaCgwCvLcsGdO3fejnTN90Th0qVLOkmSLBzHiXgbNCbTsNvtxqKiohO9vb0Hky0GryMIgrGnp+cIx3Fn7Xa7cTWflUyMRuM8QkjSNK1+cVTwCt8ThcLCwlqdTpdfXFz8dG1MxGCSQ0tLy+7W1tZTbre7ei2fKwiCsbW19VSmeA0kSWpGo9GrqipXXFy89fXzr6hEd3c3SRDENo7jBByTgMkkGhsbD/T39x+I9XqTyTS8bdu2myUlJW6LxTKzfv16wWq1uu12u2lgYMAIAACDg4ObhoaG6mMRGUmS2J6eniONjY3GGzdunE/kb1kL8vLyeI/Hk6+qaiMAwPHyuVdWH77++uutDMPsKS0tfYKHDm8Wmbz6EKsgmEym4R07dlw5duzYzZqampizizscDvbTTz997+rVq7tiEYiGhobzmSAMU1NTBo/HU8iy7MWKioqx8PFXhg8QwiqapvFcAiZjiEUQ8vLyHra3tx+bnp4+9sUXX3wZjyAAAEBNTY3Q3d19ZXp6+tiHH354imXZJVcc+vv7DzQ2NsbstaQKo9G4ACFUQ6HQK0OIF6Lw97//PZum6ZKcnBy8BInJCFpaWnYvJwh79uw56/V6jyQr+Ki7u/sKz/MHGxoalvQE+vv7D6T7HANJkmp2djavKMqm0dFRXfj4C1EwmUyVBEGAwsLChdSYiMHEjt1uN164cOFgtPMIIaG9vf3Y5cuXL67G82/cuHH+s88+O7KU13DhwoWD6b4qkZ+fv6BpGimKYnn42AtRgBBu1uv1AbwLEpMJtLW1dURbcmRZ1tPV1ZU07yAahw8ffnju3DlbNGGQJIn95JNPjqymDYliMBgCJEnKsixvDh8jAACgt7eX1el06w0GA5868zCY2GhpadktCELEHphlWc+5c+dsaxVpaLVaPefOnbMhhCLOU7jd7uqmpqbmtbBlpWRnZwsAgM2aplEALIpCTk7ORgAAyM3NxcVfMWmN3W43Xrp0Keo8Qmdn54m1Dj22Wq2eP/zhDx3Rzn/55ZcHHA7HqgZSJUJOTs4zTdOIe/furQdgURQoitpE07SI6zZg0p2TJ09G9RIaGhrOHz58+OFa2wQAAB0dHcN79uw5G+mcJEnsoUOH0tZbyMnJCQAAgCiKRQD8e06hmGGYYMqswmBi5Pbt2xFn9FmW9aQ6NuDy5csX8/LyIorSzZs3m9PVWyBJUqVpOqTT6SwAAED09fVxCKEclmWxKGDSmqXmEvbu3btiQbDZbNX79+/ftX379gP79+/fZbPZVhwm/bvf/S6qt9DV1bU50rl0ICsrKxgKhThN0yjY19dXmpeX998rKysfvYlVom02W/Xly5fr79+/Xx9OtMGyrJvjOM/777//ZWtr63CmbY9dCZkQ0VhaWmpzuVzvvX7cZDINT09PH4unreW2VSOEhHfffffiSrZHFxUVnYgU+bgSO9cKj8eTMzU1ZSwqKvpfFEVRBRBCjaZpKdWGrSV2u934ySefHIn08gRBMAmCYOrp6am+dOmSp6ur63wmJ9b4oRBJEAAA4P333/8ynnZOnz69qb29/Vg0rwOA5z17f3//gcXhSlyrGTt27LjS3d39ve/K6/VudjgcbLwRlWuBTqcTAQBgfn6+gEAI5VAUJb9JhV1sNlt1rLvpwttjt2zZciRdx4RvAku59H/605++jrUdu91uPHr0aMdSgvAy4R2Qp0+f3hTrM44dO3Yz0vF0HkLo9XoJAAACgYCBkGWZQQi9MV6C3W43dnZ2noh3r/3IyMjulpaWqBF0mNXl2rVrEROCmEym4Vh7Xrvdblwq6CkakiSx7e3tx2LtFGpqagSTyRQxcCra35FqaJpWIISqqqoMQVGUgaKojFmKtNvtpvCk0Mcff1wfbxhpW1tb1PXk5RgZGdkdTyCKw+FgbTZbdVNTU3NTU1NzIhNYbzoTExMRe+pt27ZF7JUjsdRy5nIIgmCMZ1kxml0zMzNpG/aMEJIhhByFEDJQFJX2uRMcDgfb3Nx85OVx5fXr18Hnn38OqqqqrnR0dJxfbtzX2Nh4YKUfRZjFQJQry/VOH3/88Xt/+9vfjrzcK/X29oLPPvvMs3fvXjxHESd+vz/ie3vnnXdijkv45ptvEooVuHnzZjMAIKZVjpKSEnek4263O+ZhSApQ9Xp9MQEAQARBpHUZOLvdbmxoaDgVbaJpZGRkd1tbW8dy7l20Ne54kCSJ/eMf/7hkO42NjQc+//xzWyQ3NTxHke6hr+lGoqnVbDZbdaJtSJLExurtWSyWmWhtJGLDakKSpCLLMklACOOqPJ0KbDbbsj28IAjG5ubmqJtPbDZbdaJeQpihoaH6aOfsdrsxloQfvb29B+OZvHrTEQTBFOl4XV1dTKsCY2NjhcmwI9Z21q9fH9GTFEWRS4YdqwFCSJFlmUh7UbDb7caRkZGYeniXy/We3W6P+PEk66MAAACe56OKi81mizm5xpkzZ7C3kCBWqzWim/46k5OTEb+LeIm1nWh2pbOnsJjunQoLQtSiMKmmt7c3rt70iy++sEQ6nqyPAoDovRYA8Y0ZHz9+nJYz0elItF2I0TqB1zGbzTGJR7LaidWudAIhpAIAIKFpmqKqatqKwt27d+Na143242dZNmkBI9E+UAAAmJubi9nepcQF8yo0TUfc1v/48eOYet6ysrKIY/x4ibWdcPLX12FZNinitBqoqgo1TVMIgiA0SZLSdggRr8Jv3br1u0jHk5krYqkXG89Lz83NjWgr5vtEE2Kn0xnTsLCjo2N4KTGP1YZEE7ckasNqoqoqASFUiMWAhbQVhf379zvjuX7Pnj0Rl6iiRZmtBJPJFHUZbP369XeS0Q7mVaL9r1wuV8zeVn19fUKp2d59992Y7x8cHIw4jDQYDGm7j0ZVVULTtBARCoWmNU0jU21QNKxWq7ukpCSmMNaqqqqom1eWijJbgU1RY+0PHToU84fT0dGR9mnA04XCwsKI73WplaDXOXPmzMXlMjFHg2VZz9GjR2OOLYlm14YNG9K2I5BlmVQUZY5QVZUXRXHJkvSp5uLFi8um1WZZ1rPcj+yjjz7qStSWxUCpqOJy+PDhh9GSbbxMQ0PDssFWmH+zffv2iB6Y2+2ujif8uLOz80S8LjxCSIgnxZvD4WCj7auJ9nekA7IsU7IszxEIoYCiKGktCjU1NcK5c+dsVVVVEZW6pKTk6/7+/iPLvbSOjo7hH//4xyt2IWMRHgCeJ9uIVh8AIST89re/7Uh1QpBMo7W19btoP+YTJ07E7C0cPnz4YVdX15JZmF+GZVnPyZMn49ol+emnn0YMsgPg+TcYaztrTSgUQgRBhChN0+Y0TSNEUSTTOZOz1Wr1WK3WU3a7/Xxvb++mu3fvbjabze79+/c7Y12rBgCAwcHBs0VFRZvirTeIEBJ+85vfnI3141gMY75is9mqw+PLd95552Fra+t36bh1Nt2pqakR8vPzv4v03r766qvdAICYt08vvkPbyZMnd3/zzTdR8ynU19dfPHPmzMV439fVq1d3RToe6zA4FYiiSMHnzMOhoaEfAQBa3rRScfHUHmRZ1tPZ2XkiVfn/1oJMSLJis9mqOzs7T0Q6197efmylvbDNZqseGxsrnJycNJnNZndZWdnMSttqaWnZ3dPTEzGy9sMPPzyVrntevF5v1sTEhFlV1S/g6OioThCET4xG42xxcfFcqo1bS5ZKtAJAYr1FppEJouBwONi6urqzkXr2vLy8h16vN+U1FjiOOxspnJ5lWQ/P82m79f7Ro0f5Pp8vHyF0hqqoqAgNDw8HFhYW9G+aKCwOSY7Z7XZjb2/vJpfLZRIEgU20t8CsDjU1NUJ9ff3F69evf8/D8/l8m5qamppXqyJULCy1C7e2tjYtPYQwoVCIgRA+tVgsz1cdAoHAfwEAalNsV8pYFAe8EpABnDlz5mJdXV3EeYDe3t6DNpvtYSrE/PTp05uiDUfjXc5caxRFgYFAgFFV9TsAFlO8a5o2pSgKyfO8bunbMZjUUlNTI+zatSvqys2f//xn21rXb7Tb7cb29vaoCVn37t2b1svPPM/rNE0jVFV9CMCiKDx9+tQFAAB+vz8rlcZhMLFw+fLli9EC0SRJYtva2jrWShjCKd6WKmOXrpOLYXiezwIAAIZhHgGwKAp79+4NSZL0iOf5tN3WicG8zF/+8pdT0eIWBEEwtrW1dax2vopwAuBoghAOelpNG5LB3NwcJ8vyQ4vFIgLwUtVpTdPGgsEgEwgEUOrMw2Biw2q1evbt2xc1clQQBOPvf//7U42NjTHnt4iHpqam5uUSAO/bty/muJZUEQgEaFmWaQjhi815L0SBIIj7mqZpMzMz2akxD4OJj+7u7isNDQ1LRob29/cf4DjubEtLS8Kp+AB47h3k5+ef6u3tXXJ5saGhISPycM7OzmZDCNVQKDQaPvZCFOrq6p5BCB/xPI9FAZMx3Lhx4/xywhDOi1lUVHSipaVld7z1OxwOB7t///5dRUVFJzo7O0/4fL4lhyUNDQ3nMyGMXVEU6Pf7c1RVfdDQ0PAicPGVPQ8EQdyVJKnE6/Vm5efn47L0mIzgxo0b5xsbG8FyEaput7u6p6enuqen54jJZBretm3bzXA26Lq6Oo/VanXb7XbT48ePWafTWehyuUxDQ0P18YTEZ4ogAADA7OwspygKCQC4//LxVzIuHT9+nPj1r399CCEkVVVVPVlTCzEpJRMiGpejpaVl94ULFw6mIg8iQkjYt2/f2UwYMoRxOp0bZVkO1NbW/g1C+KJC3CvJVY4fP65KkvT/gsGg3u/369feTAxm5XR3d1+JZwdksjCZTMNdXV1HMkkQfD4fK8syjRAafFkQAHhNFAAAQKfTOVRVDUxPT+evnYkYTHKwWq0enucPRtu6nkwQQsKePXvOTk9PH0v3VYbXmZycLFAUZWbr1q3fy+/wPVGwWCyipmnfBINBvdfrxcFMmIyku7v7yrlz52wNDQ3nky0OCCHhZz/72fmBgYGDqdxrsVLcbne2KIqETqcbhhB+r2RkxCzOmqaRt2/f/h8URem3bNky8SZVpH5T+SHMKSxFS0vL7n/961/10aqMLQdCSMjPz//uo48+6srwnBjwzp07JZqmLVRXV59brPXwChEzLkEIleHh4a9kWW72eDw5xcXF/tW3FYNZPcJJbwB4Hmtw7dq1tycmJjb5/X6jJElsON0+QkigaZpHCAkmk+lhYWGhZ/v27XcyXAheMDExka8oCqXT6f4ZSRAAiCIKAABQXV09NjQ0ND4zM7OxoKBAoGk6YypTYzBLsbiL8o3bFs/zvM7n8+VSFPXgrbfeGo923ZKp3YPB4BVVVWWXy5W25bMxGMzyKIoCJyYmjKqqihDCvqWuXbYy1LfffltDkuRuo9E4g4cRGExmMjExUeD1evMQQr0Wi+XuUtcuWwTmJz/5iUOW5ftut7sA51vAYDIPr9eb5fV680iSdC4nCADEIAoAALCwsHAFQjg/Pj5eLIpi2haOwWAwrxIIBNDjx4+LIIRPCYL4Zyz3xFxY1ul05oui2KrX67Xy8vJJkiQjzlxiMJj0QBRF8sGDB+slSZKzs7PPl5WVxTT8j7mGpMVi8VIU9X94nocPHjwoVhQlbStVYzBvOoqiEGNjY2ZZlkmGYS7GKggAxCEKAABQXV09gRC6GgwG9WNjY0VYGDCY9ENRFOLBgwdmSZJojuP+c8uWLZPx3B93tena2to7iqJcDQQC7NjYWBGIYwiCwWBWl8UhgzkYDDIURf2jrKzs/vJ3vcqKf9C3bt3aBiHcyTBMoLy8fArPMWAwqUUURWpsbMwsSRJiWfZaeXn5tytpJ6FefmhoyAIh/AVJklJFRcUkjnrEYFJDIBCgFwVBMhgMX67EQwiTsOs/PDy8QZblX1EURZWWlk5xHBdMtE0MBhM7s7Oz3OTkpFFV1Tm9Xv+PeOcQXicp8wEOhyNPVdV9EEJDQUGB90c/+pEvGe1iMJglgS6Xa53P58shCMK7fv36CwUFBfMJN5oMywAAoK+vj+E4bhdCqIqm6WBpaalbr9dLyWofg8H8G7/fzzx58sQkSRICADgRQv8M121IlKSvHAwNDVk0TdtBEARdWFj41Gg0+nE+BgwmOSiKQkxMTOT7/f5cgiCesSzbl8j8QSRWZTnR6XRyoVBoF0EQZRRFicXFxbM4OzQGkxhutzt7ZmamQFEUCiF0Ly8v7yuz2Zz039Wqxhg4HI7Nqqr+XFVVNisrSyoqKvIaDIbA8ndiMJgws7OznNvtzl+s5OTlOK6vrKzs0Wo9b9UDj/r6+qicnJxaWZYtOp2ugGGYQGFhoQ97DhhMdBRFgbOzs5zX680TRZEmCIInCOJfFotlOFrGpGSxZtGIAwMDCCFUrarqOxDCbISQlJ2dzefl5S1wHJeUCRIMJtPxer36hYUFbmFhgVMUhaQoKkRR1PWqqionhFBZCxvWPET5+PHjxAcffFAJANhCkmQphBBSFCXm5ubyHMc9MxgMOM4B8yYBvV6vfn5+PovneU5RFApCqEIIXRRFObdu3Tq6fBNJNmitH/gyfX19XHZ2dqWmaZsRQhsAAABCqOr1+mBWVlZQr9cHDQZDEIdQY34oiKJIzc/PMzzPM6FQiAmFQjpN0yAAACiK4oIQjj158mT0V7/6VcqG12mzmam7u1tvNps36vX6UoIgiiGEeeFzJEkqEEKFpmmZoigZh1NjMgFVVaEsy5Qsy6Qsy5QkSZSmaQQAAEAINZIkn4VCof8CAEwxDPMoWXEGiZI2ovA6o6OjOp/PZwQAFAAAchRFoWmazkEIGQAANACA0jTtxT8Zg0kXIISqqqoyQRAaRVEqz/NugiB4kiRDmqbNkST5FCE0ky4i8Dr/H40ZBZaYnf3kAAAAAElFTkSuQmCC";
/**
 * 环境相关方法
 */ /* 判断是否为 edit 态 */
function isEdit(env) {
  if (env !== null && env !== void 0 && env.edit) {
    return true;
  } else {
    return false;
  }
}
/* 判断是否在设计器中运行 */
function isDesigner(env) {
  var _env$runtime;
  if (env !== null && env !== void 0 && env.edit || env !== null && env !== void 0 && (_env$runtime = env.runtime) !== null && _env$runtime !== void 0 && _env$runtime.debug) {
    return true;
  } else {
    var _window;
    return !!((_window = window) !== null && _window !== void 0 && _window.mybricks);
  }
}
function isH5() {
  return Taro.getEnv() === Taro.ENV_TYPE.WEB || Taro.getEnv() === "Unknown";
}
function DefaultNavigation(props) {
  var data = props.data,
    env = props.env;
  var onBack = function onBack() {
    if (env.runtime) {
      console.log("back");
      env.canvas.back();
    }
  };
  return __combine_nesting_style__(/*#__PURE__*/React__default.createElement(TaroViewTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), css$c.defaultNavigation),
    className: css$c.defaultNavigation,
    style: {
      background: data.navigationBarBackgroundColor
    }
  }, /*#__PURE__*/React__default.createElement(TaroViewTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), css$c.safearea),
    className: css$c.safearea
  }), /*#__PURE__*/React__default.createElement(TaroViewTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), css$c.main),
    className: css$c.main
  }, !data.useTabBar ? /*#__PURE__*/React__default.createElement(TaroViewTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), css$c.left),
    className: css$c.left
  }, /*#__PURE__*/React__default.createElement(TaroImageTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), css$c.backIcon),
    className: css$c.backIcon,
    src: data.navigationBarTextStyle === "white" ? backIconWhite : backIconBlack,
    onClick: onBack
  }), data.homeButton ? /*#__PURE__*/React__default.createElement(TaroImageTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), css$c.homeIcon),
    className: css$c.homeIcon,
    src: data.navigationBarTextStyle === "white" ? homeButtonWhite : homeButtonBlack
  }) : null) : null, isDesigner(env) && (data.showNavigationBarCapsule == true || data.showNavigationBarCapsule == undefined) && /*#__PURE__*/React__default.createElement(TaroImageTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), css$c.right),
    className: css$c.right,
    src: data.navigationBarTextStyle === "white" ? menuButtonWhite : menuButtonBlack
  }), /*#__PURE__*/React__default.createElement(TaroViewTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), css$c.title),
    className: css$c.title,
    style: {
      color: data.navigationBarTextStyle
    }
  }, data.navigationBarTitleText))), __nesting_style__());
}
var css$b = {
  "customNavigation": "style_customNavigation__ddSi4",
  "safearea": "style_safearea__Aqfot",
  "main": "style_main__nDuLd",
  "right": "style_right__vFBLx",
  "title": "style_title__Rg8y4"
};
var defaultMenuButtonBoundingClientRect$2 = {
  width: 87,
  height: 32,
  top: 48,
  right: 368,
  bottom: 80,
  left: 281
};
function CustomNavigation(props) {
  var _slots$mainSlot, _data$customNavigatio;
  var env = props.env,
    data = props.data,
    slots = props.slots;
  var relativeRect = useMemo(function () {
    if (isDesigner(env)) {
      return defaultMenuButtonBoundingClientRect$2;
    } else {
      var boundingClientRect = Taro.getMenuButtonBoundingClientRect();
      var ratio = Taro.getSystemInfoSync().windowWidth / 375;
      return {
        width: boundingClientRect.width / ratio,
        height: boundingClientRect.height / ratio,
        top: boundingClientRect.top / ratio,
        right: boundingClientRect.right / ratio,
        bottom: boundingClientRect.bottom / ratio,
        left: boundingClientRect.left / ratio
      };
    }
  }, []);
  var safeareaHeight = isDesigner(env) ? 44 : relativeRect.top - (40 - relativeRect.height) / 2;
  // 自定义导航栏
  return __combine_nesting_style__(/*#__PURE__*/React__default.createElement(TaroViewTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), css$b.customNavigation),
    className: css$b.customNavigation,
    style: _objectSpread2({}, data.customNavigation.style)
  }, /*#__PURE__*/React__default.createElement(TaroViewTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), css$b.safearea),
    className: css$b.safearea,
    style: {
      height: safeareaHeight
    }
  }), /*#__PURE__*/React__default.createElement(TaroViewTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), css$b.main),
    className: css$b.main,
    style: {
      marginLeft: 375 - relativeRect.right,
      marginRight: 375 - relativeRect.right,
      height: 40 // 高度固定 40 px
    }
  }, isDesigner(env) && (data.showNavigationBarCapsule == true || data.showNavigationBarCapsule == undefined) && /*#__PURE__*/React__default.createElement(TaroImageTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), css$b.right),
    className: css$b.right,
    src: data.navigationBarTextStyle === "white" ? menuButtonWhite : menuButtonBlack
  }), /*#__PURE__*/React__default.createElement(TaroViewTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), cx("mybricks-mainSlot", css$b.title)),
    className: cx("mybricks-mainSlot", css$b.title)
  }, (_slots$mainSlot = slots["mainSlot"]) === null || _slots$mainSlot === void 0 ? void 0 : _slots$mainSlot.render({
    style: _objectSpread2({}, ((_data$customNavigatio = data.customNavigation) === null || _data$customNavigatio === void 0 ? void 0 : _data$customNavigatio.mainSlotStyle) || {})
  })))), __nesting_style__());
}
var css$a = {
  "noneNavigation": "style_noneNavigation__W0Lnn",
  "safearea": "style_safearea__pqYOV",
  "main": "style_main__6Tc-W",
  "left": "style_left__L-ozj",
  "right": "style_right__KKGPT",
  "title": "style_title__KEBnS",
  "backIcon": "style_backIcon__VfapO"
};
var defaultMenuButtonBoundingClientRect$1 = {
  width: 87,
  height: 32,
  top: 48,
  right: 368,
  bottom: 80,
  left: 281
};
function NoneNavigation(props) {
  var data = props.data,
    env = props.env;
  var relativeRect = useMemo(function () {
    if (isDesigner(env)) {
      return defaultMenuButtonBoundingClientRect$1;
    } else {
      var boundingClientRect = Taro.getMenuButtonBoundingClientRect();
      var ratio = Taro.getSystemInfoSync().windowWidth / 375;
      return {
        width: boundingClientRect.width / ratio,
        height: boundingClientRect.height / ratio,
        top: boundingClientRect.top / ratio,
        right: boundingClientRect.right / ratio,
        bottom: boundingClientRect.bottom / ratio,
        left: boundingClientRect.left / ratio
      };
    }
  }, []);
  var safeareaHeight = isDesigner(env) ? 44 : relativeRect.top - (40 - relativeRect.height) / 2;
  // 隐藏导航栏
  return __combine_nesting_style__(/*#__PURE__*/React__default.createElement(TaroViewTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), css$a.noneNavigation),
    className: css$a.noneNavigation
  }, /*#__PURE__*/React__default.createElement(TaroViewTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), css$a.safearea),
    className: css$a.safearea,
    style: {
      height: safeareaHeight
    }
  }), /*#__PURE__*/React__default.createElement(TaroViewTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), css$a.main),
    className: css$a.main,
    style: {
      marginLeft: 375 - relativeRect.right,
      marginRight: 375 - relativeRect.right,
      height: 40
    }
  }, !data.useTabBar && data.showNavigationBackBtnInNone ? /*#__PURE__*/React__default.createElement(TaroViewTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), css$a.left),
    className: css$a.left
  }, /*#__PURE__*/React__default.createElement(TaroImageTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), cx(css$a.backIcon, "mybricks-backIcon")),
    className: cx(css$a.backIcon, "mybricks-backIcon"),
    src: data.customBackIcon ? data.customBackIcon : data.navigationBarTextStyle === "white" ? backIconWhite : backIconBlack,
    onClick: function onClick(e) {
      if (!env.runtime) {
        return;
      } else if (env.runtime.debug) {
        env.canvas.back(-1);
      } else if (env.runtime) {
        Taro.navigateBack({
          delta: 1
        });
      }
    }
  })) : null, /*#__PURE__*/React__default.createElement(TaroViewTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), cx(css$a.title, "mybricks-navTitle")),
    className: cx(css$a.title, "mybricks-navTitle"),
    style: {
      color: data.navigationBarTextStyle
    }
  }, data.showNavigationTextInNone ? data.navigationBarTitleText : ""), isDesigner(env) && (data.showNavigationBarCapsule == true || data.showNavigationBarCapsule == undefined) && /*#__PURE__*/React__default.createElement(TaroImageTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), css$a.right),
    className: css$a.right,
    src: data.navigationBarTextStyle === "white" ? menuButtonWhite : menuButtonBlack
  }))), __nesting_style__());
}
var css$9 = {
  "tabBar": "style_tabBar__Hevxs",
  "items": "style_items__5wO3h",
  "item": "style_item__z8J2r",
  "iconSlot": "style_iconSlot__P7NBw",
  "icon": "style_icon__kxloc",
  "iconSlotCenter": "style_iconSlotCenter__UW--l",
  "textSlot": "style_textSlot__h4G6a"
};
var CustomTabBar = function (_ref) {
  var data = _ref.data,
    env = _ref.env,
    _inputsCallable = _ref._inputsCallable;
  var onClickItem = useCallback(function (raw) {
    var _env$runtime;
    if (!((_env$runtime = env.runtime) !== null && _env$runtime !== void 0 && _env$runtime.debug)) {
      return;
    }
    if (raw.scene.id) {
      env.canvas.open(raw.scene.id, {}, "popup");
      _inputsCallable['_open']({});
    }
  }, [env]);
  var $tabBars = useMemo(function () {
    return data.tabBar.map(function (raw, index) {
      var isSelected = data.id == raw.scene.id;
      // 如果有强制覆盖的时候
      if (data.selectedTabItemIndex !== undefined && data.selectedTabItemCatelog !== undefined) {
        isSelected = data.selectedTabItemIndex === index;
        if (isSelected) {
          isSelected = data.selectedTabItemCatelog === "激活样式" ? true : false;
        }
      }
      var itemCx = cx(_defineProperty(_defineProperty({
        "mybricks-tabItem": env.edit
      }, css$9.item, true), css$9.selected, isSelected));
      var icon = isSelected ? raw.selectedIconPath : raw.normalIconPath;
      var iconStyle = isSelected ? raw.selectedIconStyle : raw.normalIconStyle;
      var textStyle = isSelected ? raw.selectedTextStyle : raw.normalTextStyle;
      var backgroundStyle = isSelected ? raw.selectedBackgroundStyle : raw.normalBackgroundStyle;
      var iconSlotCx = cx(_defineProperty(_defineProperty({}, css$9.iconSlot, true), css$9.iconSlotCenter, !raw.text));
      return /*#__PURE__*/React__default.createElement(TaroViewTagName, {
        __hmStyle: calcStaticStyle(__inner_style__(), itemCx),
        className: itemCx,
        style: _objectSpread2({}, backgroundStyle),
        onClick: function onClick() {
          onClickItem(raw);
        }
      }, /*#__PURE__*/React__default.createElement(TaroViewTagName, {
        __hmStyle: calcStaticStyle(__inner_style__(), iconSlotCx),
        className: iconSlotCx
      }, /*#__PURE__*/React__default.createElement(TaroImageTagName, {
        __hmStyle: calcStaticStyle(__inner_style__(), css$9.icon),
        className: css$9.icon,
        style: _objectSpread2({}, iconStyle),
        src: icon
      })), /*#__PURE__*/React__default.createElement(TaroViewTagName, {
        __hmStyle: calcStaticStyle(__inner_style__(), css$9.textSlot),
        className: css$9.textSlot
      }, /*#__PURE__*/React__default.createElement(TaroViewTagName, {
        __hmStyle: calcStaticStyle(__inner_style__(), css$9.text),
        className: css$9.text,
        style: _objectSpread2({}, textStyle)
      }, raw.text)));
    });
  }, [data.tabBar, env.canvas.id, data.id, data.selectedTabItemIndex, data.selectedTabItemCatelog]);
  return __combine_nesting_style__(/*#__PURE__*/React__default.createElement(TaroViewTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), css$9.tabBar),
    className: css$9.tabBar
  }, /*#__PURE__*/React__default.createElement(TaroViewTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), css$9.items),
    className: css$9.items
  }, $tabBars)), __nesting_style__());
};
var _excluded$1 = ["cancelPullRefresh"];
var isIOS = Taro.getSystemInfoSync().platform === "ios";
var defaultMenuButtonBoundingClientRect = {
  width: 87,
  height: 32,
  top: 48,
  right: 368,
  bottom: 80,
  left: 281
};
var usePullDownRefresh = function usePullDownRefresh(_ref) {
  var _ref$enabled = _ref.enabled,
    enabled = _ref$enabled === void 0 ? false : _ref$enabled,
    onLoad = _ref.onLoad,
    setDisableScrollWhenPulling = _ref.setDisableScrollWhenPulling;
  var _useState = useState({
      refresherTriggered: false
    }),
    _useState2 = _slicedToArray(_useState, 2),
    state = _useState2[0],
    setState = _useState2[1];
  var onLoadRef = useRef(function () {
    return Promise.resolve();
  });
  var loading = useRef(false);
  useEffect(function () {
    onLoadRef.current = onLoad;
  }, [onLoad]);
  var onRefresh = useCallback(function () {
    var _onLoadRef$current;
    if (loading.current) {
      return;
    }
    setState({
      refresherTriggered: true
    });
    loading.current = true;
    (_onLoadRef$current = onLoadRef.current) === null || _onLoadRef$current === void 0 || _onLoadRef$current.call(onLoadRef);
  }, []);
  var cancelPullRefresh = useCallback(function () {
    loading.current = false;
    setState({
      refresherTriggered: false
    });
  }, []);
  // const onRestore = useCallback(() => {
  //   setState({ refresherTriggered: false })
  // }, [])
  if (!enabled) {
    return {
      cancelPullRefresh: cancelPullRefresh,
      refresherEnabled: false
    };
  }
  return {
    cancelPullRefresh: cancelPullRefresh,
    refresherEnabled: true,
    refresherThreshold: 100,
    refresherDefaultStyle: "black",
    refresherBackground: "transparent",
    refresherTriggered: state.refresherTriggered,
    onRefresherRefresh: onRefresh,
    onRefresherPulling: function onRefresherPulling(e) {
      // 下拉时，禁止 scroll-view 滚动
      setDisableScrollWhenPulling(true);
    },
    onRefresherStatusChange: function onRefresherStatusChange(e) {
      console.log("onRefresherStatusChange", e.detail);
      if (e.detail === "releasing") {
        Taro.vibrateShort();
      }
    },
    onRefresherRestore: function onRefresherRestore(e) {
      console.log("onRefresherRestore", e.detail);
      setDisableScrollWhenPulling(false);
    },
    onRefresherAbort: function onRefresherAbort(e) {
      console.log("onRefresherAbort", e.detail);
      setDisableScrollWhenPulling(false);
    }
  };
};
function mybricks_taro_systemPage(props) {
  var _env$runtime, _slots$content, _slots$content$render, _slots$footerBar, _slots$footerBar$rend;
  var id = props.id,
    env = props.env,
    data = props.data,
    inputs = props.inputs,
    outputs = props.outputs,
    slots = props.slots;
  var _useState3 = useState(false),
    _useState4 = _slicedToArray(_useState3, 2),
    ready = _useState4[0],
    setReady = _useState4[1];
  var _useState5 = useState(0),
    _useState6 = _slicedToArray(_useState5, 2),
    footerHeight = _useState6[0],
    setFooterHeight = _useState6[1];
  var footerRef = useRef(null);
  var scrollRef = useRef(null);
  var _useState7 = useState(0),
    _useState8 = _slicedToArray(_useState7, 2);
  _useState8[0];
  _useState8[1];
  var _useState9 = useState(false),
    _useState10 = _slicedToArray(_useState9, 2),
    disableScrollWhenPulling = _useState10[0],
    setDisableScrollWhenPulling = _useState10[1];
  /**
  * 监听页面重新显示、隐藏
  */
  useEffect(function () {
    Taro.eventCenter.on("pageDidShow", function (_ref2) {
      var _outputs$pageDidShow;
      var path = _ref2.path,
        query = _ref2.query;
      if (path.indexOf(env.canvas.id) === -1) {
        return;
      }
      (_outputs$pageDidShow = outputs["pageDidShow"]) === null || _outputs$pageDidShow === void 0 || _outputs$pageDidShow.call(outputs, _objectSpread2({}, query));
    });
    Taro.eventCenter.on("pageDidHide", function (_ref3) {
      var _outputs$pageDidHide;
      var path = _ref3.path,
        query = _ref3.query;
      if (path.indexOf(env.canvas.id) === -1) {
        return;
      }
      (_outputs$pageDidHide = outputs["pageDidHide"]) === null || _outputs$pageDidHide === void 0 || _outputs$pageDidHide.call(outputs, _objectSpread2({}, query));
    });
  }, []);
  useEffect(function () {
    if (isDesigner(env)) {
      return;
    }
    if (!footerRef.current) {
      return;
    }
    var query = Taro.createSelectorQuery();
    query.select("#".concat(id, " .mybricks-footer")).boundingClientRect();
    query.exec(function (res) {
      if (res[0]) {
        var windowWidth = isDesigner(env) ? 315 : Taro.getSystemInfoSync().windowWidth;
        var height = res[0].height / windowWidth * 375;
        console.log("footerHeight", height);
        setFooterHeight(height);
      }
    });
  }, [footerRef.current]);
  // 获取菜单按钮的布局位置信息
  var relativeRect = useMemo(function () {
    if (isDesigner(env)) {
      return defaultMenuButtonBoundingClientRect;
    } else {
      var boundingClientRect = Taro.getMenuButtonBoundingClientRect();
      var ratio = Taro.getSystemInfoSync().windowWidth / 375;
      return {
        width: boundingClientRect.width / ratio,
        height: boundingClientRect.height / ratio,
        top: boundingClientRect.top / ratio,
        right: boundingClientRect.right / ratio,
        bottom: boundingClientRect.bottom / ratio,
        left: boundingClientRect.left / ratio
      };
    }
  }, []);
  var useTabBar = useMemo(function () {
    if (!data.useTabBar) {
      return false;
    }
    if (data.tabBar.length < 2 || data.tabBar.length > 5) {
      return false;
    }
    var isContain = data.tabBar.find(function (item) {
      return item.scene.id == env.canvas.id;
    });
    if (!isContain) {
      return false;
    }
    return true;
  }, [data.useTabBar, data.tabBar, env.canvas.id, data.id]);
  useEffect(function () {
    env.useTabBar = useTabBar;
  }, [useTabBar]);
  var onLoad = useCallback(function () {
    var _outputs$pulldown;
    (_outputs$pulldown = outputs["pulldown"]) === null || _outputs$pulldown === void 0 || _outputs$pulldown.call(outputs, true);
  }, []);
  var _useState11 = useState({
      scrollWithAnimation: false,
      scrollAnimationDuration: 0,
      scrollIntoView: "u_000none",
      scrollTop: 0
    }),
    _useState12 = _slicedToArray(_useState11, 2),
    scrollToProps = _useState12[0],
    setScrollToProps = _useState12[1];
  var _usePullDownRefresh = usePullDownRefresh({
      enabled: data.enabledPulldown,
      onLoad: onLoad,
      setDisableScrollWhenPulling: setDisableScrollWhenPulling
    }),
    cancelPullRefresh = _usePullDownRefresh.cancelPullRefresh,
    pulldownProps = _objectWithoutProperties(_usePullDownRefresh, _excluded$1);
  useEffect(function () {
    var _inputs$cancelPulldow;
    (_inputs$cancelPulldow = inputs["cancelPulldown"]) === null || _inputs$cancelPulldow === void 0 || _inputs$cancelPulldow.call(inputs, function () {
      cancelPullRefresh === null || cancelPullRefresh === void 0 || cancelPullRefresh();
    });
  }, [cancelPullRefresh]);
  useEffect(function () {
    var _inputs$setShare;
    (_inputs$setShare = inputs["setShare"]) === null || _inputs$setShare === void 0 || _inputs$setShare.call(inputs, function (val) {
      var _env$setShareConfig, _env$setShareConfig2;
      var msgConfig = {};
      var timelineConfig = {};
      if (val !== null && val !== void 0 && val.title || val !== null && val !== void 0 && val.imageUrl) {
        msgConfig = {
          title: val.title,
          imageUrl: val.imageUrl
        };
        // 分享给好友支持 path
        if (val !== null && val !== void 0 && val.path) {
          msgConfig["path"] = val.path;
        }
        timelineConfig = {
          title: val.title
        }; // 分享到朋友圈暂时不加图片
      } else {
        if (val.message) {
          msgConfig = val.message;
        }
        if (val.timeline) {
          timelineConfig = val.timeline;
        }
      }
      env === null || env === void 0 || (_env$setShareConfig = env.setShareConfig) === null || _env$setShareConfig === void 0 || _env$setShareConfig.call(env, "message", msgConfig);
      env === null || env === void 0 || (_env$setShareConfig2 = env.setShareConfig) === null || _env$setShareConfig2 === void 0 || _env$setShareConfig2.call(env, "timeline", timelineConfig);
    });
  }, []);
  useMemo(function () {
    if (env !== null && env !== void 0 && env.rootScroll && !isDesigner(env)) {
      env.rootScroll.scrollTo = function (_ref4) {
        var scrollTop = _ref4.scrollTop,
          id = _ref4.id,
          _ref4$duration = _ref4.duration,
          duration = _ref4$duration === void 0 ? 0 : _ref4$duration;
        /** 这里务必注意，scrollTop的优先级比scrollIntoView高，且这两个值只会在变化时生效，所以每次setScrollToProps务必只设置变化的字段，保证之前字段不变 */
        var isAnimte = duration > 0;
        if (id) {
          // H5
          if (isH5()) {
            var anchor = document.querySelector(id);
            if (anchor) {
              document.querySelector("#root_scroll").scrollTo({
                top: anchor.offsetTop,
                behavior: isAnimte ? "smooth" : "auto"
              });
              return;
            }
          }
          setScrollToProps(function (c) {
            return _objectSpread2(_objectSpread2({}, c), {}, {
              scrollIntoView: id,
              scrollTop: Math.random() + 20,
              scrollAnimationDuration: duration,
              scrollWithAnimation: isAnimte
            });
          });
        } else {
          setScrollToProps(function (c) {
            return _objectSpread2(_objectSpread2({}, c), {}, {
              scrollTop: scrollTop,
              scrollAnimationDuration: duration,
              scrollWithAnimation: isAnimte
            });
          });
          // hack 设置当前滚动位置
          scrollRef.current = scrollTop;
        }
      };
      env.rootScroll.getBoundingClientRect = function () {
        return new Promise(function (resolve, reject) {
          Taro.createSelectorQuery().select("#root_scroll").boundingClientRect(function (rect) {
            resolve(rect);
          }).exec();
        });
      };
    }
  }, []);
  var handleScroll = useCallback(function (e) {
    var _env$rootScroll, _env$rootScroll$emitS;
    scrollRef.current = e.detail.scrollTop;
    env === null || env === void 0 || (_env$rootScroll = env.rootScroll) === null || _env$rootScroll === void 0 || (_env$rootScroll$emitS = _env$rootScroll.emitScrollEvent) === null || _env$rootScroll$emitS === void 0 || _env$rootScroll$emitS.call(_env$rootScroll, e);
  }, [scrollRef.current]);
  useEffect(function () {
    if (!(data !== null && data !== void 0 && data.enabledShareMessage)) {
      Taro.hideShareMenu({
        menus: ["shareAppMessage", "shareTimeline"]
      });
    }
  }, []);
  /**
  * 骨架屏
  */
  useEffect(function () {
    inputs === null || inputs === void 0 || inputs["ready"](function () {
      setReady(true);
    });
  }, []);
  var slotStyle = useMemo(function () {
    var _data$layout;
    if (((_data$layout = data.layout) === null || _data$layout === void 0 ? void 0 : _data$layout.position) === "smart") {
      return {
        overflow: "visible",
        // overflow 必须是visible，用于覆盖render-web给的overflow: hidden，否则子元素的sticky不生效
        // overflow: "hidden auto", // auto 会导致页面出现滚动条
        display: "inline-block" // 防止margin重叠用，触发BFC，不可以删除
      };
    }
    return {
      height: "fit-content !important",
      // 防止margin重叠用，触发BFC，不可以删除
      display: "inline-block" // 防止margin重叠用，触发BFC，不可以删除
    };
  }, [data.layout, data.bottomSpace]);
  var background = useMemo(function () {
    var result = {};
    if (data.backgroundImage) {
      result["backgroundImage"] = "".concat(data.backgroundImage);
    }
    if (data.backgroundSize) {
      result["backgroundSize"] = data.backgroundSize;
    }
    if (data.backgroundRepeat) {
      result["backgroundRepeat"] = data.backgroundRepeat;
    }
    if (data.backgroundPosition) {
      result["backgroundPosition"] = data.backgroundPosition;
    }
    if (data.background) {
      result["backgroundColor"] = data.background;
    }
    return result;
  }, [data.backgroundImage, data.backgroundSize, data.backgroundRepeat, data.backgroundPosition, data.background]);
  if (data.useLoading && !ready) {
    return __combine_nesting_style__(/*#__PURE__*/React__default.createElement(TaroViewTagName, {
      __hmStyle: calcStaticStyle(__inner_style__(), css$d.loading),
      className: css$d.loading
    }, /*#__PURE__*/React__default.createElement(TaroViewTagName, {
      __hmStyle: calcStaticStyle(__inner_style__(), css$d.icon),
      className: css$d.icon
    })), __nesting_style__());
  }
  return __combine_nesting_style__(/*#__PURE__*/React__default.createElement(TaroViewTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), cx(_defineProperty(_defineProperty(_defineProperty({}, css$d.page, true), css$d.h5page, isH5()), css$d.debug, isDesigner(env)))),
    className: cx(_defineProperty(_defineProperty(_defineProperty({}, css$d.page, true), css$d.h5page, isH5()), css$d.debug, isDesigner(env))),
    style: _objectSpread2({}, background)
  }, data.useNavigationStyle === "default" ? /*#__PURE__*/React__default.createElement(React__default.Fragment, null, env.runtime.debug ? /*#__PURE__*/React__default.createElement(React__default.Fragment, null, /*#__PURE__*/React__default.createElement(TaroViewTagName, {
    style: {
      width: 375,
      height: 84
    }
  }), /*#__PURE__*/React__default.createElement(TaroViewTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), css$d.fixedTop),
    className: css$d.fixedTop
  }, /*#__PURE__*/React__default.createElement(DefaultNavigation, {
    env: env,
    data: data
  }))) : null) : null, data.useNavigationStyle === "custom" ? /*#__PURE__*/React__default.createElement(React__default.Fragment, null, (_env$runtime = env.runtime) !== null && _env$runtime !== void 0 && _env$runtime.debug ? /*#__PURE__*/React__default.createElement(React__default.Fragment, null, /*#__PURE__*/React__default.createElement(TaroViewTagName, {
    style: {
      width: 375,
      height: 84
    }
  }), /*#__PURE__*/React__default.createElement(TaroViewTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), css$d.fixedTop),
    className: css$d.fixedTop
  }, /*#__PURE__*/React__default.createElement(CustomNavigation, {
    env: env,
    data: data,
    slots: slots
  }))) : /*#__PURE__*/React__default.createElement(React__default.Fragment, null, /*#__PURE__*/React__default.createElement(TaroViewTagName, {
    id: "custom_navigation"
  }, /*#__PURE__*/React__default.createElement(TaroViewTagName, {
    style: {
      width: 375,
      height: relativeRect.top - (40 - relativeRect.height) / 2
    }
  }), /*#__PURE__*/React__default.createElement(TaroViewTagName, {
    style: {
      width: 375,
      height: 40
    }
  })), /*#__PURE__*/React__default.createElement(TaroViewTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), css$d.fixedTop),
    className: css$d.fixedTop
  }, /*#__PURE__*/React__default.createElement(CustomNavigation, {
    env: env,
    data: data,
    slots: slots
  })))) : null, data.useNavigationStyle === "none" ? /*#__PURE__*/React__default.createElement(NoneNavigation, {
    env: env,
    data: data
  }) : null, /*#__PURE__*/React__default.createElement(TaroViewTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), css$d.fixedContainer),
    id: "root",
    className: css$d.fixedContainer
  }, /*#__PURE__*/React__default.createElement(TaroScrollViewTagName, _extends({
    key: "page",
    id: "root_scroll",
    scrollY: !data.disableScroll && !disableScrollWhenPulling,
    enhanced: isIOS && data.enabledPulldown ? false : true,
    bounce: false,
    enablePassive: true,
    showScrollbar: false,
    onScroll: handleScroll,
    enableBackToTop: true,
    "using-sticky": true
  }, scrollToProps, {
    scrollTop: scrollRef.current
  }, pulldownProps, {
    __hmStyle: calcStaticStyle(__inner_style__(), css$d.contentScrollView),
    className: css$d.contentScrollView
  }), (_slots$content = slots["content"]) === null || _slots$content === void 0 || (_slots$content$render = _slots$content.render) === null || _slots$content$render === void 0 ? void 0 : _slots$content$render.call(_slots$content, {
    style: _objectSpread2({}, slotStyle)
  }))), useTabBar && env.runtime.debug ? /*#__PURE__*/React__default.createElement(React__default.Fragment, null, /*#__PURE__*/React__default.createElement(TaroViewTagName, {
    style: {
      width: 375,
      height: 60
    }
  }), /*#__PURE__*/React__default.createElement(TaroViewTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), css$d.fixedBottom),
    className: css$d.fixedBottom
  }, /*#__PURE__*/React__default.createElement(CustomTabBar, props))) : null, useTabBar && !env.runtime.debug && !isH5() ? /*#__PURE__*/React__default.createElement(TaroViewTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), cx(css$d.tabBarPlaceholder)),
    className: cx(css$d.tabBarPlaceholder)
  }) : null, !useTabBar && data.useFooter ? /*#__PURE__*/React__default.createElement(React__default.Fragment, null, /*#__PURE__*/React__default.createElement(TaroViewTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), css$d.footerPlaceholder),
    className: css$d.footerPlaceholder,
    style: {
      height: footerHeight
    }
  }), /*#__PURE__*/React__default.createElement(TaroViewTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), cx(css$d.footer, "mybricks-footer")),
    className: cx(css$d.footer, "mybricks-footer"),
    ref: footerRef
  }, (_slots$footerBar = slots["footerBar"]) === null || _slots$footerBar === void 0 || (_slots$footerBar$rend = _slots$footerBar.render) === null || _slots$footerBar$rend === void 0 ? void 0 : _slots$footerBar$rend.call(_slots$footerBar), /*#__PURE__*/React__default.createElement(TaroViewTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), css$d.safearea),
    className: css$d.safearea
  }))) : null), __nesting_style__());
}
var css$8 = {
  "popup": "style_popup__bisqh",
  "overlay": "style_overlay__JdoAF",
  "main": "style_main__bts6l",
  "close": "style_close__zK7yY",
  "center": "style_center__R3ESJ",
  "top": "style_top__tphmn",
  "bottom": "style_bottom__KVoj-",
  "left": "style_left__DWWtV",
  "right": "style_right__g5U5y",
  "content": "style_content__PGOgq",
  "empty": "style_empty__q43Zh",
  "show": "style_show__6k-p5"
};
function mybricks_taro_popup(_ref) {
  var _slots$content2, _slots$content3, _slots$content3$rende;
  var env = _ref.env,
    _env = _ref._env,
    data = _ref.data;
  _ref.inputs;
  var outputs = _ref.outputs,
    slots = _ref.slots;
  _ref.createPortal;
  var _useState = useState(env.edit ? true : false),
    _useState2 = _slicedToArray(_useState, 2),
    show = _useState2[0];
  _useState2[1];
  var handleClose = useCallback(function () {
    var _env$currentScenes, _env$currentScenes$cl, _outputs$onClose;
    _env === null || _env === void 0 || (_env$currentScenes = _env.currentScenes) === null || _env$currentScenes === void 0 || (_env$currentScenes$cl = _env$currentScenes.close) === null || _env$currentScenes$cl === void 0 || _env$currentScenes$cl.call(_env$currentScenes);
    outputs === null || outputs === void 0 || (_outputs$onClose = outputs["onClose"]) === null || _outputs$onClose === void 0 || _outputs$onClose.call(outputs);
    // setShow(false);
  }, [_env]);
  /** setup */
  useEffect(function () {
    // inputs["onShow"]?.(() => {
    //   setShow(true);
    // });
    // inputs["onHide"]?.(() => {
    //   setShow(false);
    // });
    return function () {
      var _env$currentScenes2, _env$currentScenes2$c;
      // 销毁，但没有事件
      _env === null || _env === void 0 || (_env$currentScenes2 = _env.currentScenes) === null || _env$currentScenes2 === void 0 || (_env$currentScenes2$c = _env$currentScenes2.close) === null || _env$currentScenes2$c === void 0 || _env$currentScenes2$c.call(_env$currentScenes2);
    };
  }, []);
  var popupCx = useMemo(function () {
    return cx(_defineProperty(_defineProperty({}, css$8.popup, true), css$8.show, true));
  }, [show, env.edit]);
  var mainCx = useMemo(function () {
    var _slots$content;
    return cx(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty({}, css$8.main, true), css$8.center, data.position === "center"), css$8.top, data.position === "top"), css$8.bottom, data.position === "bottom"), css$8.left, data.position === "left"), css$8.right, data.position === "right"), css$8.empty, ((_slots$content = slots["content"]) === null || _slots$content === void 0 ? void 0 : _slots$content.size) === 0));
  }, [data.position, (_slots$content2 = slots["content"]) === null || _slots$content2 === void 0 ? void 0 : _slots$content2.size]);
  var handleOverlayClick = useCallback(function () {
    if (data.maskClose) {
      var _env$currentScenes3, _env$currentScenes3$c, _outputs$onClickOverl;
      _env === null || _env === void 0 || (_env$currentScenes3 = _env.currentScenes) === null || _env$currentScenes3 === void 0 || (_env$currentScenes3$c = _env$currentScenes3.close) === null || _env$currentScenes3$c === void 0 || _env$currentScenes3$c.call(_env$currentScenes3);
      outputs === null || outputs === void 0 || (_outputs$onClickOverl = outputs["onClickOverlay"]) === null || _outputs$onClickOverl === void 0 || _outputs$onClickOverl.call(outputs);
    }
    // outputs?.['onClickOverlay']?.(true);
  }, [_env, data.maskClose]);
  var isInEdit = isEdit(env);
  var isInDesignerRuntime = isDesigner(env);
  /** hack style 设计器下面一些需要hack的样式 */
  var popupStyle = useMemo(function () {
    // if (isInDesignerRuntime) { // 在设计器里模拟不超过小程序header的效果
    //   return {
    //     position: 'absolute'
    //   }
    // }
    // return {};
    if (isInEdit) {
      /** 新场景需要一个宽高 */return {
        width: 375,
        height: 667,
        position: "relative"
      };
    }
    if (isInDesignerRuntime) {
      /** 设计器runtime时需要fixed会相对于更上层的元素 */return {
        // position: 'absolute',
        width: 375
      };
    }
    return {};
  }, [isInEdit, isInDesignerRuntime]);
  var popupView = /*#__PURE__*/React__default.createElement(TaroViewTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), popupCx),
    className: popupCx,
    style: _objectSpread2({}, popupStyle)
  }, /*#__PURE__*/React__default.createElement(TaroViewTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), "".concat(css$8.overlay, " mybricks-overlay")),
    className: "".concat(css$8.overlay, " mybricks-overlay"),
    onClick: handleOverlayClick
  }), /*#__PURE__*/React__default.createElement(TaroViewTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), mainCx),
    className: mainCx
  }, /*#__PURE__*/React__default.createElement(TaroViewTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), cx(_defineProperty(_defineProperty({}, css$8.content, true), "mybricks-content", true))),
    className: cx(_defineProperty(_defineProperty({}, css$8.content, true), "mybricks-content", true))
  }, (_slots$content3 = slots["content"]) === null || _slots$content3 === void 0 || (_slots$content3$rende = _slots$content3.render) === null || _slots$content3$rende === void 0 ? void 0 : _slots$content3$rende.call(_slots$content3, {
    style: _objectSpread2({}, data.layout || {})
  })), data.position === "center" && data.visibleClose && /*#__PURE__*/React__default.createElement(TaroViewTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), cx(_defineProperty(_defineProperty({}, css$8.close, true), "mybricks-close", true))),
    className: cx(_defineProperty(_defineProperty({}, css$8.close, true), "mybricks-close", true)),
    onClick: handleClose
  })));
  return popupView;
}
var css$7 = {
  "com": "style_com__ha2-U",
  "image": "style_image__QhtkT"
};
var css$6 = {
  "com": "index_com__G-HMq",
  "place": "index_place__IvS1F",
  "none": "index_none__yqXJj"
};
var _window;
var pixelRatio = Taro.getSystemInfoSync().pixelRatio;
// const getWidth = (w: number) => Math.round(w / 200) * 200;
var dpr = pixelRatio !== null && pixelRatio !== void 0 ? pixelRatio : (_window = window) === null || _window === void 0 ? void 0 : _window.devicePixelRatio;
// const commonWidth = getWidth((window.screen.availWidth || document.body.clientWidth) * dpr);
// const isSupportWebp = (() => {
//   try {
//     return document.createElement('canvas').toDataURL('image/webp', 0.5).indexOf('data:image/webp') === 0;
//   } catch(err) {
//     return false;
//   }
// })()
// export function imageWebpProcess(url: string) {
//   return isSupportWebp ? url : ''
// }
// /**
//  * 给各个云存储的图片增加处理参数
//  */
// export function imageProcess(url: string, width: number) {
//   width = (width * dpr) | 0;
//   switch (true) {
//     case /https?:\/\/js/.test(url):
//       return imageProcessJs(url, width);
//     case /https?:\/\/ali/.test(url):
//       return imageProcessAli(url, width);
//     case /https?:\/\/tx/.test(url):
//       return imageProcessTx(url, width);
//     case /https?:\/\/p[0-9]\./.test(url): // 其他cdn，按cdn方的人来说是动态的，都支持阿里的参数
//       return imageProcessAli(url, width);
//     default:
//       return url;
//   }
// }
// /**
//  * 金山云 https://docs.ksyun.com/documents/886
//  * @param url
//  * @param width
//  */
// function imageProcessJs(url: string, width: number) {
//   width = width || commonWidth;
//   const pos = url.indexOf('@');
//   const base = url.slice(0, pos === -1 ? +Infinity : pos);
//   return base + '@base@tag=imgScale&m=1&w=' + width + '&q=85&interlace=1';
// }
// /**
//  * 阿里云 https://help.aliyun.com/document_detail/44687.html
//  * @param url
//  * @param width
//  */
// function imageProcessAli(url: string, width: number) {
//   width = width || commonWidth;
//   const pos = url.indexOf('?');
//   const base = url.slice(0, pos === -1 ? +Infinity : pos);
//   return base + '?x-oss-process=image/resize,w_' + width + '/format,jpg/interlace,1/quality,q_85';
// }
// /**
//  * 腾讯云 https://cloud.tencent.com/document/product/460/36540
//  * @param url
//  * @param width
//  */
// function imageProcessTx(url: string, width: number) {
//   width = width || commonWidth;
//   const pos = url.indexOf('?');
//   const base = url.slice(0, pos === -1 ? +Infinity : pos);
//   return base + '?imageView2/2/w/' + width + '/format/jpg/interlace/1/q/85';
// }
function autoCdnCut(_ref, options) {
  var url = _ref.url,
    width = _ref.width,
    height = _ref.height;
  var _ref2 = options !== null && options !== void 0 ? options : {},
    _ref2$quality = _ref2.quality,
    quality = _ref2$quality === void 0 ? 85 : _ref2$quality;
  if (!isString(url) || !url) {
    return url;
  }
  if (url.indexOf('https') === -1 || url.indexOf('assets.mybricks.world') === -1) {
    return url;
  }
  var query = '?x-oss-process=image/resize,';
  if (isNumber(width)) {
    query += "w_".concat((width * dpr).toFixed(0));
  } else if (isNumber(height)) {
    query += "h_".concat((height * dpr).toFixed(0));
  }
  if (isNumber(quality)) {
    query += "/quality,q_".concat(quality);
  }
  return "".concat(url).concat(query);
}
var _excluded = ["skeleton", "skeletonStyle", "onLoad", "onClick", "onError", "className", "src", "mode", "cdnCut", "cdnCutOption"];
function SkeletonImage(_ref) {
  var _ref$skeleton = _ref.skeleton,
    skeleton = _ref$skeleton === void 0 ? false : _ref$skeleton,
    skeletonStyle = _ref.skeletonStyle,
    onLoad = _ref.onLoad,
    onClick = _ref.onClick,
    onError = _ref.onError,
    className = _ref.className,
    src = _ref.src,
    mode = _ref.mode,
    _ref$cdnCut = _ref.cdnCut,
    cdnCut = _ref$cdnCut === void 0 ? "" : _ref$cdnCut,
    _ref$cdnCutOption = _ref.cdnCutOption,
    cdnCutOption = _ref$cdnCutOption === void 0 ? {} : _ref$cdnCutOption,
    props = _objectWithoutProperties(_ref, _excluded);
  var _useState = useState(!!skeleton),
    _useState2 = _slicedToArray(_useState, 2),
    loading = _useState2[0],
    setLoading = _useState2[1];
  useEffect(function () {
    if (src && skeleton) {
      setLoading(true);
    }
  }, [src, skeleton]);
  var _onLoad = useCallback(function (e) {
    setLoading(false);
    onLoad === null || onLoad === void 0 || onLoad(e);
  }, [onLoad]);
  var _onClick = useCallback(function (e) {
    onClick === null || onClick === void 0 || onClick(e);
  }, [onClick]);
  var _onError = useCallback(function (e) {
    setLoading(false);
    onError === null || onError === void 0 || onError(e);
  }, [onError]);
  var _src = useMemo(function () {
    if (cdnCut === "auto") {
      var cutUrl = autoCdnCut({
        url: src,
        width: cdnCutOption === null || cdnCutOption === void 0 ? void 0 : cdnCutOption.width,
        height: cdnCutOption === null || cdnCutOption === void 0 ? void 0 : cdnCutOption.height
      }, {
        quality: 90
      });
      return cutUrl;
    }
    return src;
  }, [src, cdnCut, cdnCutOption === null || cdnCutOption === void 0 ? void 0 : cdnCutOption.height, cdnCutOption === null || cdnCutOption === void 0 ? void 0 : cdnCutOption.height]);
  return __combine_nesting_style__(/*#__PURE__*/React__default.createElement(TaroViewTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), css$6.com),
    className: css$6.com
  }, /*#__PURE__*/React__default.createElement(TaroViewTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), loading ? "".concat(css$6.place) : "".concat(css$6.place, " ").concat(css$6.none)),
    className: loading ? "".concat(css$6.place) : "".concat(css$6.place, " ").concat(css$6.none),
    style: skeletonStyle
  }), _src && /*#__PURE__*/React__default.createElement(TaroImageTagName, _extends({
    __hmStyle: calcStaticStyle(__inner_style__(), className),
    lazyLoad: true,
    className: className,
    src: _src,
    mode: mode,
    onClick: _onClick,
    onLoad: _onLoad,
    onError: _onError,
    nativeProps: {
      loading: "lazy",
      decoding: "async"
    }
  }, props))), __nesting_style__());
}
function mybricks_taro_image(_ref) {
  var _data$showMenuByLongp;
  var env = _ref.env,
    data = _ref.data,
    inputs = _ref.inputs,
    outputs = _ref.outputs;
  _ref.title;
  var style = _ref.style,
    extra = _ref.extra;
  var ele = useRef(null);
  var _useState = useState(css$7["h5-polyfill-aspectfill-width"]),
    _useState2 = _slicedToArray(_useState, 2),
    h5PolyfillClass = _useState2[0],
    setH5PolyfillClass = _useState2[1];
  useEffect(function () {
    var _ele$current$getBound, _ele$current$getBound2, _ele$current;
    if (data.mode !== "aspectFill") {
      return;
    }
    if (!ele.current && !ele.current.getBoundingClientRect) {
      return;
    }
    var _ref2 = (_ele$current$getBound = (_ele$current$getBound2 = (_ele$current = ele.current).getBoundingClientRect) === null || _ele$current$getBound2 === void 0 ? void 0 : _ele$current$getBound2.call(_ele$current)) !== null && _ele$current$getBound !== void 0 ? _ele$current$getBound : {},
      width = _ref2.width,
      height = _ref2.height;
    setH5PolyfillClass(width > height ? css$7["h5-polyfill-aspectfill-width"] : css$7["h5-polyfill-aspectfill-height"]);
  }, [style.width, style.height, data.mode]);
  /** TODO 写在useEffect里时序有延迟，容易出现闪屏，先试试这样先 */
  useMemo(function () {
    inputs["setSrc"](function (src) {
      data.src = src;
    });
  }, []);
  var onLoad = useCallback(function () {
    if (!env.runtim) {
      return;
    }
    outputs["onLoad"](data.src);
  }, []);
  var onClick = useCallback(function (e) {
    if (!env.runtime) {
      return;
    }
    if (data.clickType === "previewImage") {
      Taro.previewImage({
        urls: [data.src],
        current: data.src
      });
      e.stopPropagation();
      return;
    }
    // 当配置了单击事件，阻止事件冒泡
    if (outputs["onClick"].getConnections().length) {
      e.stopPropagation();
    }
    outputs["onClick"](data.src);
  }, [data.clickType, data.src, data.stopPropagation]);
  var onError = useCallback(function () {
    if (!env.runtime) {
      return;
    }
    outputs["onError"](data.src);
  }, []);
  var src = useMemo(function () {
    var src = data.svgPolyfill || data.src || (extra === null || extra === void 0 ? void 0 : extra.imageUrl);
    return src;
  }, [data.svgPolyfill, data.src, extra === null || extra === void 0 ? void 0 : extra.imageUrl]);
  var svgProps = useMemo(function () {
    if (data.svgPolyfill) {
      return {
        svg: true,
        mode: "aspectFit"
      };
    } else {
      return {};
    }
  }, [data.svgPolyfill]);
  return __combine_nesting_style__(/*#__PURE__*/React__default.createElement(TaroViewTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), css$7.com),
    className: css$7.com,
    ref: ele
  }, /*#__PURE__*/React__default.createElement(SkeletonImage, _extends({
    __hmStyle: calcStaticStyle(__inner_style__(), cx(css$7.image, h5PolyfillClass, "mybricks-image")),
    __styleSheet: {
      key: cx(css$7.image, h5PolyfillClass, "mybricks-image"),
      value: calcStaticStyle(__inner_style__(), cx(css$7.image, h5PolyfillClass, "mybricks-image"))
    },
    skeleton: env.edit ? false : !!(data !== null && data !== void 0 && data.loadSmooth),
    className: cx(css$7.image, h5PolyfillClass, "mybricks-image"),
    src: src,
    mode: data.mode,
    onClick: onClick,
    onLoad: onLoad,
    onError: onError,
    showMenuByLongpress: (_data$showMenuByLongp = data.showMenuByLongpress) !== null && _data$showMenuByLongp !== void 0 ? _data$showMenuByLongp : false,
    cdnCut: "auto",
    cdnCutOption: {
      width: style.width,
      height: style.height
    }
  }, svgProps))), __nesting_style__());
}
var css$5 = {
  "button": "style_button__00vWp",
  "text": "style_text__sOFvV",
  "icon": "style_icon__9pUc5"
};
function mybricks_taro_button(_ref) {
  var env = _ref.env,
    data = _ref.data;
  _ref.logger;
  _ref.slots;
  var inputs = _ref.inputs,
    outputs = _ref.outputs;
  _ref.title;
  var extra = _ref.extra;
  /** TODO 写在useEffect里时序有延迟，容易出现闪屏，先试试这样先 */
  useMemo(function () {
    inputs["buttonText"](function (val) {
      data.text = val;
    });
  }, []);
  var openType = useMemo(function () {
    switch (true) {
      case data.openType === "getPhoneNumber":
        {
          return {
            openType: "getPhoneNumber",
            onGetPhoneNumber: function onGetPhoneNumber(e) {
              if (!!e.detail.errno) {
                outputs["getPhoneNumberFail"](_objectSpread2({}, e.detail));
              } else {
                outputs["getPhoneNumberSuccess"](_objectSpread2({}, e.detail));
              }
            }
          };
        }
      case data.openType === "getRealtimePhoneNumber":
        {
          return {
            openType: "getRealtimePhoneNumber",
            onGetRealtimePhoneNumber: function onGetRealtimePhoneNumber(e) {
              if (!!e.detail.errno) {
                outputs["getRealtimePhoneNumberFail"](_objectSpread2({}, e.detail));
              } else {
                outputs["getRealtimePhoneNumberSuccess"](_objectSpread2({}, e.detail));
              }
            }
          };
        }
      case data.openType === "share":
        {
          return {
            openType: "share",
            onClick: function onClick(e) {
              outputs["share"](_objectSpread2({}, e.detail));
            }
          };
        }
      case data.openType === "contact":
        {
          return {
            openType: "contact",
            onContact: function onContact(e) {
              outputs["onContact"](_objectSpread2({}, e.detail));
            }
          };
        }
      case data.openType === "feedback":
        {
          return {
            openType: "feedback"
          };
        }
      case data.openType === "openSetting":
        {
          return {
            openType: "openSetting"
          };
        }
      case data.openType === "chooseAvatar":
        {
          return {
            openType: "chooseAvatar",
            onChooseAvatar: function onChooseAvatar(e) {
              outputs["chooseAvatarSuccess"](e.mpEvent.detail.avatarUrl);
            }
          };
        }
      default:
        {
          return {
            onClick: function onClick(e) {
              if (env.runtime && !data.disabled) {
                if (outputs["onClick"].getConnections().length) {
                  e.stopPropagation();
                }
                outputs["onClick"](data.text);
              }
            }
          };
        }
    }
  }, [data.openType, data.text, env.runtime, data.disabled]);
  var useBeforeIcon = useMemo(function () {
    if (env.edit) {
      return data.useBeforeIcon;
    } else {
      return data.useBeforeIcon && data.beforeIconUrl;
    }
  }, [env, data.useBeforeIcon, data.beforeIconUrl]);
  var useAfterIcon = useMemo(function () {
    if (env.edit) {
      return data.useAfterIcon;
    } else {
      return data.useAfterIcon && data.afterIconUrl;
    }
  }, [env, data.useAfterIcon, data.afterIconUrl]);
  var disabled = useMemo(function () {
    if (data.disabled) {
      return {
        disabled: true
      };
    } else {
      return {};
    }
  }, [data.disabled]);
  // input禁用按钮
  useEffect(function () {
    var _inputs$setDisabled;
    (_inputs$setDisabled = inputs["setDisabled"]) === null || _inputs$setDisabled === void 0 || _inputs$setDisabled.call(inputs, function (val, relOutputs) {
      var _relOutputs$setDisabl;
      data.disabled = !!val;
      (_relOutputs$setDisabl = relOutputs["setDisabledSuccess"]) === null || _relOutputs$setDisabl === void 0 || _relOutputs$setDisabl.call(relOutputs, val);
    });
  }, []);
  // input启用按钮
  useEffect(function () {
    var _inputs$setEnabled;
    (_inputs$setEnabled = inputs["setEnabled"]) === null || _inputs$setEnabled === void 0 || _inputs$setEnabled.call(inputs, function (val, relOutputs) {
      var _relOutputs$setEnable;
      data.disabled = false;
      (_relOutputs$setEnable = relOutputs["setEnabledSuccess"]) === null || _relOutputs$setEnable === void 0 || _relOutputs$setEnable.call(relOutputs, val);
    });
  }, []);
  return __combine_nesting_style__(/*#__PURE__*/React__default.createElement(TaroButtonTagName, _extends({
    __hmStyle: calcStaticStyle(__inner_style__(), cx(css$5.button, data.disabled ? "mybricks-button-disable" : "mybricks-button")),
    className: cx(css$5.button, data.disabled ? "mybricks-button-disable" : "mybricks-button")
  }, disabled, openType), useBeforeIcon ? /*#__PURE__*/React__default.createElement(TaroImageTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), cx("mybricks-beforeIcon", css$5.icon)),
    className: cx("mybricks-beforeIcon", css$5.icon),
    src: data.beforeIconUrl || (extra === null || extra === void 0 ? void 0 : extra.imageUrl),
    mode: "scaleToFill"
  }) : null, /*#__PURE__*/React__default.createElement(TaroTextTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), css$5.text),
    className: css$5.text
  }, data.text), useAfterIcon ? /*#__PURE__*/React__default.createElement(TaroImageTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), cx("mybricks-afterIcon", css$5.icon)),
    className: cx("mybricks-afterIcon", css$5.icon),
    src: data.afterIconUrl || (extra === null || extra === void 0 ? void 0 : extra.imageUrl),
    mode: "scaleToFill"
  }) : null), __nesting_style__());
}
var css$4 = {
  "text": "style_text__NdCnF",
  "ellipsis-line": "style_ellipsis-line__BiWvf",
  "tooltip": "style_tooltip__DH2mp",
  "skeleton": "style_skeleton__iK542"
};
function mybricks_taro_text(_ref) {
  var id = _ref.id,
    env = _ref.env,
    data = _ref.data;
  _ref.style;
  var inputs = _ref.inputs,
    outputs = _ref.outputs;
  var _useState = useState(false),
    _useState2 = _slicedToArray(_useState, 2),
    ready = _useState2[0],
    setReady = _useState2[1];
  var _useState3 = useState(false),
    _useState4 = _slicedToArray(_useState3, 2),
    showTooltop = _useState4[0],
    setShowTooltop = _useState4[1];
  var _useState5 = useState({}),
    _useState6 = _slicedToArray(_useState5, 2),
    tooltipStyle = _useState6[0],
    setTooltipStyle = _useState6[1];
  var _useState7 = useState(null),
    _useState8 = _slicedToArray(_useState7, 2),
    timerId = _useState8[0],
    setTimerId = _useState8[1];
  var textRef = useRef(null);
  var _useState9 = useState(-1),
    _useState10 = _slicedToArray(_useState9, 2);
  _useState10[0];
  _useState10[1];
  var _useState11 = useState(-1),
    _useState12 = _slicedToArray(_useState11, 2);
  _useState12[0];
  _useState12[1];
  var _useState13 = useState(data.displayState),
    _useState14 = _slicedToArray(_useState13, 2),
    displayState = _useState14[0],
    setDisplayState = _useState14[1];
  // 兼容下之前的动态文本开关
  useEffect(function () {
    //老组件打开了动态文本渲染，则默认选中「隐藏」
    if (data.useDynamic) {
      setDisplayState("hidden");
      data.displayState = "hidden";
      data.useDynamic = false;
    }
  }, [data.useDynamic]);
  var displaySkeleton = useMemo(function () {
    if (displayState === "skeleton" && !ready && env.runtime) {
      return true;
    }
    return false;
  }, [displayState, env.runtime, ready]);
  /** TODO 写在useEffect里时序有延迟，容易出现闪屏，先试试这样先 */
  useMemo(function () {
    var _inputs$getValue;
    inputs["value"](function (val) {
      data.text = val;
      setReady(true);
    });
    (_inputs$getValue = inputs["getValue"]) === null || _inputs$getValue === void 0 || _inputs$getValue.call(inputs, function (val, outputRels) {
      if (!ready && displayState === "hidden" && displayState === "skeleton") {
        outputRels["onGetValue"]("");
      } else {
        outputRels["onGetValue"](data.text);
      }
    });
  }, [ready]);
  var textCx = useMemo(function () {
    return cx(_defineProperty(_defineProperty(_defineProperty({}, css$4.text, true), "mybricks-text", true), id, true));
  }, [id, data.ellipsis]);
  var ellipsisCx = useMemo(function () {
    return cx(_defineProperty({}, css$4["ellipsis-line"], !!data.ellipsis));
  }, [data.ellipsis]);
  var SkeletonCx = useMemo(function () {
    return cx(_defineProperty({}, css$4.skeleton, displaySkeleton));
  }, [displaySkeleton]);
  var textStyle = useMemo(function () {
    //隐藏文本但是保留占位，撑开骨骼图
    var common = {};
    if (displayState === "skeleton" && !ready && env.runtime) {
      common = {
        visibility: "hidden"
      };
    }
    if (displayState === "skeleton" && ready && env.runtime) {
      common = {
        visibility: "visible"
      };
    }
    if (data.ellipsis) {
      return _objectSpread2(_objectSpread2({}, common), {}, {
        WebkitLineClamp: data.maxLines
      });
    } else {
      return _objectSpread2({}, common);
    }
  }, [data.ellipsis, data.maxLines, ready, displayState]);
  useMemo(function () {
    if (data.ellipsis) {
      return {
        maxLines: data.maxLines
      };
    } else {
      return {};
    }
  }, [data.ellipsis, data.maxLines]);
  var onClick = useCallback(function (e) {
    if (!env.runtime) {
      return;
    }
    // 当配置了单击事件，阻止事件冒泡
    if (outputs["onClick"].getConnections().length) {
      e.stopPropagation();
    }
    outputs["onClick"](data.text);
  }, []);
  var onLongPress = useCallback(function (e) {
    if (!env.runtime) {
      return;
    }
    switch (data.useLongPress) {
      case "tooltip":
        // 长按提示 tooltip，松开手指后消失
        clearTimeout(timerId);
        // 动态获取 textRef 的位置
        if (Taro.getEnv() === Taro.ENV_TYPE.WEB || Taro.getEnv() === "Unknown") {
          var rect = textRef.current.getBoundingClientRect();
          setTooltipStyle({
            width: rect.width,
            top: rect.top - 10,
            left: rect.left + rect.width / 2
          });
          setShowTooltop(true);
        } else {
          var ratio = Taro.getSystemInfoSync().windowWidth / 375;
          var query = Taro.createSelectorQuery();
          query.selectAll(".".concat(id)).boundingClientRect();
          query.exec(function (res) {
            var targetReat = res[0].filter(function (item) {
              return item.left <= e.currentTarget.x && item.right >= e.currentTarget.x && item.top <= e.currentTarget.y && item.bottom >= e.currentTarget.y;
            });
            setTooltipStyle({
              width: targetReat[0].width / ratio,
              top: targetReat[0].top / ratio - 10,
              left: targetReat[0].left / ratio + targetReat[0].width / ratio / 2
            });
            setShowTooltop(true);
          });
        }
        break;
      case "custom":
        outputs["onLongPress"](data.text);
        break;
    }
  }, [data.useLongPress, timerId, id, textRef.current, displaySkeleton]);
  var onTouchEnd = useCallback(function () {
    var id = setTimeout(function () {
      setShowTooltop(false);
    }, 500);
    setTimerId(id);
  }, []);
  var text = useMemo(function () {
    var _data$text;
    var text = (_data$text = data.text) !== null && _data$text !== void 0 ? _data$text : "";
    if (_typeof(text) === "object") {
      return JSON.stringify(text);
    }
    return text;
  }, [data.text]);
  //
  var display = useMemo(function () {
    if (displayState === "hidden" && !ready && env.runtime) {
      return false;
    }
    return true;
  }, [displayState, env.runtime, ready]);
  return __combine_nesting_style__(/*#__PURE__*/React__default.createElement(TaroViewTagName, null, display ? /*#__PURE__*/React__default.createElement(TaroViewTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), textCx),
    className: textCx,
    onClick: onClick,
    onLongPress: onLongPress,
    onTouchEnd: onTouchEnd
  }, showTooltop && !displaySkeleton ? /*#__PURE__*/React__default.createElement(TaroViewTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), css$4.tooltip),
    className: css$4.tooltip,
    style: tooltipStyle
  }, text) : null, /*#__PURE__*/React__default.createElement(TaroViewTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), SkeletonCx),
    className: SkeletonCx
  }, /*#__PURE__*/React__default.createElement(TaroViewTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), ellipsisCx),
    ref: textRef,
    className: ellipsisCx,
    style: textStyle
  }, text))) : null), __nesting_style__());
}
var css$3 = {
  "container": "style_container__wthZ8"
};
function mybricks_taro_containerBasic(_ref) {
  var env = _ref.env,
    data = _ref.data,
    slots = _ref.slots;
  _ref.inputs;
  var outputs = _ref.outputs;
  var onClick = useCallback(function (e) {
    var _outputs$onClick;
    if (!env.runtime) {
      return;
    }
    // 当配置了单击事件，阻止事件冒泡
    if (outputs["onClick"].getConnections().length) {
      e.stopPropagation();
    }
    (_outputs$onClick = outputs["onClick"]) === null || _outputs$onClick === void 0 || _outputs$onClick.call(outputs);
  }, []);
  return __combine_nesting_style__(/*#__PURE__*/React__default.createElement(TaroViewTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), cx(css$3.container, "mybricks-container")),
    className: cx(css$3.container, "mybricks-container"),
    onClick: onClick
  }, slots["content"].render({
    style: _objectSpread2({}, data.layout)
  })), __nesting_style__());
}
var css$2 = {
  "condition": "style_condition__2puQg",
  "content": "style_content__ftKiQ"
};
function mybricks_taro_containerCondition2(_ref) {
  var env = _ref.env,
    data = _ref.data,
    slots = _ref.slots,
    inputs = _ref.inputs,
    outputs = _ref.outputs;
  var _useState = useState(data.defaultActiveId),
    _useState2 = _slicedToArray(_useState, 2),
    innputId = _useState2[0],
    setInputId = _useState2[1];
  var _useState3 = useState(),
    _useState4 = _slicedToArray(_useState3, 2);
  _useState4[0];
  var setBool = _useState4[1];
  var activeId = useMemo(function () {
    if (env.edit) {
      var _data$_editSelectId_, _data$items;
      return (_data$_editSelectId_ = data._editSelectId_) !== null && _data$_editSelectId_ !== void 0 ? _data$_editSelectId_ : (_data$items = data.items) === null || _data$items === void 0 || (_data$items = _data$items[0]) === null || _data$items === void 0 ? void 0 : _data$items.id;
    }
    return innputId;
  }, [data.items, data._editSelectId_, innputId]);
  /** TODO 写在useEffect里时序有延迟，容易出现闪屏，先试试这样先 */
  useMemo(function () {
    var _inputs$setValue;
    // 通过setValue来切换条件
    (_inputs$setValue = inputs["setValue"]) === null || _inputs$setValue === void 0 || _inputs$setValue.call(inputs, function (bool, relOutputs) {
      var _relOutputs$setValueD, _outputs$changeCondit, _outputs$item$outputI;
      var item = data.items.find(function (t) {
        return t.title === bool;
      });
      if (!item) {
        return;
      }
      setInputId(item.id);
      setBool(bool);
      (_relOutputs$setValueD = relOutputs["setValueDone"]) === null || _relOutputs$setValueD === void 0 || _relOutputs$setValueD.call(relOutputs, bool);
      (_outputs$changeCondit = outputs["changeCondition"]) === null || _outputs$changeCondit === void 0 || _outputs$changeCondit.call(outputs, bool);
      (_outputs$item$outputI = outputs[item.outputId]) === null || _outputs$item$outputI === void 0 || _outputs$item$outputI.call(outputs, bool);
    });
    //通过连线来切换条件
    data.items.forEach(function (item) {
      var _inputs$item$id;
      (_inputs$item$id = inputs[item.id]) === null || _inputs$item$id === void 0 || _inputs$item$id.call(inputs, function (bool, relOutputs) {
        var _outputs$changeCondit3, _outputs$item$outputI3, _relOutputs$changeDon2;
        if (item.id === activeId) {
          var _slots$item$id, _slots$item$id$inputs, _slots$item$id$inputs2, _relOutputs$changeDon, _outputs$item$outputI2, _outputs$changeCondit2;
          (_slots$item$id = slots[item.id]) === null || _slots$item$id === void 0 || (_slots$item$id$inputs = (_slots$item$id$inputs2 = _slots$item$id.inputs)["itemData"]) === null || _slots$item$id$inputs === void 0 || _slots$item$id$inputs.call(_slots$item$id$inputs2, bool);
          setBool(bool);
          (_relOutputs$changeDon = relOutputs["changeDone"]) === null || _relOutputs$changeDon === void 0 || _relOutputs$changeDon.call(relOutputs, bool);
          (_outputs$item$outputI2 = outputs[item.outputId]) === null || _outputs$item$outputI2 === void 0 || _outputs$item$outputI2.call(outputs, bool);
          (_outputs$changeCondit2 = outputs["changeCondition"]) === null || _outputs$changeCondit2 === void 0 || _outputs$changeCondit2.call(outputs, bool);
          return;
        }
        setInputId(item.id);
        setBool(bool);
        (_outputs$changeCondit3 = outputs["changeCondition"]) === null || _outputs$changeCondit3 === void 0 || _outputs$changeCondit3.call(outputs, bool);
        (_outputs$item$outputI3 = outputs[item.outputId]) === null || _outputs$item$outputI3 === void 0 || _outputs$item$outputI3.call(outputs, bool);
        (_relOutputs$changeDon2 = relOutputs["changeDone"]) === null || _relOutputs$changeDon2 === void 0 || _relOutputs$changeDon2.call(relOutputs, bool);
      });
    });
  }, [data.items, activeId]);
  var renderMode = useMemo(function () {
    var _data$renderMode;
    if (env.edit) {
      return "lazy"; // 其他模式容易让设计器拿不到真实的widthFact heightFact，所以搭建态不能切换
    }
    return (_data$renderMode = data.renderMode) !== null && _data$renderMode !== void 0 ? _data$renderMode : "lazy";
  }, [data.renderMode]);
  return __combine_nesting_style__(/*#__PURE__*/React__default.createElement(TaroViewTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), css$2.condition),
    className: css$2.condition
  }, renderMode === "lazy" && data.items.map(function (item) {
    var _slots$item$id2;
    if (activeId !== item.id) {
      return null;
    }
    return /*#__PURE__*/React__default.createElement(TaroViewTagName, {
      __hmStyle: calcStaticStyle(__inner_style__(), css$2.content),
      className: css$2.content,
      key: "".concat(renderMode).concat(item.id)
    }, (_slots$item$id2 = slots[item.id]) === null || _slots$item$id2 === void 0 ? void 0 : _slots$item$id2.render({
      key: item.id
    }));
  }), renderMode === "pre" && data.items.map(function (item) {
    var _slots$item$id3;
    return /*#__PURE__*/React__default.createElement(TaroViewTagName, {
      __hmStyle: calcStaticStyle(__inner_style__(), css$2.content),
      className: css$2.content,
      key: "".concat(renderMode).concat(item.id),
      style: activeId !== item.id ? {
        display: 'none'
      } : {}
    }, (_slots$item$id3 = slots[item.id]) === null || _slots$item$id3 === void 0 ? void 0 : _slots$item$id3.render({
      key: item.id
    }));
  })), __nesting_style__());
}
var css$1 = {
  "checkList": "style_checkList__2MwAo",
  "checkListTrack": "style_checkListTrack__37que",
  "checkListTrackWrap": "style_checkListTrackWrap__yvYfr",
  "line": "style_line__axciN",
  "item": "style_item__crYg8",
  "lines": "style_lines__rR6Eq"
};
var useFormItemValue = function useFormItemValue(initialValue, onChange) {
  var _useState = useState(initialValue),
    _useState2 = _slicedToArray(_useState, 2),
    value = _useState2[0],
    setValue = _useState2[1];
  var valueRef = useRef(initialValue);
  var valueRefProxy = useRef(initialValue);
  useEffect(function () {
    if (value !== valueRef.current) {
      valueRef.current = value;
      if (typeof onChange === "function") {
        onChange(value);
      }
    }
  }, [value, onChange]);
  var setValueProxy = useCallback(function (val) {
    valueRefProxy.current = val;
    setValue(val);
  }, []);
  var getValueImmediately = useCallback(function () {
    return valueRefProxy.current;
  }, []);
  return [value, setValueProxy, getValueImmediately];
};
var css = {
  "item": "item_item__JjgfE",
  "icon": "item_icon__WGZ-H",
  "text": "item_text__GICp-",
  "itemSelected": "item_itemSelected__UlnJf"
};
function Item(props) {
  var _data$itemLayoutStyle;
  var env = props.env,
    data = props.data;
  props.inputs;
  props.outputs;
  props.slots;
  var index = props.index;
  var item = props.item,
    isSelected = props.isSelected,
    onChange = props.onChange;
  var icon = useMemo(function () {
    return isSelected ? item.selectedIcon : item.icon;
  }, [isSelected, item]);
  return __combine_nesting_style__(/*#__PURE__*/React__default.createElement(TaroViewTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), cx(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty({}, css.item, !isSelected), "mybricks-item", !isSelected), css.itemSelected, isSelected), "mybricks-item-selected", isSelected), "mybricks-items", true))),
    "data-index": index,
    className: cx(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty({}, css.item, !isSelected), "mybricks-item", !isSelected), css.itemSelected, isSelected), "mybricks-item-selected", isSelected), "mybricks-items", true)),
    style: _objectSpread2(_objectSpread2({}, (_data$itemLayoutStyle = data.itemLayoutStyle) !== null && _data$itemLayoutStyle !== void 0 ? _data$itemLayoutStyle : {}), {}, {
      height: data.itemHeight ? data.itemHeight : "auto"
    }),
    onClick: function onClick(e) {
      if (env.edit) {
        return;
      }
      e.stopPropagation();
      onChange(item.value);
    }
  }, icon && /*#__PURE__*/React__default.createElement(TaroImageTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), cx(_defineProperty(_defineProperty({}, css.icon, true), "mybricks-icon", true))),
    className: cx(_defineProperty(_defineProperty({}, css.icon, true), "mybricks-icon", true)),
    src: icon
  }), item.label && /*#__PURE__*/React__default.createElement(TaroViewTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), cx(_defineProperty(_defineProperty(_defineProperty({}, css.text, true), "mybricks-text", !isSelected), "mybricks-text-selected", isSelected))),
    className: cx(_defineProperty(_defineProperty(_defineProperty({}, css.text, true), "mybricks-text", !isSelected), "mybricks-text-selected", isSelected))
  }, item.label)), __nesting_style__());
}
function mybricks_taro_checkList(props) {
  var env = props.env,
    data = props.data,
    inputs = props.inputs,
    outputs = props.outputs;
  props.slots;
  var defaultValue = useMemo(function () {
    if (env.edit) {
      var _data$options$;
      return [(_data$options$ = data.options[0]) === null || _data$options$ === void 0 ? void 0 : _data$options$.value];
    }
    return data.defaultValue || [];
  }, [env.edit, data.options, data.defaultValue]);
  var _useFormItemValue = useFormItemValue(defaultValue, function (val) {
      //
      var result = val;
      if (data.useMultiple) ;else {
        result = val[0];
      }
      outputs["onChange"](result);
    }),
    _useFormItemValue2 = _slicedToArray(_useFormItemValue, 3),
    value = _useFormItemValue2[0],
    setValue = _useFormItemValue2[1],
    getValue = _useFormItemValue2[2];
  //
  var _useState = useState(env.edit ? true : data.defaultRenderMode === "dynamic" ? false : true),
    _useState2 = _slicedToArray(_useState, 2),
    ready = _useState2[0],
    setReady = _useState2[1];
  useEffect(function () {
    inputs["setValue"](function (val, outputRels) {
      setValue(val);
      outputRels["setValueComplete"](val);
    });
    inputs["getValue"](function (val, outputRels) {
      var result = getValue();
      if (data.useMultiple) ;else {
        result = result[0];
      }
      outputRels["returnValue"](result);
    });
    inputs["resetValue"](function (val, outputRels) {
      setValue("");
      outputRels["resetValueComplete"]("");
    });
    inputs["setOptions"](function (val) {
      if (Array.isArray(val)) {
        data.options = val;
        setReady(true);
        // 如果选项中有 selected 为 true 的项，则设置为当前值
        var selectedItems = val.filter(function (item) {
          return item.selected;
        });
        if (data.useMultiple) {
          setValue(selectedItems.map(function (item) {
            return item.value;
          }));
        } else {
          var _selectedItems;
          setValue([(_selectedItems = selectedItems[selectedItems.length - 1]) === null || _selectedItems === void 0 ? void 0 : _selectedItems.value]);
        }
      }
    });
  }, [data.useMultiple]);
  var onChange = useCallback(function (val) {
    if (!env.runtime) {
      return;
    }
    var _value = value.slice();
    var index = _value.indexOf(val);
    if (data.useMultiple) {
      // 多选模式
      if (index > -1) {
        _value.splice(index, 1);
      } else {
        _value.push(val);
      }
    } else {
      // 单选模式
      if (index > -1) ;else {
        _value = [val];
      }
    }
    setValue(_value);
  }, [value, data.useMultiple]);
  var options = useMemo(function () {
    return ready && data.options || [];
  }, [ready, data.options]);
  return __combine_nesting_style__(/*#__PURE__*/React__default.createElement(TaroViewTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), cx([css$1.checkList, "mybricks-checkList"])),
    className: cx([css$1.checkList, "mybricks-checkList"])
  }, /*#__PURE__*/React__default.createElement(TaroViewTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), cx(_defineProperty(_defineProperty({}, css$1.checkListTrack, true), css$1.checkListTrackWrap, data.useWrap))),
    className: cx(_defineProperty(_defineProperty({}, css$1.checkListTrack, true), css$1.checkListTrackWrap, data.useWrap))
  }, /*#__PURE__*/React__default.createElement(TaroViewTagName, {
    __hmStyle: calcStaticStyle(__inner_style__(), cx(_defineProperty(_defineProperty({}, css$1.line, !data.useWrap), css$1.lines, data.useWrap))),
    className: cx(_defineProperty(_defineProperty({}, css$1.line, !data.useWrap), css$1.lines, data.useWrap)),
    style: {
      marginBottom: data.useWrap ? "-".concat(data.gutter[0], "px") : 0,
      marginRight: data.useWrap ? "-".concat(data.gutter[1], "px") : 0
    }
  }, options.map(function (item, index) {
    var isSelected = value.includes(item.value);
    var style = {
      paddingRight: "".concat(data.gutter[1], "px")
    };
    if (data.useWrap) {
      style = _objectSpread2(_objectSpread2({}, style), {}, {
        maxWidth: "".concat(100 / data.column, "%"),
        flexBasis: "".concat(100 / data.column, "%"),
        paddingBottom: "".concat(data.gutter[0], "px")
      });
    } else {
      style = _objectSpread2(_objectSpread2({}, style), {}, {
        minWidth: "".concat(data.itemMinWidth, "px")
      });
    }
    return /*#__PURE__*/React__default.createElement(TaroViewTagName, {
      __hmStyle: calcStaticStyle(__inner_style__(), css$1.item),
      className: css$1.item,
      style: style
    }, /*#__PURE__*/React__default.createElement(Item, _extends({}, props, {
      item: item,
      isSelected: isSelected,
      onChange: onChange,
      index: index
    })));
  })))), __nesting_style__());
}
function polyfill(obj) {
  for (var key in obj) obj[obj[key].namespace + '-' + obj[key].version] = obj[key];
  return obj;
}
var comDefs = polyfill({
  "mybricks.taro._connector": {
    namespace: "mybricks.taro._connector",
    version: "1.0.0",
    runtime: mybricks_taro__connector
  },
  "mybricks.taro._connectorGlobalHeaders": {
    namespace: "mybricks.taro._connectorGlobalHeaders",
    version: "1.0.0",
    runtime: mybricks_taro__connectorGlobalHeaders
  },
  "mybricks.taro._muilt-inputJs": {
    namespace: "mybricks.taro._muilt-inputJs",
    version: "1.0.0",
    runtime: mybricks_taro__muilt_inputJs
  },
  "mybricks.taro._format": {
    namespace: "mybricks.taro._format",
    version: "1.0.0",
    runtime: mybricks_taro__format
  },
  "mybricks.taro._timerDelay": {
    namespace: "mybricks.taro._timerDelay",
    version: "1.0.0",
    runtime: mybricks_taro__timerDelay
  },
  "mybricks.taro._setStorage": {
    namespace: "mybricks.taro._setStorage",
    version: "1.0.0",
    runtime: mybricks_taro__setStorage
  },
  "mybricks.taro._getStorage": {
    namespace: "mybricks.taro._getStorage",
    version: "1.0.0",
    runtime: mybricks_taro__getStorage
  },
  "mybricks.taro.open": {
    namespace: "mybricks.taro.open",
    version: "1.0.0",
    runtime: mybricks_taro_open
  },
  "mybricks.taro._goto": {
    namespace: "mybricks.taro._goto",
    version: "1.0.0",
    runtime: mybricks_taro__goto
  },
  "mybricks.taro._navigateBack": {
    namespace: "mybricks.taro._navigateBack",
    version: "1.0.0",
    runtime: mybricks_taro__navigateBack
  },
  "mybricks.taro._getRouter": {
    namespace: "mybricks.taro._getRouter",
    version: "1.0.0",
    runtime: mybricks_taro__getRouter
  },
  "mybricks.taro._toast": {
    namespace: "mybricks.taro._toast",
    version: "1.0.1",
    runtime: mybricks_taro__toast
  },
  "mybricks.taro._showToast": {
    namespace: "mybricks.taro._showToast",
    version: "1.0.1",
    runtime: mybricks_taro__showToast
  },
  "mybricks.taro._hideToast": {
    namespace: "mybricks.taro._hideToast",
    version: "1.0.0",
    runtime: mybricks_taro__hideToast
  },
  "mybricks.taro._showLoading": {
    namespace: "mybricks.taro._showLoading",
    version: "1.0.0",
    runtime: mybricks_taro__showLoading
  },
  "mybricks.taro._hideLoading": {
    namespace: "mybricks.taro._hideLoading",
    version: "1.0.0",
    runtime: mybricks_taro__hideLoading
  },
  "mybricks.taro._setNavigationBarTitle": {
    namespace: "mybricks.taro._setNavigationBarTitle",
    version: "1.0.0",
    runtime: mybricks_taro__setNavigationBarTitle
  },
  "mybricks.taro._scan-qrcode": {
    namespace: "mybricks.taro._scan-qrcode",
    version: "1.0.0",
    runtime: mybricks_taro__scan_qrcode
  },
  "mybricks.taro._call-phone": {
    namespace: "mybricks.taro._call-phone",
    version: "1.0.0",
    runtime: mybricks_taro__call_phone
  },
  "mybricks.taro.systemPage": {
    namespace: "mybricks.taro.systemPage",
    version: "1.0.1",
    runtime: mybricks_taro_systemPage
  },
  "mybricks.taro.popup": {
    namespace: "mybricks.taro.popup",
    version: "1.0.0",
    runtime: mybricks_taro_popup
  },
  "mybricks.taro.image": {
    namespace: "mybricks.taro.image",
    version: "1.0.0",
    runtime: mybricks_taro_image
  },
  "mybricks.taro.button": {
    namespace: "mybricks.taro.button",
    version: "1.0.0",
    runtime: mybricks_taro_button
  },
  "mybricks.taro.text": {
    namespace: "mybricks.taro.text",
    version: "1.0.0",
    runtime: mybricks_taro_text
  },
  "mybricks.taro.containerBasic": {
    namespace: "mybricks.taro.containerBasic",
    version: "1.0.0",
    runtime: mybricks_taro_containerBasic
  },
  "mybricks.taro.containerCondition2": {
    namespace: "mybricks.taro.containerCondition2",
    version: "1.0.0",
    runtime: mybricks_taro_containerCondition2
  },
  "mybricks.taro.checkList": {
    namespace: "mybricks.taro.checkList",
    version: "1.0.0",
    runtime: mybricks_taro_checkList
  }
});

export { comDefs as default };
//# sourceMappingURL=comDefs.js.map
