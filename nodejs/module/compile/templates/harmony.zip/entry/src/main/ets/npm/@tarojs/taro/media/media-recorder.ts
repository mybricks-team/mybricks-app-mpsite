// @ts-nocheck
import { temporarilyNotSupport } from '../utils'

// 画面录制器
export const createMediaRecorder = /* @__PURE__ */ temporarilyNotSupport('createMediaRecorder')
