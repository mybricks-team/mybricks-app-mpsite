// @ts-nocheck
export { eventSource } from '../dist/runtime.esm'
