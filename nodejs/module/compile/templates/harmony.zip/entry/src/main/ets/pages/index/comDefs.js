import comDefs from '../../components/comDefs.js';



export { comDefs as default };
//# sourceMappingURL=comDefs.js.map
