import { window } from './npm/@tarojs/runtime';
import Taro from './npm/@tarojs/taro';
import pako from './node_modules/pako/dist/pako.esm.js';

const isH5 = Taro.getEnv() === Taro.ENV_TYPE.WEB || Taro.getEnv() === "Unknown";
let global = {
  currunt: {}
};
const getGlobalData = () => {
  if ("harmony" === "h5") {
    if (!window.__render_bricks__) {
      window.__render_bricks__ = {};
    }
    return window.__render_bricks__;
  }
  if ("harmony" === "harmony") {
    if (!globalThis.$mbr) {
      globalThis.$mbr = {};
    }
    return globalThis.$mbr;
  }
  if ("harmony" === "alipay" || "harmony" === "dd") {
    if (getApp() === void 0) {
      getApp = () => global.currunt;
    }
    return global.currunt;
  }
  return Taro.getApp?.({
    allowDefault: true
  });
};
const checkUpdateVersionAndApply = _ref => {
  let {
    checkAndUpdate = false,
    showConfirm = true
  } = _ref;
  if (!checkAndUpdate) {
    return;
  }
  if (false) {
    const updateManager = Taro.getUpdateManager();
    updateManager.onCheckForUpdate(function (res) {
      if (res.hasUpdate) {
        updateManager.onUpdateReady(function () {
          if (showConfirm) {
            Taro.showModal({
              title: "更新提示",
              content: "新版本已经准备好，是否重启应用？",
              success: function (res2) {
                if (res2.confirm) {
                  updateManager.applyUpdate();
                }
              }
            });
          } else {
            updateManager.applyUpdate();
          }
        });
        updateManager.onUpdateFailed(function () {
          Taro.showModal({
            title: "已经有新版本喽~",
            content: "请您删除当前小程序，到微信 “发现-小程序” 页，重新搜索打开哦~"
          });
        });
      }
    });
  } else {}
};
function parsePakoJson(input) {
  const unzipStartTime = (/* @__PURE__ */new Date()).getTime();
  let result;
  if ("harmony" === "h5") {
    result = atob(input);
  } else {
    result = Taro.base64ToArrayBuffer(input);
  }
  try {
    result = pako.inflate(result, {
      to: "string"
    });
  } catch (e) {
    console.error(e);
  }
  try {
    result = JSON.parse(result);
  } catch (e) {
    console.error(e);
  }
  console.log(`unzip time ${unzipStartTime - (new Date()).getTime()}ms`);
  return result;
}

export { checkUpdateVersionAndApply, getGlobalData, isH5, parsePakoJson };
//# sourceMappingURL=utils.js.map
