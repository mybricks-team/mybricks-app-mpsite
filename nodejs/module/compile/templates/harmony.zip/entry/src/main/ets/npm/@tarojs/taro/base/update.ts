// @ts-nocheck
import { temporarilyNotSupport } from '../utils'

// 更新
export const updateWeChatApp = /* @__PURE__ */ temporarilyNotSupport('updateWeChatApp')
export const getUpdateManager = /* @__PURE__ */ temporarilyNotSupport('getUpdateManager')
