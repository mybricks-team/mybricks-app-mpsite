// @ts-nocheck
import { temporarilyNotSupport } from '../utils'

// 车牌
export const chooseLicensePlate = /* @__PURE__ */ temporarilyNotSupport('chooseLicensePlate')
