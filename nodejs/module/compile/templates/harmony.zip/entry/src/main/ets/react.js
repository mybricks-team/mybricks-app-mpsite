export { default } from './npm/react';
//# sourceMappingURL=react.js.map
