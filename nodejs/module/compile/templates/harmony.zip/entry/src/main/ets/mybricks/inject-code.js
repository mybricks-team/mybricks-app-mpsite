const allInjectScript = {};

export { allInjectScript as default };
//# sourceMappingURL=inject-code.js.map
