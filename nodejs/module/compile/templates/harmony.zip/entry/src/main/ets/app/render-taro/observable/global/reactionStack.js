import _defineProperty from '../../../../node_modules/@babel/runtime/helpers/esm/defineProperty.js';
import './index.js';
import { globalTaskEmitter } from './taskEmitter.js';

class ReactionStack {
  constructor() {
    _defineProperty(this, "reactionStack", []);
  }
  regist(operation) {
    let reaction = this.getCurrentReaction();
    if (reaction) {
      globalTaskEmitter.registReaction(reaction, operation);
    }
  }
  autoRun(reaction, fn) {
    const {
      reactionStack
    } = this;
    if (reactionStack.indexOf(reaction) === -1) {
      try {
        reactionStack.push(reaction);
        return fn();
      } finally {
        reactionStack.pop();
      }
    }
  }
  getCurrentReaction() {
    const {
      reactionStack
    } = this;
    const reaction = reactionStack[reactionStack.length - 1];
    return reaction;
  }
}
const globalReactionStack = new ReactionStack();

export { globalReactionStack };
//# sourceMappingURL=reactionStack.js.map
