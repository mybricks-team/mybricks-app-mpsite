function isObject(value) {
  return value && typeof value === "object";
}
function isNumber(num) {
  return typeof num === "number" && !isNaN(num);
}
function compareVersion(version1, version2) {
  const arr1 = version1.split(".");
  const arr2 = version2.split(".");
  const length1 = arr1.length;
  const length2 = arr2.length;
  const minlength = Math.min(length1, length2);
  let i = 0;
  for (i; i < minlength; i++) {
    let a = parseInt(arr1[i]);
    let b = parseInt(arr2[i]);
    if (a > b) {
      return 1;
    } else if (a < b) {
      return -1;
    }
  }
  if (length1 > length2) {
    for (let j = i; j < length1; j++) {
      if (parseInt(arr1[j]) != 0) {
        return 1;
      }
    }
    return 0;
  } else if (length1 < length2) {
    for (let j = i; j < length2; j++) {
      if (parseInt(arr2[j]) != 0) {
        return -1;
      }
    }
    return 0;
  }
  return 0;
}
function uuid() {
  let len = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 5;
  let radix = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 8;
  const chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".split("");
  const uuid2 = [];
  radix = radix || chars.length;
  if (len) {
    for (let i = 0; i < len; i++) uuid2[i] = chars[0 | Math.random() * radix];
  } else {
    let r;
    uuid2[8] = uuid2[13] = uuid2[18] = uuid2[23] = "-";
    uuid2[14] = "4";
    for (let i = 0; i < 36; i++) {
      if (!uuid2[i]) {
        r = 0 | Math.random() * 16;
        uuid2[i] = chars[i == 19 ? r & 3 | 8 : r];
      }
    }
  }
  return uuid2.join("");
}
function easyClone(val) {
  if (val && typeof val === "object") {
    try {
      if (val instanceof FormData) {
        return val;
      }
      return JSON.parse(JSON.stringify(val));
    } catch (ex) {
      return val;
    }
  }
  return val;
}

export { compareVersion, easyClone, isNumber, isObject, uuid };
//# sourceMappingURL=utils.js.map
