// @ts-nocheck
import { temporarilyNotSupport } from '../utils'

export const reportMonitor = /* @__PURE__ */ temporarilyNotSupport('reportMonitor')
export const reportAnalytics = /* @__PURE__ */ temporarilyNotSupport('reportAnalytics')
export const reportEvent = /* @__PURE__ */ temporarilyNotSupport('reportEvent')
export const getExptInfoSync = /* @__PURE__ */ temporarilyNotSupport('getExptInfoSync')
