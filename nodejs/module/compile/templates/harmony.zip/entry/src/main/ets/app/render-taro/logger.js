import { window } from '../../npm/@tarojs/runtime';

let silent = false;
function setLoggerSilent() {
  silent = true;
}
const globalKey = "__IOEventList__";
const ioLogger = {
  log: function () {
    if (!window[globalKey]) {
      window[globalKey] = [];
    }
    window[globalKey].push(arguments.length <= 0 ? void 0 : arguments[0]);
    console.log(...arguments);
  }
};
function log(msg) {
  console.log(`%c[Mybricks]%c ${msg}
`, `color:#FFF;background:#fa6400`, ``, ``);
}
function logInputVal(comTitle, comDef, pinId, val) {
  if (silent) {
    return;
  }
  let tval;
  try {
    tval = JSON.stringify(val);
  } catch (ex) {
    tval = val;
  }
  ioLogger.log(`%c[Mybricks] 输入项 %c ${comTitle || comDef.title || comDef.namespace} | ${pinId} -> ${tval}`, `color:#FFF;background:#000`, ``, ``);
}
function logOutputVal(comTitle, comDef, pinId, val) {
  if (silent) {
    return;
  }
  let tval;
  try {
    tval = JSON.stringify(val);
  } catch (ex) {
    tval = val;
  }
  ioLogger.log(`%c[Mybricks] 输出项 %c ${comTitle || comDef.title || comDef.namespace} | ${pinId} -> ${tval}`, `color:#FFF;background:#fa6400`, ``, ``);
}

export { log, logInputVal, logOutputVal, setLoggerSilent };
//# sourceMappingURL=logger.js.map
