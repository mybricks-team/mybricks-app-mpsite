import { createPageConfig } from '../../npm/@tarojs/plugin-framework-react/dist/runtime';
import component from './index_comp.js';
import '../../npm/react';
import '../../npm/@tarojs/react';

const config = {};
const index = () => createPageConfig(component, 'pages/404/index', config);

export { config, index as default };
//# sourceMappingURL=index_taro_comp.js.map
